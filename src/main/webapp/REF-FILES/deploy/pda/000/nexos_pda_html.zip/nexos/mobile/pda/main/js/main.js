/**
 * <pre>
 *  ==================================================================================================================================================
 *  프로그램ID         : mobile main
 *  프로그램명         : Mobile Main
 *  프로그램설명       : Mobile Main 화면 Javascript
 *  작성자             : Copyright (c) 2013 ASETEC Corporation. All rights reserved.
 *  작성일자           : 2016-12-14
 *  버전               : 1.0
 * 
 *  --------------------------------------------------------------------------------------------------------------------------------------------------
 *  버전       작성일자      작성자           설명
 *  ---------  ------------  ---------------  --------------------------------------------------------------------------------------------------------
 *  1.0        2016-12-14    ASETEC           신규작성
 *  --------------------------------------------------------------------------------------------------------------------------------------------------
 * 
 *  ==================================================================================================================================================
 * </pre>
 */

/**
 * 화면 초기화 - 화면 로드시 자동 호출 됨
 */
function _Initialize() {

    // 단위화면에서 사용될 일반 전역 변수 정의
    $NC.setGlobalVar({
        // 실행 단위 화면 목록
        windows: [],
        // 최종 실행 화면, 단위화면, 단위화면 팝업, 공통코드검색 팝업, 출력미리보기 팝업
        lastWindow: null,
        // 현재 활성화된 단위 화면
        activeWindow: null,
        // 현재 활성화된 단위 화면 팝업
        activeSubWindow: null,
        // 현재 활성화된 공통코드검색, 출력미리보기 팝업
        activePopupWindow: null,
        // 오류 메시지 전체 표시 여부
        isFullErrorMessage: false,
        // 데이터 검색 및 복사 관련 정보
        copyInfo: {
            targetGrid: "",
            columnField: "",
            columnName: "",
            rowCount: 0,
            lastSearchVal: "",
            lastSearchIndex: -1
        },
        baseUrl: "/nexos/mobile/pda/",
        activeElement: null,
        activeValue: "",
        onMouseEvent: $.browser.mobile ? "click" : "click",
        // 로그아웃 여부
        isLogout: false,
        // 암호화 처리
        isEncPayload: $NC.iif($.browser.mobile, false, true),
        // 실행 단위 화면 리사이즈 처리 Timeout Event
        onResizeTimeout: null,
        // 데이터 복사 Timeout Event
        onCopyDataTimeout: null,
        // 프로그램 Loading Timeout Event
        onProgramLoadingTimeout: null,
        // 화면 오픈시 포커스 Delaytime
        TIMEOUT_OPEN_FOCUS: 600
    });

    // 최소 사이즈 지정
    if ($Android.isValid()) {
        $NC.G_OFFSET.minWidth = Math.max($(window).width(), 360);
        $NC.G_OFFSET.minHeight = Math.max($(window).height(), 520);
    } else {
        $NC.G_OFFSET.minWidth = 360;
        $NC.G_OFFSET.minHeight = 520;
    }

    // Viewport 조정
    // setViewport();

    // 버튼 이벤트 바인딩
    commonEventInitialize();
    // 그리드 데이터 복사 Overlay 초기화
    copyGridDataOverlayInitialize();
    // 개인정보 체크, 엑셀 다운로드 Overlay 초기화
    piExcelDownloadOverlayInitialize();
    // MainMenu 관련 초기화
    window.mainMenuInitialize();
}

/**
 * Load 완료시 호출 됨
 */
function _OnLoaded() {

    getSessionUserInfo();
}

/**
 * 화면 리사이즈 Offset 세팅
 */
function _SetResizeOffset() {

    $NC.G_OFFSET.nonClientHeight = $("#ctrTopTitleBar").outerHeight(true);
}

/**
 * Window Resize Event - Window Size 조정시 호출 됨
 */
function _OnResize(parent, viewWidth, viewHeight, syncResize) {

    // $("#ctrDisplaySize").html("Win: width=" + viewWidth + ", height=" + viewHeight //
    // + "<br>Min: width=" + $NC.G_OFFSET.minWidth + ", height=" + $NC.G_OFFSET.minHeight);

    // Viewport 사이즈/스크롤바 조정 - Window 사이즈에 맞게 조정, 화면 최소 사이즈보다 작으면 스크롤바 보임
    var $view = $("#ctrViewport"), overflowX = "hidden", overflowY = "hidden", scrollX = 0, scrollY = 0;
    var actualWidth = viewWidth, actualHeight = viewHeight;
    $NC.resizeContainer($view, actualWidth, actualHeight, null, false);

    if (actualWidth < $NC.G_OFFSET.minWidth) {
        scrollY = $NC.G_LAYOUT.scroll.height;
        overflowX = "scroll";
    }
    if (actualHeight < $NC.G_OFFSET.minHeight) {
        scrollX = $NC.G_LAYOUT.scroll.width;
        overflowY = "scroll";
    }
    $view.css("overflow", overflowX + " " + overflowY);

    // 화면 최대 사이즈 계산 - 화면 최소 사이즈 이상
    actualWidth = Math.max(actualWidth, $NC.G_OFFSET.minWidth) - scrollX;
    actualHeight = Math.max(actualHeight, $NC.G_OFFSET.minHeight) - scrollY;
    $NC.resizeContainer("#ctrMainView", actualWidth, actualHeight, null, false);

    // 단위 화면 영역 계산
    actualHeight -= $NC.G_OFFSET.nonClientHeight;
    $NC.G_CHILDLAYOUT.width = actualWidth;
    $NC.G_CHILDLAYOUT.height = actualHeight;

    // 단위 화면 요소 사이즈 조정
    $NC.resizeContainer("#ctrClientView", actualWidth, actualHeight);

    window._OnResizeMainMenu(parent, viewWidth, viewHeight, syncResize);

    clearTimeout($NC.G_VAR.onResizeTimeout);
    if (syncResize) {
        resizeChildWindows();
    } else {
        $NC.G_VAR.onResizeTimeout = setTimeout(resizeChildWindows, 100);
    }
}

/**
 * Input Change Event - Input, Select Change 시 호출 됨
 */
function _OnInputChange(e, view, val) {

    // 기본정보 입력 콘트롤일 경우만 처리
    if (view.parents(".globalOnChangeWC").length > 0) {
        var id = view.prop("id").substr(3).toUpperCase();
        switch (id) {
            case "CENTER_CD":
                $NC.G_USERINFO.CENTER_CD = val;
                $NC.G_USERINFO.CENTER_NM = $NC.getValueCombo(view, "N");
                setLoginUserInfo();
                break;
            case "BU_CD":
                $NC.G_USERINFO.BU_CD = val;
                $NC.G_USERINFO.BU_NM = $NC.getValueCombo(view, "N");
                setLoginUserInfo();
                break;
            case "WORK_DATE":
                if (!$NC.isDate(val)) {
                    alert($NC.getDisplayMsg("JS.PDA_MAIN.XXX", "작업일자를 정확히 입력하십시오."));
                    $NC.setValue(view, $NC.G_USERINFO.WORK_DATE);
                    $NC.setFocus(view);
                    return;
                } else {
                    $NC.G_USERINFO.WORK_DATE = $NC.getDate(val);
                    setLoginUserInfo();
                }
                break;
        }
        window._OnInputChangeMainMenu(id, view, val); // mainMenu에는 event object 대신 id로 전달
        return;
    }

    window._OnInputChangeMainMenu(e, view, val);
}

/**
 * 전체 서비스 호출 실행 후 Call
 * 
 * @param ajaxData
 *        ajaxData, serviceRequest: isSuccess, requestUrl, requestData
 * @returns
 */
function _OnAfterServiceCall(ajaxData, serviceRequest) {

    // 개인정보 조회에 대한 기록
    if ($NC.G_USERINFO.USE_SECURITY_LOG === $ND.C_YES) {
        // 체크 대상 프로그램이 없으면 처리 안함
        if ($NC.isNull($NC.G_VAR.personalInfoPrograms)) {
            return;
        }
        try {
            // 정상처리일 경우만 기록
            if (!serviceRequest.isSuccess) {
                return;
            }
            var requestUrl = serviceRequest.requestUrl || "";
            // 조회 서비스 호출, getData, getDataSet, getDataList
            if (requestUrl.indexOf("/getData") == -1) {
                return;
            }
            // 서비스 Url에서 프로그램ID Parsing
            var rIndex, rCount, isTarget = false, ACTIVITY_PROGRAM_ID = requestUrl.substring(1, requestUrl.indexOf("/", 1));
            // 프로그램 및 결과 데이터 체크
            for (rIndex = 0, rCount = $NC.G_VAR.personalInfoPrograms.length; rIndex < rCount; rIndex++) {
                var checkingProgram = $NC.G_VAR.personalInfoPrograms[rIndex] || "";
                if (ACTIVITY_PROGRAM_ID.indexOf(checkingProgram) == -1 || $NC.isNull(serviceRequest.requestData)) {
                    continue;
                }
                isTarget = true;
                break;
            }
            if (!isTarget) {
                return;
            }
            var responseData = ajaxData.data || "";
            var piColumns = $NC.G_VAR.personalInfoColumns || [];
            for (rIndex = 0, rCount = piColumns.length; rIndex < rCount; rIndex++) {
                if (responseData.indexOf("\"" + piColumns[rIndex] + "\"") > -1) {
                    $NC.serviceCallAndWait("/WC/writeActivityLog.do", {
                        P_QUERY_PARAMS: {
                            P_ACTIVITY_CD: ACTIVITY_PROGRAM_ID,
                            P_ACTIVITY_COMMENT: objToParamString(serviceRequest.requestData),
                            P_ACTIVITY_DIV: "21", // 21 - 개인정보조회
                            P_USER_ID: $NC.G_USERINFO.USER_ID
                        }
                    }, function() {
                        // 성공
                    }, function() {
                        // 실패 메시지 표시 하지 않음
                    });
                    break;
                }
            }

            // 프로그램만 체크
            // for (var rIndex = 0, rCount = $NC.G_VAR.personalInfoPrograms.length; rIndex < rCount; rIndex++) {
            // var checkingProgram = $NC.G_VAR.personalInfoPrograms[rIndex] || "";
            // if (ACTIVITY_PROGRAM_ID.indexOf(checkingProgram) == -1 || $NC.isNull(serviceRequest.requestData)) {
            // continue;
            // }
            // var QUERY_ID = serviceRequest.requestData.P_QUERY_ID || "";
            // if (QUERY_ID.indexOf(checkingProgram) == -1) {
            // continue;
            // }
            // $NC.serviceCallAndWait("/WC/writeActivityLog.do", {
            // P_ACTIVITY_CD: ACTIVITY_PROGRAM_ID,
            // P_ACTIVITY_COMMENT: objToParamString(serviceRequest.requestData),
            // P_ACTIVITY_DIV: "21", // 21 - 개인정보조회
            // P_USER_ID: $NC.G_USERINFO.USER_ID
            // }, function() {
            // // 성공
            // }, function() {
            // // 실패 메시지 표시 하지 않음
            // });
            // break;
            // }
        } catch (e) {
            //
        }
    }
}

function setViewport() {

    var viewportWidth = $(window).width(), viewportHeight = $(window).height(), designWidth = 360, screenOrientation = 1;
    if ($Android.isValid()) {
        designWidth = $NC.nullToDefault($Android.callby("getDesignWidth"), designWidth);
        screenOrientation = $NC.nullToDefault($Android.callby("getScreenOrientation"), screenOrientation);
    }

    var scaleVal;
    if (screenOrientation == 1) {
        scaleVal = viewportWidth / designWidth;
    } else {
        scaleVal = viewportHeight / designWidth;
    }
    var $viewport = $("head").children("meta[name='viewport']");
    if ($viewport.length < 1) {
        $viewport = $("<meta name='viewport' />").appendTo($("head"));
    }

    $NC.G_OFFSET.viewportWidth = viewportWidth / scaleVal;
    $NC.G_OFFSET.viewportHeight = viewportHeight / scaleVal;

    var content = "width=" + $NC.G_OFFSET.viewportWidth //
        + ", height=" + $NC.G_OFFSET.viewportHeight //
        + ", initial-scale=" + scaleVal //
        + ", maximum-scale=" + scaleVal;
    $viewport.attr("content", content);
}

/**
 * Input KeyUp Event - Input, Select Keyup 시 호출 됨
 */
function _OnInputKeyUp(e, view) {

    // 로그인 입력 콘트롤일 경우만 처리
    if (view.parents(".ctrLogin").length > 0) {
        if (e.keyCode != 13) {
            return;
        }

        switch (view.prop("id")) {
            case "edtUser_Pwd":
                btnLoginOnClick();
                break;
            case "edtReset_User_Email":
                btnResetUserPwdOnClick();
                break;
        }

        return;
    }

    window._OnInputKeyUpMainMenu(e, view);
}

/**
 * Inquiry Button Event - 메인 상단 조회 버튼 클릭시 호출 됨
 */
function _Inquiry() {

    var activeWindow = $NC.G_VAR.activeWindow;
    if ($NC.isNull(activeWindow)) {
        return;
    }

    var contentWindow = $NC.getChildWindow(activeWindow);
    if ($.isFunction(contentWindow._Inquiry)) {
        contentWindow._Inquiry();
    }
}

/**
 * New Button Event - 메인 상단 신규 버튼 클릭시 호출 됨
 */
function _New() {

    var activeWindow = $NC.G_VAR.activeWindow;
    if ($NC.isNull(activeWindow)) {
        return;
    }

    if (activeWindow.get("G_PARAMETER").EXE_LEVEL1 !== $ND.C_YES) {
        alert($NC.getDisplayMsg("JS.PDA_MAIN.001", "해당 프로그램의 저장권한이 없습니다."));
        return;
    }

    var contentWindow = $NC.getChildWindow(activeWindow);
    if ($.isFunction(contentWindow._New)) {
        contentWindow._New();
    }
}

/**
 * Save Button Event - 메인 상단 저장 버튼 클릭시 호출 됨
 */
function _Save() {

    var activeWindow = $NC.G_VAR.activeWindow;
    if ($NC.isNull(activeWindow)) {
        return;
    }

    if (activeWindow.get("G_PARAMETER").EXE_LEVEL1 !== $ND.C_YES) {
        alert($NC.getDisplayMsg("JS.PDA_MAIN.001", "해당 프로그램의 저장권한이 없습니다."));
        return;
    }

    var contentWindow = $NC.getChildWindow(activeWindow);
    if ($.isFunction(contentWindow._Save)) {
        contentWindow._Save();
    }
}

/**
 * Cancel Button Event - 메인 상단 취소 버튼 클릭시 호출 됨
 */
function _Cancel() {

    var activeWindow = $NC.G_VAR.activeWindow;
    if ($NC.isNull(activeWindow)) {
        return;
    }

    if (activeWindow.get("G_PARAMETER").EXE_LEVEL1 !== $ND.C_YES) {
        alert($NC.getDisplayMsg("JS.PDA_MAIN.001", "해당 프로그램의 저장권한이 없습니다."));
        return;
    }

    var contentWindow = $NC.getChildWindow(activeWindow);
    if ($.isFunction(contentWindow._Cancel)) {
        contentWindow._Cancel();
    }
}

/**
 * Delete Button Event - 메인 상단 삭제 버튼 클릭시 호출 됨
 */
function _Delete() {

    var activeWindow = $NC.G_VAR.activeWindow;
    if ($NC.isNull(activeWindow)) {
        return;
    }

    if (activeWindow.get("G_PARAMETER").EXE_LEVEL2 !== $ND.C_YES) {
        alert($NC.getDisplayMsg("JS.PDA_MAIN.002", "해당 프로그램의 삭제권한이 없습니다."));
        return;
    }

    var contentWindow = $NC.getChildWindow(activeWindow);
    if ($.isFunction(contentWindow._Delete)) {
        contentWindow._Delete();
    }
}

/**
 * Print Button Event - 메인 상단 출력 버튼 클릭시 호출 됨
 */
function _Print() {

}

function _OnAfterPrint() {

}

/**
 * Event 초기화
 */
function commonEventInitialize() {

    $(window) //
    .on("beforeunload", function(e) {
        if ($NC.G_VAR.ignoreUnloadMessage) {
            return;
        }
        if ($NC.G_VAR.isLogout) {
            return;
        }
        var confirmationMessage = null;
        if ($NC.G_VAR.windows.length > 0) {
            confirmationMessage = $NC.getDisplayMsg("JS.PDA_MAIN.003", "현재 작업 중인 화면이 존재합니다. 다른 사이트로 이동시 모든 화면이 초기화됩니다.");
        } else {
            confirmationMessage = $NC.getDisplayMsg("JS.PDA_MAIN.XXX", "다른 사이트로 이동시 모든 화면이 초기화됩니다.");
        }

        if ($NC.isNotNull(confirmationMessage)) {
            // (e || window.event).returnValue = confirmationMessage;
            return confirmationMessage;
        }
    }) //
    .on("unload", function(e) {
        // 프로그램 종료 기록
        writeProgramActivityLog("12");
    });

    $NC.setValue("#lblServerVersion", $NC.nullToDefault($("meta[name=Nexos-Server-Version]").prop("content"), "0.0.0"));
    $NC.setVisible("#lblServerVersion", false); // PDA에서는 숨김
    if ($Android.isValid()) {
        $NC.setGlobalVar({ //
            PDA_APPLICATION_VERSION: $NC.nullToDefault($Android.callby("getApplicationVersion"), "0.0.00"),
            PDA_RESOURCE_VERSION: $NC.nullToDefault($Android.callby("getResourceVersion"), "0.0.00")
        });
        $NC.setValue("#lblAppVersion", $NC.G_VAR.PDA_APPLICATION_VERSION);
        $NC.setValue("#lblResVersion", $NC.G_VAR.PDA_RESOURCE_VERSION);
    } else {
        // Desktop에서는 숨김
        $NC.setVisible("#ctrVersion .ctrGroupRow", false);
    }
    // $("#btnClose").click(btnCloseOnClick);
    $("#btnLogout").click(btnLogoutOnClick);
    $("#btnLogin").click(btnLoginOnClick);
    $("#btnResetForm").click(toggleLoginForm).hide();
    $("#edtUser_Pwd").css("padding-right", "4px");
    $NC.setTooltip("#btnResetForm", $NC.getDisplayMsg("JS.PDA_MAIN.XXX", "비밀번호 초기화"));
    $("#btnLoginForm").click(toggleLoginForm);
    $("#btnResetUserPwd").click(btnResetUserPwdOnClick);
    $("#btnTopLogo").on($NC.G_VAR.onMouseEvent, showDeveloperPopup);
    $("#btnTopUser").on($NC.G_VAR.onMouseEvent, btnTopUserOnClick);
    $("#ctrMainView").focus(setFocusActiveWindow);
    if ($.browser.mobile) {
        $("#imgLogoBI") //
        .css("cursor", "pointer") //
        .click(function() {
            window.location.reload(true);
        });
    }

    var $view = $("#pgbProcessing");
    if ($view.length > 0) {
        $view.progressbar({
            value: false
        }).children().css("background-color", "#e6e6e6");
    }
    $("#ctrProcessingLayer") //
    .click(function(e) {
        if (e.ctrlKey || e.metaKey) {
            $NC.hideProgressMessage(true);
        }
    }) //
    .keydown(function(e) {
        e.preventDefault();
    });
    $("#ctrLoadingLayer") //
    .click(function(e) {
        if (e.ctrlKey || e.metaKey) {
            $NC.hideLoadingMessage(true);
        }
    }) //
    .keydown(function(e) {
        e.preventDefault();
    });
    $("#ctrPrintingLayer") //
    .click(function(e) {
        if (e.ctrlKey || e.metaKey) {
            $NC.hidePrintingMessage(true);
        }
    }) //
    .keydown(function(e) {
        e.preventDefault();
    });
}

/**
 * 종료 버튼 클릭 이벤트
 */
function btnCloseOnClick(e) {

    var activeWindow = $NC.G_VAR.activeWindow;
    if ($NC.isNull(activeWindow)) {
        return;
    }

    if (e.ctrlKey || e.metaKey) {
        writeProgramActivityLog("12");

        removeAllChildWindow();
    } else {
        // 프로그램 실행 로그 기록
        writeProgramActivityLog("12", activeWindow.get("G_PARAMETER").PROGRAM_ID);

        removeChildWindow(activeWindow);
    }
}

/**
 * 로그인 버튼 클릭 이벤트
 */
function btnLoginOnClick(e) {

    var USER_ID = $NC.getValue("#edtUser_Id");
    var USER_PWD = $NC.getValue("#edtUser_Pwd");

    if ($NC.isNull(USER_ID)) {
        alert($NC.getDisplayMsg("JS.PDA_MAIN.008", "사용자ID를 입력하십시오."));
        $NC.setFocus("#edtUser_Id");
        return;
    }

    if ($NC.isNull(USER_PWD)) {
        alert($NC.getDisplayMsg("JS.PDA_MAIN.009", "비밀번호를 입력하십시오."));
        $NC.setFocus("#edtUser_Pwd");
        return;
    }

    if ($NC.isNotNull($NC.G_USERINFO) && USER_ID != $NC.G_USERINFO.USER_ID && $NC.G_VAR.windows.length > 0) {
        if (confirm($NC.getDisplayMsg("JS.PDA_MAIN.010", "기존에 로그인했던 사용자가 아닙니다.\n로그인시 실행중인 프로그램이 모두 종료됩니다.\n\n입력한 사용자로 로그인하시겠습니까?"))) {
            removeAllChildWindow();
        } else {
            $NC.setValue("#edtUser_Id");
            $NC.setValue("#edtUser_Pwd");
            $NC.setFocus("#edtUser_Id");
            return;
        }
    }

    var $ctrLoginLayer = $("#ctrLoginLayer");
    if ($NC.isNull($ctrLoginLayer.data("loginType"))) {
        $ctrLoginLayer.data("loginType", 0);
    }

    if ($NC.G_VAR.isEncPayload) {
        $NC.serviceCall("/WC/loginEnc.do", getEncPayload({
            P_USER_ID: USER_ID,
            P_USER_PWD: USER_PWD,
            P_APPLICATION_DIV: "3"
        }), onLogin, onLoginError);
    } else {
        $NC.serviceCall("/WC/login.do", {
            P_USER_ID: USER_ID,
            P_USER_PWD: USER_PWD,
            P_APPLICATION_DIV: "3"
        }, onLogin, onLoginError);
    }
}

/**
 * 로그아웃 버튼 클릭 이벤트
 */
function btnLogoutOnClick() {

    if (!confirm($NC.getDisplayMsg("JS.PDA_MAIN.011", "로그아웃 하시겠습니까?"))) {
        return;
    }

    doLogout();
}

/**
 * 로그아웃 처리
 */
function doLogout() {

    $NC.G_VAR.isLogout = true;
    $NC.serviceCall("/WC/logout.do", {
        P_USER_ID: $NC.G_USERINFO.USER_ID
    }, onLogout);
}

function btnTopUserOnClick(e) {

    // 활성화된 화면이 없으면 기본 사용자비밀번호 변경 팝업
    if ($NC.isNull($NC.G_VAR.activeWindow)) {
        showChangeUserPwdPopup(e);
    }
    // 화면이 활성화 되어 있을 경우 기본 정보 변경 레이어
    else {
        window.showDefaultInfoLayer();
    }
}

function btnResetUserPwdOnClick() {

    var USER_ID = $NC.getValue("#edtReset_User_Id");
    var USER_NM = $NC.getValue("#edtReset_User_Nm");
    var USER_EMAIL = $NC.getValue("#edtReset_User_Email");

    if ($NC.isNull(USER_ID)) {
        alert($NC.getDisplayMsg("JS.PDA_MAIN.XXX", "사용자ID를 입력하십시오."));
        $NC.setFocus("#edtReset_User_Id");
        return;
    }

    if ($NC.isNull(USER_NM)) {
        alert($NC.getDisplayMsg("JS.PDA_MAIN.XXX", "사용자명을 입력하십시오."));
        $NC.setFocus("#edtReset_User_Nm");
        return;
    }

    if ($NC.isNull(USER_EMAIL)) {
        alert($NC.getDisplayMsg("JS.PDA_MAIN.XXX", "사용자 이메일을 입력하십시오."));
        $NC.setFocus("#edtReset_User_Email");
        return;
    }

    if (!confirm($NC.getDisplayMsg("JS.PDA_MAIN.XXX", "사용자 비밀번호를 초기화 하시겠습니까?"))) {
        return;
    }

    $NC.serviceCall("/WC/resetUserPwd.do", {
        P_USER_ID: USER_ID,
        P_USER_NM: USER_NM,
        P_USER_EMAIL: USER_EMAIL
    }, onResetUserPwd, onResetUserPwdError, {
        type: 2,
        message: $NC.getDisplayMsg("JS.PDA_MAIN.XXX", "사용자 비밀번호 초기화 중 입니다. 잠시만 기다려 주십시오...")
    });
}

/**
 * 사용자 비밀번호 변경 팝업 호출
 */
function showChangeUserPwdPopup(e) {

    if ($NC.isNull($NC.G_USERINFO)) {
        return;
    }

    var viewLeft, viewTop;
    var viewWidth = 356;
    var viewHeight = 230;
    if ($NC.G_USERINFO.USE_PASSWORD_CHANGE_RULES == $ND.C_YES) {
        viewWidth = 650;
    }
    if ($NC.G_USERINFO.CHANGE_PWD_YN == $ND.C_YES // 
        || $NC.G_USERINFO.ERROR_CHANGE_PWD_YN == $ND.C_YES //
        || $NC.G_USERINFO.CHANGE_PWD_ALERT_YN == $ND.C_YES) {
        viewHeight = 250;
    }

    viewLeft = ($("#ctrClientView").outerWidth(true) - viewWidth) / 2;
    viewTop = ($("#ctrClientView").outerHeight(true) - viewHeight) / 2;

    showSubPopup({
        PROGRAM_ID: "CHANGEUSERPWDPOPUP",
        PROGRAM_NM: $NC.getDisplayMsg("JS.PDA_MAIN.012", "사용자 비밀번호 변경"),
        url: "../popup/changeuserpwdpopup.html",
        G_PARAMETER: {
            P_ENC_PAYLOAD: $NC.G_VAR.isEncPayload ? getEncPayload : null
        },
        left: viewLeft,
        top: viewTop,
        width: viewWidth,
        height: viewHeight,
        onOk: function() {

            // alert($NC.getDisplayMsg("JS.PDA_MAIN.013", "정상적으로 변경되었습니다. 로그인 화면에서 다시 로그인하십시오."));
            $NC.serviceCall("/WC/logout.do", {
                P_USER_ID: $NC.G_USERINFO.USER_ID
            }, function() {
                $NC.G_VAR.isLogout = true;
                onLogout();
            });
        },
        onCancel: function() {
            // 취소시
            // 비밀번호 변경규칙에 의한 비밀번호 변경 대상일 경우
            // 비밀번호 오류에 의한 비밀번호 변경 대상일 경우 로그아웃 함
            if ($NC.G_USERINFO.CHANGE_PWD_YN == $ND.C_YES //
                || $NC.G_USERINFO.ERROR_CHANGE_PWD_YN == $ND.C_YES) {

                // 비밀번호 변경 대상인데 취소하면 로그아웃 처리
                $NC.serviceCall("/WC/logout.do", {
                    P_USER_ID: $NC.G_USERINFO.USER_ID
                }, function() {
                    $NC.G_VAR.isLogout = true;
                    onLogout();
                });
            }
        }
    });
}

/**
 * 사용자 그리드 설정 팝업 호출
 */
function showUserGridLayoutPopup(options) {

    if ($NC.isNull($NC.G_USERINFO)) {
        return;
    }

    showSubPopup({
        PROGRAM_ID: "USERGRIDLAYOUTPOPUP",
        PROGRAM_NM: $NC.getDisplayMsg("JS.MAIN.XXX", "사용자 표시항목 설정"),
        url: "../popup/usergridlayoutpopup.html",
        width: 580,
        height: 600,
        G_PARAMETER: options,
        onOk: function(resultInfo) {
            // 활성 윈도우 검색, 공통팝업은 그리드 설정 불가
            var activeWindow = $NC.G_VAR.activeSubWindow;
            if ($NC.isNull(activeWindow)) {
                activeWindow = $NC.G_VAR.activeWindow;
                if ($NC.isNull(activeWindow)) {
                    return;
                }
            }

            // 화면 재로딩
            setTimeout(function() {
                activeWindow.refresh();
            }, $ND.C_TIMEOUT_ACT);
        }
    });
}

/**
 * 로그인 폼 토글
 */
function toggleLoginForm(e) {

    if ($NC.isVisible(".ctrLoginForm")) {
        $NC.setValue("#edtReset_User_Id");
        $NC.setValue("#edtReset_User_Nm");
        $NC.setValue("#edtReset_User_Email");
        $NC.setVisible(".ctrLoginForm", false);
        $NC.showView(".ctrResetForm", null, function() {
            $NC.setFocus("#edtReset_User_Id");
        }, "slow", "fade");
    } else {
        $NC.setValue("#edtUser_Id");
        $NC.setValue("#edtUser_Pwd");
        $NC.setVisible(".ctrResetForm", false);
        $NC.showView(".ctrLoginForm", null, function() {
            $NC.setFocus("#edtUser_Id");
        }, "slow", "fade");
    }
}

/**
 * 사용자 정보 Load
 */
function getSessionUserInfo() {

    // 데이터 조회
    $("#ctrLoginLayer").data("loginType", 2);
    $NC.serviceCallAndWait("/WC/getSessionUserInfo.do", null, onLogin, function(ajaxData) {
        $("#ctrLoginLayer").data("encSalt", $NC.toObject(ajaxData).RESULT_DATA);
        showLoginPopup(0);
    });
    $("#ctrViewport").hide().css("visibility", "visible").fadeIn(2500);
    $NC.hideLoadingMessage(true);
}

/**
 * 화면 메시지 정보 Load
 * 
 * @param programId
 */
function getProgramMsg(programId) {

    if ($NC.isNotNull($NC.G_LANG[$ND.C_LANG_PROGRAM]) //
        && $NC.G_LANG[$ND.C_LANG_PROGRAM].indexOf(programId) > -1) {
        return;
    }

    $NC.serviceCallAndWait("/WC/getDataSet.do", {
        P_QUERY_ID: "WC.GET_JS_MSG",
        P_QUERY_PARAMS: {
            P_SYS_LANG: $NC.G_USERINFO.SYS_LANG,
            P_PROGRAM_ID: programId
        }
    }, function(ajaxData) {

        // 프로그램 메시지 G_LANG에 세팅
        $NC.setGlobalDisplayInfo(ajaxData, programId);
    });
}

/**
 * 단위화면 실행 로그
 * 
 * @param activityDiv
 * @param programId
 */
function writeProgramActivityLog(activityDiv, programId) {

    if ($NC.G_USERINFO.USE_SECURITY_LOG !== $ND.C_YES) {
        return;
    }

    var activityCd = null;
    var activityComment = null;
    // 프로그램ID가 Null이면 전체 종료
    if ($NC.isNull(programId)) {
        var winCount = $NC.G_VAR.windows.length;
        if (winCount == 0) {
            return;
        }
        if (winCount == 1) {
            activityCd = programId;
        } else {
            var removeProgramIds = [];
            for (var rIndex = 0; rIndex < winCount; rIndex++) {
                removeProgramIds.push($NC.G_VAR.windows[rIndex].get("G_PARAMETER").PROGRAM_ID);
            }
            activityCd = "실행프로그램전체종료";
            activityComment = removeProgramIds.join(", ");
        }
    } else {
        activityCd = programId;
    }

    writeActivityLog(activityDiv, activityComment, activityCd);
}

/**
 * 액티비티 로그 기록
 * 
 * @param activityDiv
 *        "01": 로그인<br>
 *        "02": 로그아웃<br>
 *        "03": 프로그램실행<br>
 *        "04": 프로그램종료<br>
 * @param activityComment
 * @param activityCd
 */
function writeActivityLog(activityDiv, activityComment, activityCd) {

    if ($NC.G_USERINFO.USE_SECURITY_LOG !== $ND.C_YES) {
        return;
    }

    $NC.serviceCallAndWait("/WC/writeActivityLog.do", {
        P_ACTIVITY_CD: activityCd || null,
        P_ACTIVITY_COMMENT: activityComment || null,
        P_ACTIVITY_DIV: $NC.nullToDefault(activityDiv, "01"),
        P_USER_ID: $NC.G_USERINFO.USER_ID
    }, function() {
        // 성공
    }, function() {
        // 실패 메시지 표시 하지 않음
    });
}

/**
 * 공통 버튼 활성화 처리
 */
function setInitTopButtons() {

}

/**
 * 공통 버튼 비활성화 처리
 */
function topButtonsInitialize(disabled) {

}

/**
 * 메뉴 보임/숨김
 */
function showMenu(show, duration) {

    if (show) {
        $NC.hideView("#ctrWindows");
        $NC.showView("#ctrMenuView", null, null, duration || $ND.C_TIMEOUT_ACT, "slide", "left");
    } else {
        $NC.hideView("#ctrMenuView", null, duration || $ND.C_TIMEOUT_ACT, "slide", "left");
        $NC.showView("#ctrWindows");
    }

    var $parent = $(window);
    _OnResize($parent, $parent.width(), $parent.height(), true);
}

/**
 * 메뉴 토글
 */
function toggleMenu() {

    showMenu(!$NC.isVisible("#ctrMenuView"));
    scrollViewToTop();
}

/**
 * 단위 화면 실행<br>
 * 활성 윈도우는 activeWindow로 세팅 됨
 * 
 * @param {Object|String}
 *        programInfo[필수] 실행할 프로그램ID 또는 프로그램 정보<br>
 *        프로그램ID일 경우 메뉴리스트에서 검색해서 프로그램 정보를 참조 함<br>
 * @param {Object}
 *        params[선택] 해당 단위화면에서 사용하기 위한 추가 참조 데이터<br>
 *        화면 전역변수 $NC.G_VAR.G_PARAMETER로 추가 됨
 */
function showProgramPopup(programInfo, params) {

    if ($.type(programInfo) == "string") {
        var programIndex = $NC.getSearchArray($NC.G_VAR.G_PROGRAMMENU, {
            searchKey: "PROGRAM_ID",
            searchVal: programInfo,
            isAllData: true
        });

        if (programIndex == -1) {
            alert($NC.getDisplayMsg("JS.PDA_MAIN.014", "해당 프로그램[" + programInfo + "]을 사용할 권한이 없습니다.", programInfo));
            return;
        }
        programInfo = $NC.G_VAR.G_PROGRAMMENU[programIndex];
    }

    // 메뉴면 아무것도 안함
    if (programInfo.PROGRAM_DIV == "M") {
        return;
    }

    // 기존에 Open한 화면인지 체크
    var containerId = "ctr" + programInfo.PROGRAM_ID;
    var winIndex = getWindowIndex(containerId);
    if (winIndex > -1) {
        var $jWin = $NC.G_VAR.windows[winIndex];
        $NC.G_VAR.windows.splice(winIndex, 1);
        $NC.G_VAR.windows.push($jWin);
        $jWin.focus();
        return;
    }

    // 서버 상태 체크(세션 만료 포함)
    if (!isRunningServer()) {
        return;
    }

    // 프로그램 메시지 읽기
    getProgramMsg(programInfo.PROGRAM_ID);
    // 프로그램 실행 로그 기록
    writeProgramActivityLog("11", programInfo.PROGRAM_ID);

    // 화면 Layout 구성
    var programTitle = programInfo.PROGRAM_NM + " (" + programInfo.PROGRAM_ID + ")";
    // 클라이언트에 추가
    // var $parent = $("#ctrWindows");

    var P_PARAMETER = $.extend({}, params || {}, {
        ROW_ID: programInfo.id,
        PROGRAM_NM: programInfo.PROGRAM_NM,
        PROGRAM_ID: programInfo.PROGRAM_ID,
        WIDE_YN: programInfo.WIDE_YN,
        WEB_URL: programInfo.WEB_URL,
        PROGRAM_DIV: programInfo.PROGRAM_DIV,
        APPLICATION_DIV: programInfo.APPLICATION_DIV || "3",
        EXE_LEVEL1: programInfo.EXE_LEVEL1 || $ND.C_NO,
        EXE_LEVEL2: programInfo.EXE_LEVEL2 || $ND.C_NO,
        EXE_LEVEL3: programInfo.EXE_LEVEL3 || $ND.C_NO,
        EXE_LEVEL4: programInfo.EXE_LEVEL4 || $ND.C_NO,
        EXE_LEVEL5: programInfo.EXE_LEVEL5 || $ND.C_NO
    });

    $NC.hideLoadingMessage(true);
    $NC.showLoadingMessage();
    var childRect = getChildWindowRect();

    var $newJWindow = $.jWindow({
        parentElement: "#ctrWindows",
        id: containerId,
        title: programTitle,
        G_PARAMETER: P_PARAMETER,
        animationDuration: 200,
        posx: childRect.left,
        posy: childRect.top,
        minWidth: childRect.minWidth,
        minHeight: childRect.minHeight,
        width: childRect.width,
        height: childRect.height,
        windowType: 1,
        contentAttr: (P_PARAMETER.PROGRAM_DIV || "").toLowerCase(),
        type: "iframe",
        fixed: false,
        url: $.browser.urlPrefix + $NC.G_VAR.baseUrl + programInfo.WEB_URL,
        refreshButton: true,
        minimiseButton: false,
        maximiseButton: false,
        closeButton: !$.browser.mobile, // false
        containment: true,
        draggable: false,
        resizeable: false,
        windowBorder: false,
        onRefreshing: function($jWindow) {
            // 서버 상태 체크(세션 만료 포함)
            return isRunningServer();
        },
        onClosing: function($jWindow) {
            if ($jWindow) {
                var contentWindow = $NC.getChildWindow($jWindow);
                if ($.isFunction(contentWindow._OnClose)) {
                    return contentWindow._OnClose();
                }
            }
            return true;
        },
        onClose: function($jWindow) {
            if ($jWindow) {
                // 프로그램 실행 로그 기록
                var G_PARAMETER = $jWindow.get("G_PARAMETER");
                writeProgramActivityLog("12", G_PARAMETER.PROGRAM_ID);

                // 화면 목록에서 제거
                removeChildWindow($jWindow);
            }
        },
        onFocus: function($jWindow) {
            // 메뉴에서 해당 화면 선택
            if ($NC.G_VAR.activeWindow != null) {
                $NC.G_VAR.activeWindow.getContainerNode().hide();
            }
            $NC.G_VAR.activeWindow = $jWindow;
            $NC.G_VAR.lastWindow = $jWindow;
            // var G_PARAMETER = $jWindow.get("G_PARAMETER");

            showMenu(false);
            scrollViewToTop();
            setInitTopButtons();
            resizeActiveChildWindow();
            $NC.G_VAR.activeWindow.getContainerNode().show();

            var contentWindow = $NC.getChildWindow($jWindow);
            if ($.isFunction(contentWindow._OnWindowFocus)) { // @Deprecated 명칭 변경 _OnWindowFocus -> _OnFocus
                contentWindow._OnWindowFocus();
            } else if ($.isFunction(contentWindow._OnFocus)) {
                contentWindow._OnFocus();
            }
        }
    });

    // 해당 화면 목록에 추가
    $NC.G_VAR.windows.push($newJWindow);
    $newJWindow.update();
    $newJWindow.show({
        complete: function() {
            setTimeout(function() {
                var contentWindow = $NC.getChildWindow($newJWindow);
                if ($.isFunction(contentWindow._OnWindowFocus)) { // @Deprecated 명칭 변경 _OnWindowFocus -> _OnFocus
                    contentWindow._OnWindowFocus();
                } else if ($.isFunction(contentWindow._OnFocus)) {
                    contentWindow._OnFocus();
                }
            }, $NC.G_VAR.TIMEOUT_OPEN_FOCUS);
        }
    });
}

/**
 * 공통 코드검색 팝업 창 표시<br>
 * 활성 윈도우는 activePopupWindow로 세팅 됨
 */
function showCommonPopup(options) {

    // 서버 상태 체크(세션 만료 포함)
    if (!isRunningServer()) {
        return;
    }

    if ($NC.isNull(options.containerId) || $NC.isNull(options.queryId)) {
        return;
    }

    options.PROGRAM_ID = "COMMONPOPUP";
    options.PROGRAM_NM = $NC.getDisplayMsg("JS.PDA_MAIN.015", "공통팝업");
    options.APPLICATION_DIV = "3";
    options.CLOSE_ACTION = $ND.C_CANCEL;

    if ($NC.isNull(options.title)) {
        options.title = $NC.getDisplayMsg("JS.PDA_MAIN.016", "코드 검색");
    }
    if ($NC.isNull(options.url)) {
        options.url = $.browser.urlPrefix + $NC.G_VAR.baseUrl + "../popup/commonpopup.html";
    }

    var parentElement = "#ctrWindows";
    // 모바일 화면은 지정된 사이즈 사용안함
    // 최대 화면으로 고정
    // var $parent = $(parentElement);
    // var parentOffset = $parent.offset();
    var parentOffset = {
        left: 0,
        // 모달로 표시, 상단 타이틀바 하단
        top: $NC.G_OFFSET.nonClientHeight
    };
    var childRect = getChildWindowRect();

    var $newJWindow = $.jWindow({
        parentElement: parentElement,
        id: options.containerId,
        title: options.title,
        G_PARAMETER: options,
        animationDuration: 200,
        posx: parentOffset.left,
        posy: parentOffset.top,
        minWidth: childRect.minWidth,
        minHeight: childRect.minHeight,
        width: childRect.width, // + $NC.G_CHILDLAYOUT.nonClientWidth,
        height: childRect.height, // + $NC.G_CHILDLAYOUT.nonClientWidth,
        windowType: 3,
        contentAttr: "c",
        type: "iframe",
        fixed: false,
        url: options.url,
        refreshButton: true,
        minimiseButton: false,
        maximiseButton: false,
        closeButton: !$.browser.mobile, // true,
        containment: true,
        draggable: false,
        resizeable: false,
        windowBorder: false,
        modal: true,
        onRefreshing: function($jWindow) {
            // 서버 상태 체크(세션 만료 포함)
            return isRunningServer();
        },
        onClosing: function($jWindow) {
            if ($jWindow) {
                var contentWindow = $NC.getChildWindow($jWindow);
                if ($.isFunction(contentWindow._OnClose)) {
                    return contentWindow._OnClose();
                }
            }
            return true;
        },
        onClose: function($jWindow) {
            if ($jWindow) {
                var G_PARAMETER = $jWindow.get("G_PARAMETER");
                if ($.isFunction(G_PARAMETER.onClose)) {
                    G_PARAMETER.onClose();
                }

                var resultInfo = G_PARAMETER.RESULT_INFO;
                if (resultInfo) {
                    if ($.type(resultInfo) == "object") {
                        if (Array.isArray(resultInfo)) {
                            resultInfo = $.extend(true, [], resultInfo);
                        } else {
                            resultInfo = $.extend(true, {}, resultInfo);
                        }
                    }
                }

                // 팝업 CloseAction이 OK 일 경우
                if (G_PARAMETER.CLOSE_ACTION == $ND.C_OK) {
                    if ($.isFunction(options.onSelect)) {
                        options.onSelect(resultInfo);
                    }
                }
                // 팝업 CloseAction이 CANCEL 일 경우
                else if ($.isFunction(options.onCancel)) {
                    options.onCancel(resultInfo);
                }
            }

            // 팝업 제거
            setTimeout(function() {
                if ($jWindow) {
                    removePopupWindow($jWindow);
                }
                setFocusActiveWindow();
            }, $ND.C_TIMEOUT_ACT_FAST);
        },
        onFocus: function($jWindow) {
            $NC.G_VAR.activePopupWindow = $jWindow;
            $NC.G_VAR.lastWindow = $jWindow;
            showMenu(false);

            var contentWindow = $NC.getChildWindow($jWindow);
            if ($.isFunction(contentWindow._OnWindowFocus)) { // @Deprecated 명칭 변경 _OnWindowFocus -> _OnFocus
                contentWindow._OnWindowFocus();
            } else if ($.isFunction(contentWindow._OnFocus)) {
                contentWindow._OnFocus();
            }
        }
    });

    $newJWindow.update();
    $newJWindow.show({
        duration: 200,
        complete: function() {
            if ($.browser.mobile) {
                $newJWindow.getDomNodes().modalBackground.css("overflow", "auto");
            }

            setTimeout(function() {
                var contentWindow = $NC.getChildWindow($newJWindow);
                if ($.isFunction(contentWindow._OnWindowFocus)) { // @Deprecated 명칭 변경 _OnWindowFocus -> _OnFocus
                    contentWindow._OnWindowFocus();
                } else if ($.isFunction(contentWindow._OnFocus)) {
                    contentWindow._OnFocus();
                }
            }, $NC.G_VAR.TIMEOUT_OPEN_FOCUS);
        }
    });
}

/**
 * 메시지 표시
 * 
 * @param options
 *        <br>
 *        String: 메시지<br>
 *        Object: <br>
 *        title[선택]: 기본값 -> 확인<br>
 *        message[필수]: 메시지<br>
 *        width, height[선택]: 메시지박스 크기<br>
 *        buttons[선택]: 기본값 -> 확인 버튼, {"예": function() { ... }, "아니오": function () { ... }}<br>
 *        hideFocus[선택]: 기본 버튼에 포커스 지정 여부, 기본값 true<br>
 *        onDialogOpen: 메시지박스 오픈시 호출되는 Event<br>
 *        autoCloseDelayTime[선택]: 지정시 지정된 시간 이후 자동으로 닫힘, 기본값 미지정
 */
function showMessage(options) {

    if ($NC.isNull(options)) {
        return;
    }

    if ($.type(options) == "string") {
        options = {
            message: options
        };
    }

    if ($NC.isNull(options.message)) {
        return;
    }

    var $ctrPopupMessageLayer = $("#ctrPopupMessageLayer");
    if ($NC.isDialogOpen($ctrPopupMessageLayer)) {
        $ctrPopupMessageLayer.dialog("close");
    }

    var buttons;
    if ($NC.isNull(options.buttons)) {
        buttons = {
            "확인": function() {
                $(this).dialog("close");
            }
        };
    } else {
        buttons = {};
        for ( var button in options.buttons) {
            buttons[button] = function(e) {
                var target = $(e.target).text();
                var onClick = options.buttons[target];
                $(this).dialog("close");
                if ($.isFunction(onClick)) {
                    onClick();
                }
            };
        }
    }

    var hideFocus = options.hideFocus || false;
    var onDialogOpen = options.onDialogOpen;
    var autoCloseDelayTime = options.autoCloseDelayTime;

    $ctrPopupMessageLayer.dialog({
        autoOpen: false,
        modal: true,
        minWidth: 250,
        minHeight: 100,
        title: options.title ? options.title : $NC.getDisplayMsg("JS.PDA_MAIN.018", "확인"),
        width: options.width ? options.width : 350,
        height: options.height ? options.height : 150,
        draggable: true,
        resizable: false,
        closeOnEscape: false,
        create: function(event, ui) {
            var dlgInstance = $(this).dialog("instance");
            dlgInstance.uiDialogTitlebar.css({
                "padding": "5px",
                "cursor": "default",
                "border-width": "0"
            });
            dlgInstance.uiDialogTitlebarClose.css({
                "width": "30px",
                "height": "20px"
            });
            dlgInstance.uiDialog.css({
                "zIndex": 1301,
                "padding": "1px"
            });
        },
        open: function() {
            var $view = $(this).text("");
            var dlgInstance = $view.dialog("instance");
            dlgInstance.overlay.css("zIndex", 1300);

            var $ifmMessage = $("<iframe id='ifmMessage' name='ifmMessage' style='width: " //
                + $view.width() + "px; height: " + ($view.height() - 3) //
                + "px; border: none;' src='about:blank'></iframe>");
            $ifmMessage.appendTo($view);
            var $messageDoc = $($ifmMessage.get(0).contentDocument);
            if (options.message.toLowerCase().indexOf("<html") > -1) {
                $messageDoc.get(0).write(options.message);
            } else {
                $messageDoc.find("body").css({
                    "padding": 0,
                    "margin": 0,
                    "font-famally": "GulimChe, 'Lucida Grande', 'Lucida Sans', Arial, sans-serif",
                    "font-size": "12px",
                    "font-weight": "bold",
                    "color": "#222222"
                }).html(options.message.replace(/\n|\r/gi, "<br>"));
            }
            $ifmMessage.hide().show();
            // $view.html(options.message.replace(/\n|\r/gi, "<br>"));
            dlgInstance.uiButtonSet.find(".ui-button").width(80);
            if ($NC.isNotNull(buttons)) {
                dlgInstance.uiDialogTitlebarClose.hide();
            }
            if (hideFocus) {
                $view.focus();
            } else if (Object.keys(buttons).length == 1) {
                dlgInstance.uiButtonSet.find(".ui-button").focus();
            }
            if ($.isFunction(onDialogOpen)) {
                onDialogOpen();
            }
            if (!$NC.isNull(autoCloseDelayTime)) {
                setTimeout(function() {
                    // 첫번째 버튼 클릭으로 자동 닫기 처리, 사용자가 닫지 않았을 경우
                    var $dialog = $view.dialog("instance");
                    if (!$NC.isNull($dialog)) {
                        $dialog.uiButtonSet.find(".ui-button:first").click();
                    }
                }, autoCloseDelayTime);
            }
        },
        close: function(event, ui) {
            var $view = $(this);
            $view.dialog("option", "title", "");
            $view.dialog("destroy");
            $view.css("display", "none");
        },
        buttons: buttons
    });
    setTimeout(function() {
        $ctrPopupMessageLayer.dialog("open");
    }, $ND.C_TIMEOUT_ACT_FAST);
}

/**
 * 단위화면에서 팝업화면 표시<br>
 * 활성 윈도우는 activeSubWindow로 세팅 됨
 * 
 * @param {Object}
 *        options<br>
 *        [String]PROGRAM_ID[필수]: 프로그램ID<br>
 *        [String]PROGRAM_NM[필수]: 프로그램명<br>
 *        [Object]G_PARAMETER[선택]: 해당 팝업화면에서 사용하기 위한 추가 참조 데이터<br>
 *        화면 전역변수 $NC.G_VAR.G_PARAMETER로 추가 됨<br>
 *        <b>PROGRAM_ID, PROGRAM_NM, CLOSE_ACTION, RESULT_INFO</b>는 내부적으로 사용하므로 해당 명칭 사용 금지, overwrite 처리 됨<br>
 *        [String]url[필수]: html url<br>
 *        [String]containerId[옵션]: 컨테이너ID(containerId)의 명칭 접두어는 ctr로 지정, 미지정시 "ctr" + options.PROGRAM_ID<br>
 *        [String]title[옵션]: 팝업창 제목, 미지정시 PROGRAM_NM + " (" + PROGRAM_ID + ")"<br>
 *        [Number]width[옵션]: 팝업창 너비<br>
 *        [Number]height[옵션]: 팝업창 높이<br>
 *        [Boolean]resizeable[옵션]: 팝업창 사이즈 조절 가능여부, 기본 True<br>
 *        [Boolean]skipServiceCall[옵션]: 서비스호출 처리하지 않음, 기본 False, since 7.0.0<br>
 *        [Function]onOk[옵션]: 확인 버튼 Click Callback Event<br>
 *        [Function]onCancel[옵션]: 취소, 닫기 버튼 Click Callback Event<br>
 */
function showProgramSubPopup(options) {

    if ($NC.isNull(options.skipServiceCall)) {
        options.skipServiceCall = false;
    }
    if (!options.skipServiceCall) {

        // 서버 상태 체크(세션 만료 포함)
        if (!isRunningServer()) {
            return;
        }

        // 프로그램 메시지 읽기
        getProgramMsg(options.PROGRAM_ID);
        // 프로그램 실행 로그 기록
        writeProgramActivityLog("11", options.PROGRAM_ID);
    }

    if ($NC.isNull(options.containerId)) {
        options.containerId = "ctr" + options.PROGRAM_ID;
    }
    if ($NC.isNull(options.title)) {
        options.title = options.PROGRAM_NM + " (" + options.PROGRAM_ID + ")";
    }
    if ($NC.isNull(options.resizeable)) {
        options.resizeable = true;
    }

    if ($NC.isNull(options.G_PARAMETER)) {
        options.G_PARAMETER = {};
    }
    options.G_PARAMETER.CLOSE_ACTION = $ND.C_CANCEL;
    options.G_PARAMETER.PROGRAM_ID = options.PROGRAM_ID;
    options.G_PARAMETER.PROGRAM_NM = options.PROGRAM_NM;
    options.G_PARAMETER.APPLICATION_DIV = "3";

    var parentElement = "#ctrWindows";
    // 모바일 화면은 지정된 사이즈 사용안함
    // 최대 화면으로 고정
    // var $parent = $(parentElement);
    // var parentOffset = $parent.offset();
    var parentOffset = {
        left: 0,
        // 모달로 표시, 상단 타이틀바 하단
        top: $NC.G_OFFSET.nonClientHeight
    };
    var childRect = getChildWindowRect();

    var $newJWindow = $.jWindow({
        parentElement: parentElement,
        id: options.containerId,
        title: options.title,
        G_PARAMETER: options.G_PARAMETER,
        animationDuration: 200,
        posx: parentOffset.left,
        posy: parentOffset.top,
        minWidth: childRect.minWidth,
        minHeight: childRect.minHeight,
        width: childRect.width, // + $NC.G_CHILDLAYOUT.nonClientWidth,
        height: childRect.height, // + $NC.G_CHILDLAYOUT.nonClientWidth,
        windowType: 2,
        contentAttr: "p",
        type: "iframe",
        fixed: false,
        url: $.browser.urlPrefix + $NC.G_VAR.baseUrl + options.url,
        refreshButton: true,
        minimiseButton: false,
        maximiseButton: false,
        closeButton: !$.browser.mobile, // false,
        containment: true,
        draggable: false,
        resizeable: false,
        windowBorder: false,
        modal: true,
        onRefreshing: function($jWindow) {
            // 서버 상태 체크(세션 만료 포함)
            return isRunningServer();
        },
        onClosing: function($jWindow) {
            if ($jWindow) {
                var contentWindow = $NC.getChildWindow($jWindow);
                if ($.isFunction(contentWindow._OnClose)) {
                    return contentWindow._OnClose();
                }
            }
            return true;
        },
        onClose: function($jWindow) {
            if ($jWindow) {
                // X 버튼으로 Close시 onCancel 호출
                var G_PARAMETER = $jWindow.get("G_PARAMETER");
                if (!options.skipServiceCall) {
                    // 프로그램 실행 로그 기록
                    writeProgramActivityLog("12", G_PARAMETER.PROGRAM_ID);
                }

                var resultInfo = G_PARAMETER.RESULT_INFO;
                if (resultInfo) {
                    if ($.type(resultInfo) == "object") {
                        if (Array.isArray(resultInfo)) {
                            resultInfo = $.extend(true, [], resultInfo);
                        } else {
                            resultInfo = $.extend(true, {}, resultInfo);
                        }
                    }
                }

                // 팝업 CloseAction이 OK 일 경우
                if (G_PARAMETER.CLOSE_ACTION == $ND.C_OK) {
                    if ($.isFunction(options.onOk)) {
                        options.onOk(resultInfo);
                    }
                }
                // 팝업 CloseAction이 CANCEL 일 경우
                else if ($.isFunction(options.onCancel)) {
                    options.onCancel(resultInfo);
                }
            }

            // 팝업 제거
            setTimeout(function() {
                if ($jWindow) {
                    removePopupWindow($jWindow);
                }
                setFocusActiveWindow();
            }, $ND.C_TIMEOUT_ACT_FAST);
        },
        onFocus: function($jWindow) {
            $NC.G_VAR.activeSubWindow = $jWindow;
            $NC.G_VAR.lastWindow = $jWindow;
            showMenu(false);

            var contentWindow = $NC.getChildWindow($jWindow);
            if ($.isFunction(contentWindow._OnWindowFocus)) { // @Deprecated 명칭 변경 _OnWindowFocus -> _OnFocus
                contentWindow._OnWindowFocus();
            } else if ($.isFunction(contentWindow._OnFocus)) {
                contentWindow._OnFocus();
            }
        }
    });

    $newJWindow.update();
    $newJWindow.show({
        duration: 200,
        complete: function() {
            if ($.browser.mobile) {
                $newJWindow.getDomNodes().modalBackground.css("overflow", "auto");
            }

            setTimeout(function() {
                var contentWindow = $NC.getChildWindow($newJWindow);
                if ($.isFunction(contentWindow._OnWindowFocus)) { // @Deprecated 명칭 변경 _OnWindowFocus -> _OnFocus
                    contentWindow._OnWindowFocus();
                } else if ($.isFunction(contentWindow._OnFocus)) {
                    contentWindow._OnFocus();
                }
            }, $NC.G_VAR.TIMEOUT_OPEN_FOCUS);
        }
    });
}

/**
 * 팝업화면 표시<br>
 * 활성 윈도우는 activePopupWindow로 세팅 됨
 * 
 * @param {Object}
 *        options<br>
 *        [String]PROGRAM_ID[필수]: 프로그램ID<br>
 *        [String]PROGRAM_NM[필수]: 프로그램명<br>
 *        [Object]G_PARAMETER[선택]: 해당 팝업화면에서 사용하기 위한 추가 참조 데이터<br>
 *        화면 전역변수 $NC.G_VAR.G_PARAMETER로 추가 됨<br>
 *        <b>PROGRAM_ID, PROGRAM_NM, CLOSE_ACTION, RESULT_INFO</b>는 내부적으로 사용하므로 해당 명칭 사용 금지, overwrite 처리 됨<br>
 *        [String]url[필수]: html url<br>
 *        [String]containerId[옵션]: 컨테이너ID(containerId)의 명칭 접두어는 ctr로 지정, 미지정시 "ctr" + options.PROGRAM_ID<br>
 *        [String]title[옵션]: 팝업창 제목, 미지정시 PROGRAM_NM + " (" + PROGRAM_ID + ")"<br>
 *        [Number]width[옵션]: 팝업창 너비<br>
 *        [Number]height[옵션]: 팝업창 높이<br>
 *        [Boolean]resizeable[옵션]: 팝업창 사이즈 조절 가능여부, 기본 True<br>
 *        [Boolean]skipServiceCall[옵션]: 서비스호출 처리하지 않음, 기본 False, since 7.0.0<br>
 *        [Function]onOk[옵션]: 확인 버튼 Click Callback Event<br>
 *        [Function]onCancel[옵션]: 취소, 닫기 버튼 Click Callback Event<br>
 */
function showSubPopup(options) {

    if ($NC.isNull(options.skipServiceCall)) {
        options.skipServiceCall = false;
    }
    if (!options.skipServiceCall) {

        // 서버 상태 체크(세션 만료 포함)
        if (!isRunningServer()) {
            return;
        }

        // 프로그램 메시지 읽기
        getProgramMsg(options.PROGRAM_ID);
        // 프로그램 실행 로그 기록
        writeProgramActivityLog("11", options.PROGRAM_ID);
    }

    if ($NC.isNull(options.containerId)) {
        options.containerId = "ctr" + options.PROGRAM_ID;
    }
    if ($NC.isNull(options.title)) {
        options.title = options.PROGRAM_NM + " (" + options.PROGRAM_ID + ")";
    }
    if ($NC.isNull(options.resizeable)) {
        options.resizeable = true;
    }

    if ($NC.isNull(options.G_PARAMETER)) {
        options.G_PARAMETER = {};
    }
    options.G_PARAMETER.CLOSE_ACTION = $ND.C_CANCEL;
    options.G_PARAMETER.PROGRAM_ID = options.PROGRAM_ID;
    options.G_PARAMETER.PROGRAM_NM = options.PROGRAM_NM;
    options.G_PARAMETER.APPLICATION_DIV = "3";

    var parentElement = "#ctrWindows";
    // 모바일 화면은 지정된 사이즈 사용안함
    // 최대 화면으로 고정
    // var $parent = $(parentElement);
    // var parentOffset = $parent.offset();
    var parentOffset = {
        left: 0,
        // 모달로 표시, 상단 타이틀바 하단
        top: $NC.G_OFFSET.nonClientHeight
    };
    var childRect = getChildWindowRect();

    var $newJWindow = $.jWindow({
        parentElement: parentElement,
        id: options.containerId,
        title: options.title,
        G_PARAMETER: options.G_PARAMETER,
        animationDuration: 200,
        posx: parentOffset.left,
        posy: parentOffset.top,
        minWidth: childRect.minWidth,
        minHeight: childRect.minHeight,
        width: childRect.width, // + $NC.G_CHILDLAYOUT.nonClientWidth,
        height: childRect.height, // + $NC.G_CHILDLAYOUT.nonClientWidth,
        windowType: 3,
        contentAttr: "p",
        type: "iframe",
        fixed: false,
        url: $.browser.urlPrefix + $NC.G_VAR.baseUrl + options.url,
        refreshButton: true,
        minimiseButton: false,
        maximiseButton: false,
        closeButton: !$.browser.mobile, // false,
        containment: true,
        draggable: false,
        resizeable: false,
        windowBorder: false,
        modal: true,
        onRefreshing: function($jWindow) {
            // 서버 상태 체크(세션 만료 포함)
            return isRunningServer();
        },
        onClosing: function($jWindow) {
            if ($jWindow) {
                var contentWindow = $NC.getChildWindow($jWindow);
                if ($.isFunction(contentWindow._OnClose)) {
                    return contentWindow._OnClose();
                }
            }
            return true;
        },
        onClose: function($jWindow) {
            if ($jWindow) {
                // X 버튼으로 Close시 onCancel 호출
                var G_PARAMETER = $jWindow.get("G_PARAMETER");
                if (!options.skipServiceCall) {
                    // 프로그램 실행 로그 기록
                    writeProgramActivityLog("12", G_PARAMETER.PROGRAM_ID);
                }

                var resultInfo = G_PARAMETER.RESULT_INFO;
                if (resultInfo) {
                    if ($.type(resultInfo) == "object") {
                        if (Array.isArray(resultInfo)) {
                            resultInfo = $.extend(true, [], resultInfo);
                        } else {
                            resultInfo = $.extend(true, {}, resultInfo);
                        }
                    }
                }

                // 팝업 CloseAction이 OK 일 경우
                if (G_PARAMETER.CLOSE_ACTION == $ND.C_OK) {
                    if ($.isFunction(options.onOk)) {
                        options.onOk(resultInfo);
                    }
                }
                // 팝업 CloseAction이 CANCEL 일 경우
                else if ($.isFunction(options.onCancel)) {
                    options.onCancel(resultInfo);
                }
            }

            // 팝업 제거
            setTimeout(function() {
                if ($jWindow) {
                    removePopupWindow($jWindow);
                }
                setFocusActiveWindow();
            }, $ND.C_TIMEOUT_ACT_FAST);
        },
        onFocus: function($jWindow) {
            $NC.G_VAR.activePopupWindow = $jWindow;
            $NC.G_VAR.lastWindow = $jWindow;
            showMenu(false);

            var contentWindow = $NC.getChildWindow($jWindow);
            if ($.isFunction(contentWindow._OnWindowFocus)) { // @Deprecated 명칭 변경 _OnWindowFocus -> _OnFocus
                contentWindow._OnWindowFocus();
            } else if ($.isFunction(contentWindow._OnFocus)) {
                contentWindow._OnFocus();
            }
        }
    });

    $newJWindow.update();
    $newJWindow.show({
        duration: 200,
        complete: function() {
            if ($.browser.mobile) {
                $newJWindow.getDomNodes().modalBackground.css("overflow", "auto");
            }

            setTimeout(function() {
                var contentWindow = $NC.getChildWindow($newJWindow);
                if ($.isFunction(contentWindow._OnWindowFocus)) { // @Deprecated 명칭 변경 _OnWindowFocus -> _OnFocus
                    contentWindow._OnWindowFocus();
                } else if ($.isFunction(contentWindow._OnFocus)) {
                    contentWindow._OnFocus();
                }
            }, $NC.G_VAR.TIMEOUT_OPEN_FOCUS);
        }
    });
}

/**
 * 출력 미리보기 표시<br>
 * 활성 윈도우는 activePopupWindow로 세팅 됨
 * 
 * @param options
 *        title: 미리보기 팝업창 제목, 기본값 "미리보기"<br>
 *        url: 미리보기 팝업 주소, 기본값 previewpopup<br>
 *        reportDoc: Report 파일<br>
 *        queryId: 쿼리ID<br>
 *        queryParams: 쿼리 파라메터<br>
 *        checkedValue: 선택 값<br>
 *        internalQueryYn: Report 내부 쿼리 사용여부, 기본값 "N"<br>
 *        printCopy: 출력매수, 기본값 1<br>
 *        onAfterPrint: 출력 후 호출할 Callback Function, 출력 여부를 알 수 없으므로 팝업 창을 닫을 시 호출 됨
 */
function showPrintPreview(options) {

    // 서버 상태 체크(세션 만료 포함)
    if (!isRunningServer()) {
        return;
    }

    if ($NC.isNull(options.containerId)) {
        options.containerId = "ctrCommonPopupPrintPreview";
    }
    if ($NC.isNull(options.title)) {
        options.title = $NC.getDisplayMsg("JS.PDA_MAIN.019", "출력 미리보기");
    }
    if ($NC.isNull(options.url)) {
        options.url = $.browser.urlPrefix + $NC.G_VAR.baseUrl + "../popup/previewpopup.html";
    } else {
        options.url = $.browser.urlPrefix + $NC.G_VAR.baseUrl + options.url;
    }

    options.CLOSE_ACTION = $ND.C_CANCEL;

    var parentElement = "#ctrWindows";
    // 모바일 화면은 지정된 사이즈 사용안함
    // 최대 화면으로 고정
    // var $parent = $(parentElement);
    // var parentOffset = $parent.offset();
    var parentOffset = {
        left: 0,
        // 모달로 표시, 상단 타이틀바 하단
        top: $NC.G_OFFSET.nonClientHeight
    };
    var childRect = getChildWindowRect();

    var $newJWindow = $.jWindow({
        parentElement: parentElement,
        id: options.containerId,
        title: options.title,
        G_PARAMETER: options,
        animationDuration: 200,
        posx: parentOffset.left,
        posy: parentOffset.top,
        minWidth: childRect.minWidth,
        minHeight: childRect.minHeight,
        width: childRect.width, // + $NC.G_CHILDLAYOUT.nonClientWidth,
        height: childRect.height, // + $NC.G_CHILDLAYOUT.nonClientWidth,
        windowType: 3,
        contentAttr: "r",
        type: "iframe",
        fixed: false,
        url: options.url,
        refreshButton: false,
        minimiseButton: false,
        maximiseButton: false,
        closeButton: !$.browser.mobile, // true,
        containment: true,
        resizeable: false,
        draggable: false,
        modal: true,
        onRefreshing: function($jWindow) {
            // 서버 상태 체크(세션 만료 포함)
            return isRunningServer();
        },
        onClosing: function($jWindow) {
            if ($jWindow) {
                var contentWindow = $NC.getChildWindow($jWindow);
                if ($.isFunction(contentWindow._OnClose)) {
                    return contentWindow._OnClose();
                }
            }
            return true;
        },
        onClose: function($jWindow) {
            // 팝업 제거
            setTimeout(function() {
                if ($jWindow) {
                    removePopupWindow($jWindow);
                }
                setFocusActiveWindow();
            }, $ND.C_TIMEOUT_ACT_FAST);
        },
        onFocus: function($jWindow) {
            $NC.G_VAR.activePopupWindow = $jWindow;
            $NC.G_VAR.lastWindow = $jWindow;
            showMenu(false);

            var contentWindow = $NC.getChildWindow($jWindow);
            if ($.isFunction(contentWindow._OnWindowFocus)) { // @Deprecated 명칭 변경 _OnWindowFocus -> _OnFocus
                contentWindow._OnWindowFocus();
            } else if ($.isFunction(contentWindow._OnFocus)) {
                contentWindow._OnFocus();
            }
        }
    });
    $newJWindow.update();
    $newJWindow.show({
        complete: function() {
            if ($.browser.mobile) {
                $newJWindow.getDomNodes().modalBackground.css("overflow", "auto");
            }

            setTimeout(function() {
                var contentWindow = $NC.getChildWindow($newJWindow);
                if ($.isFunction(contentWindow._OnWindowFocus)) { // @Deprecated 명칭 변경 _OnWindowFocus -> _OnFocus
                    contentWindow._OnWindowFocus();
                } else if ($.isFunction(contentWindow._OnFocus)) {
                    contentWindow._OnFocus();
                }
            }, $NC.G_VAR.TIMEOUT_OPEN_FOCUS);
        }
    });
}

function showDeveloperPopup(e) {

    if ((e.ctrlKey || e.metaKey) && e.altKey && e.shiftKey) {
        showSubPopup({
            PROGRAM_ID: "DEVELOPERPOPUP",
            PROGRAM_NM: $NC.getDisplayMsg("JS.PDA_MAIN.020", "개발자 메뉴"),
            url: "../popup/developerpopup.html",
            width: 500,
            height: 345
        });
    }
}

function getChildWindowRect() {

    return {
        left: 0,
        top: 0,
        minWidth: $NC.G_CHILDLAYOUT.minWidth - $NC.G_CHILDLAYOUT.nonClientWidth,
        minHeight: $NC.G_CHILDLAYOUT.minHeight - $NC.G_CHILDLAYOUT.nonClientHeight,
        width: $NC.G_CHILDLAYOUT.width,
        height: $NC.G_CHILDLAYOUT.height - $NC.G_CHILDLAYOUT.nonClientHeight
    };
}

/**
 * 실행된 단위 화면 전체 사이즈 조정
 */
function resizeChildWindows() {

    // 실행 중인 단위 화면 사이즈 조정
    var childRect = getChildWindowRect();
    childRect = {
        posx: childRect.left,
        posy: childRect.top,
        // minWidth: childRect.minWidth,
        // minHeight: childRect.minHeight,
        width: childRect.width,
        height: childRect.height
    };

    // 현재 활성 윈도우 위치 조정
    var childObject, $overlay;
    if ($NC.G_VAR.activeWindow != null) {
        $NC.G_VAR.activeWindow.set(childRect);
        // 내부 팝업 Overlay 위치 조정
        childObject = $NC.getChildObject($NC.G_VAR.activeWindow);
        if (childObject.isValid && childObject.$) {
            $overlay = childObject.$(childObject.document).find(".hasOverlayPopup");
            if ($NC.isVisible($overlay)) {
                $overlay.triggerHandler("overlayResize");
            }
        }
    }

    // 현재 활성 팝업 윈도우 위치 조정
    var posx, posy;
    if ($NC.G_VAR.activeSubWindow != null) {
        posx = $NC.G_VAR.activeSubWindow.get("posx");
        posy = $NC.G_VAR.activeSubWindow.get("posy");
        $NC.G_VAR.activeSubWindow.set({
            posx: posx,
            posy: posy,
            width: childRect.width,
            height: childRect.height
        });
        // 내부 팝업 Overlay 위치 조정
        childObject = $NC.getChildObject($NC.G_VAR.activeSubWindow);
        if (childObject.isValid && childObject.$) {
            $overlay = childObject.$(childObject.document).find(".hasOverlayPopup");
            if ($NC.isVisible($overlay)) {
                $overlay.triggerHandler("overlayResize");
            }
        }
    }

    // 현재 활성 공통 팝업 윈도우 위치 조정
    if ($NC.G_VAR.activePopupWindow != null) {
        posx = $NC.G_VAR.activePopupWindow.get("posx");
        posy = $NC.G_VAR.activePopupWindow.get("posy");
        $NC.G_VAR.activePopupWindow.set({
            posx: posx,
            posy: posy,
            width: childRect.width,
            height: childRect.height
        });
    }
}

/**
 * 실행된 단위 화면 사이즈 조정
 */
function resizeActiveChildWindow() {

    // 활성화된 화면만 리사이즈
    if ($NC.G_VAR.activeWindow == null) {
        return;
    }

    // 실행 중인 단위 화면 사이즈 조정
    var childRect = getChildWindowRect();
    $NC.G_VAR.activeWindow.set({
        posx: childRect.left,
        posy: childRect.top,
        // minWidth: childRect.minWidth,
        // minHeight: childRect.minHeight,
        width: childRect.width,
        height: childRect.height
    });

    $NC.onGlobalResize();
}

/**
 * 실행된 팝업 화면을 목록에서 제거
 */
function removePopupWindow($jWindow) {

    if ($NC.isNotNull($NC.G_VAR.activePopupWindow)) {
        $NC.G_VAR.activePopupWindow = null;
    } else if ($NC.isNotNull($NC.G_VAR.activeSubWindow)) {
        $NC.G_VAR.activeSubWindow = null;
    }
    $NC.G_VAR.lastWindow = null;

    if ($jWindow == null) {
        return;
    }

    var removeWindowId = $jWindow.get("id");
    $jWindow.update(null);
    $jWindow.removeWindow();
    delete $jWindow;
    $("#" + removeWindowId).remove();

    if ($NC.isNotNull($NC.G_VAR.activeSubWindow)) {
        $NC.G_VAR.activeSubWindow.focus();
        return;
    }

    if ($NC.isNotNull($NC.G_VAR.activeWindow)) {
        $NC.G_VAR.activeWindow.focus();
        return;
    }
}

/**
 * 실행된 단위 화면을 목록에서 제거
 */
function removeChildWindow($jWindow) {

    $NC.G_VAR.activeWindow = null;
    $NC.G_VAR.lastWindow = null;
    if ($jWindow == null) {
        return;
    }

    var removeWindowId = $jWindow.get("id");
    for (var rIndex = 0, rCount = $NC.G_VAR.windows.length; rIndex < rCount; rIndex++) {
        if (removeWindowId == $NC.G_VAR.windows[rIndex].get("id")) {
            $NC.G_VAR.windows.splice(rIndex, 1);
            $jWindow.update(null);
            $jWindow.removeWindow();
            delete $jWindow;
            $("#" + removeWindowId).remove();
            break;
        }
    }

    // 마지막 화면 맨 앞으로
    var winCount = $NC.G_VAR.windows.length;
    if (winCount > 0) {
        $NC.G_VAR.activeWindow = $NC.G_VAR.windows[winCount - 1];
        $NC.G_VAR.activeWindow.getContainerNode().show();
        $NC.G_VAR.activeWindow.focus();
    } else {
        topButtonsInitialize(true);
        scrollViewToTop();

        showMenu(true);
    }
}

/**
 * 활성화된 화면 닫기(제거)
 * 
 * @returns
 */
function removeActiveWindow() {
    if ($NC.G_VAR.lastWindow == null) {
        return;
    }

    // 1: 단위화면, 2: 단위화면팝업, 3: 공통팝업, 미리보기팝업
    if ($NC.G_VAR.lastWindow.get("windowType") == 1) {
        removeChildWindow($NC.G_VAR.lastWindow);
    } else {
        removePopupWindow($NC.G_VAR.lastWindow);
    }
}

/**
 * 실행된 단위 화면 전체를 목록에서 제거
 */
function removeAllChildWindow() {

    $NC.G_VAR.activeWindow = null;
    $NC.G_VAR.activePopupWindow = null;
    $NC.G_VAR.activeSubWindow = null;
    $NC.G_VAR.lastWindow = null;

    var removeWindowId, /*removeProgramId,*/$jWindow;
    for (var rIndex = $NC.G_VAR.windows.length - 1; rIndex > -1; rIndex--) {

        $jWindow = $NC.G_VAR.windows[rIndex];
        removeWindowId = $jWindow.get("id");
        // removeProgramId = $jWindow.get("G_PARAMETER").PROGRAM_ID;

        $NC.G_VAR.windows.splice(rIndex, 1);

        $jWindow.update(null);
        $jWindow.removeWindow();
        delete $jWindow;
        $("#" + removeWindowId).remove();
    }

    showMenu(true);
    scrollViewToTop();
}

/**
 * 프로그램ID로 jWindow 리턴
 * 
 * @params program_Id
 */
function getWindowIndex(programId) {

    var result = -1;

    var containerId = programId.indexOf("ctr") == 0 ? programId : "ctr" + programId;
    var $jWindow;
    for (var rIndex = 0, rCount = $NC.G_VAR.windows.length; rIndex < rCount; rIndex++) {
        $jWindow = $NC.G_VAR.windows[rIndex];
        if (containerId == $jWindow.get("id")) {
            result = rIndex;
            break;
        }
    }
    return result;
}

/**
 * 단위 화면에 참조정보 새로고침
 */
function refreshChildReferenceInfo() {

    var contentWindow;
    for (var rIndex = 0, rCount = $NC.G_VAR.windows.length; rIndex < rCount; rIndex++) {
        contentWindow = $NC.getChildWindow($NC.G_VAR.windows[rIndex]) || {};
        if ($NC.isNull(contentWindow.$NC) || !$.isFunction(contentWindow.$NC.refreshReferenceInfo)) {
            continue;
        }
        contentWindow.$NC.refreshReferenceInfo();
    }
}

/**
 * 로그인 팝업 초기화
 */
function showLoginPopup(loginType) {

    if ($Android.isValid()) {
        $Android.callby("sendMessage", 2/*MSG_LOGIN*/, 1/*로그인표시*/, 0);
    }

    $NC.setVisible("#ctrLoginLayer");
    $("#ctrLoginLayer").data("loginType", loginType);
    if ($NC.getLocalStorage("_SAVE_USER_ID") == $ND.C_YES) {
        $NC.setValue("#chkSave_User_Id", true);
        var userId = $NC.getLocalStorage("_USER_ID");
        if ($NC.isNotNull(userId)) {
            $NC.setValue("#edtUser_Id", userId);
            $NC.setFocus("#edtUser_Pwd");
            return;
        }
    }
    $NC.setFocus("#edtUser_Id");
}

/**
 * 출력물 목록 값 세팅
 */
function setPrintList(data) {

}

/**
 * 메인 윈도우에 포커스
 */
function setFocusMain() {

    window.focus();
}

/**
 * 활성화된 화면에 포커스
 */
function setFocusActiveWindow() {

    if ($NC.isNotNull($NC.G_VAR.activePopupWindow)) {
        $NC.G_VAR.lastWindow = $NC.G_VAR.activePopupWindow;
        $NC.G_VAR.lastWindow.focus();
    } else if ($NC.isNotNull($NC.G_VAR.activeSubWindow)) {
        $NC.G_VAR.lastWindow = $NC.G_VAR.activeSubWindow;
        $NC.G_VAR.lastWindow.focus();
    } else if ($NC.G_VAR.activeWindow) {
        $NC.G_VAR.lastWindow = $NC.G_VAR.activeWindow;
        $NC.G_VAR.lastWindow.focus();
    } else {
        showMenu(true);
    }
}

/**
 * 메인 윈도우가 스크롤 되어 있을 경우 왼쪽상단이 보이도록 위치 이동
 */
function scrollViewToTop() {

    var ctrViewport = $("#ctrViewport").get(0);
    if (ctrViewport) {
        ctrViewport.scrollLeft = 0;
        ctrViewport.scrollTop = 0;
    }
}

/**
 * 엑셀 다운로드
 * 
 * @param params
 *        P_QUERY_ID<br>
 *        P_QUERY_PARAMS<br>
 *        P_SERVICE_PARAMS<br>
 *        P_COLUMN_INFO
 */
function excelFileDownload(params, onSuccessHandler, onErrorHandler) {

    var exportCallback = function() {
        params["P_USER_ID"] = $NC.G_USERINFO.USER_ID;
        fileDownload("/WC/excelExport.do", params, onSuccessHandler, onErrorHandler);
    };

    if ($NC.G_USERINFO.USE_SECURITY_LOG === $ND.C_YES) {
        var columns = (params || {}).P_COLUMN_INFO || [];
        var piColumns = $NC.G_VAR.personalInfoColumns || [];
        var requiredReason = false;
        for (var rIndex = 0, rCount = columns.length; rIndex < rCount; rIndex++) {
            if (piColumns.indexOf(columns[rIndex].P_COLUMN_NM) > -1) {
                requiredReason = true;
                break;
            }
        }
        if (requiredReason) {
            showPIExcelDownload(exportCallback, params);
            return;
        }
    }

    exportCallback();
}

/**
 * 엑셀 업로드 후 조회
 * 
 * @param params
 *        P_QUERY_ID<br>
 *        P_QUERY_PARAMS<br>
 *        P_SERVICE_PARAMS<br>
 *        P_COLUMN_INFO
 */
function excelFileUpload(params, onSuccessHandler, onErrorHandler) {

    params["P_USER_ID"] = $NC.G_USERINFO.USER_ID;
    fileUpload("/WC/excelImport.do", params, onSuccessHandler, onErrorHandler);
}

/**
 * File 업로드 IFrame 초기화
 * 
 * @param initType
 */
function frmFileInitialize(initType) {

    if (initType == 0 || initType == 1) {
        var $ifmFile = $("#ifmFile");
        $ifmFile.unbind("load");
        $ifmFile.prop("src", "about:blank");
    }

    if (initType == 0 || initType == 2) {
        var $frmFile = $("#frmFile");
        var $fileInput = $("#P_UPLOAD_FILE");
        if ($fileInput.length > 0) {
            $fileInput.removeAttr("accept");
            $fileInput.replaceWith($fileInput = $fileInput.clone(true));
        }
        $frmFile.empty();
        $frmFile.removeAttr("action");
        $frmFile.removeAttr("method");
        $frmFile.removeAttr("target");
        $frmFile.removeAttr("enctype");
    }
}

/**
 * 업로드 File 선택 Dialog
 * 
 * @param {String}
 *        accept 선택 가능 파일 종류 지정
 * @param onFileSelected
 */
function showUploadFilePopup(accept, onFileSelected) {

    frmFileInitialize(0);

    var backwardCompatibility = {};
    if (typeof accept == "string" || $.isFunction(onFileSelected)) {
        backwardCompatibility.accept = accept;
        backwardCompatibility.onFileSelected = onFileSelected;
    } else {
        backwardCompatibility.accept = null;
        backwardCompatibility.onFileSelected = accept;
    }
    var $frmFile = $("#frmFile");
    var $fileInput = $("<input/>", {
        id: "P_UPLOAD_FILE",
        type: "file",
        name: "P_UPLOAD_FILE"
    }).appendTo($frmFile);

    if ($NC.isNotNull(backwardCompatibility.accept)) {
        $fileInput.attr("accept", backwardCompatibility.accept);
    }

    if ($.isFunction(backwardCompatibility.onFileSelected)) {
        $fileInput.change(function(e) {
            var $view = $(e.target);
            var fileFullName = $NC.getValue($view);
            var fileName;
            if (fileFullName.indexOf("/") > -1) {
                fileName = fileFullName.substr(fileFullName.lastIndexOf("/") + 1);
            } else {
                fileName = fileFullName.substr(fileFullName.lastIndexOf("\\") + 1);
            }
            backwardCompatibility.onFileSelected($view, fileFullName, fileName);
        });
    }

    $fileInput.trigger("click");
}

/**
 * File 업로드 처리
 * 
 * @param requestUrl
 * @param requestData
 * @param onSuccessHandler
 * @param onErrorHandler
 */
function fileUpload(requestUrl, requestData, onSuccessHandler, onErrorHandler) {

    $NC.showProgressMessage({
        type: 2,
        message: $NC.getDisplayMsg("JS.PDA_MAIN.021", "파일을 업로드 중 입니다. 잠시만 기다려 주십시오...")
    });

    var $frmFile = $("#frmFile").attr({
        method: "post",
        action: requestUrl,
        target: "ifmFile",
        enctype: "multipart/form-data"
    });

    var requestParams = {
        P_UPLOAD_PARAMS: null
    };
    if (requestData) {
        requestParams.P_UPLOAD_PARAMS = $NC.toJson(requestData);
    }

    $("<input/>", {
        id: "P_UPLOAD_PARAMS",
        type: "hidden",
        name: "P_UPLOAD_PARAMS",
        value: requestParams.P_UPLOAD_PARAMS
    }).appendTo($frmFile);

    $frmFile.submit();
    setTimeout(function() {
        frmFileInitialize(2);
    }, $ND.C_TIMEOUT_CLOSE_FAST);

    // IE 11미만
    if ($.browser.msie && $.browser.versionNumber < 11) {
        $("#ifmFile")[0].onreadystatechange = function() {
            var $ifmFile = $("#ifmFile");
            var readyState = $ifmFile[0].readyState;
            if (readyState != "loading" && readyState != "uninitialized") {
                $ifmFile[0].onreadystatechange = null;
                onFileUpload(onSuccessHandler, onErrorHandler);
            }
        };
    }
    // 그외 Browser
    else {
        $("#ifmFile").on("load", function() {
            onFileUpload(onSuccessHandler, onErrorHandler);
        });
    }
}

/**
 * 파일 업로드 완료 콜백
 */
function onFileUpload(onSuccessHandler, onErrorHandler) {

    $NC.hideProgressMessage();

    var $body = $($("#ifmFile")[0].contentDocument.body);
    var ajaxData = $body.css("color", "transparent").text();
    if ($NC.isNull(ajaxData)) {
        return;
    }
    try {
        var resultData = $NC.toObject(ajaxData);
        // Array일 경우
        if (Array.isArray(resultData)) {
            if ($.isFunction(onSuccessHandler)) {
                onSuccessHandler(ajaxData, resultData);
            }
        }
        // 그외
        // 오류일 경우
        else if (("O_MSG" in resultData && resultData.O_MSG != $ND.C_OK) //
            || ("RESULT_CD" in resultData && resultData.RESULT_CD != $ND.C_RESULT_CD_OK)) {

            if ($.isFunction(onErrorHandler)) {
                onErrorHandler(ajaxData);
            } else {
                $NC.onError(ajaxData);
            }
        }
        // 정상일 경우
        else if ($.isFunction(onSuccessHandler)) {
            onSuccessHandler(ajaxData, resultData);
        }
    } catch (e) {
        if ($.isFunction(onErrorHandler)) {
            onErrorHandler(e);
        } else {
            alert(ajaxData);
        }
    } finally {
        $body.html("");
    }
}

/**
 * File 다운로드 처리
 * 
 * @param requestUrl
 * @param requestData
 * @param onSuccessHandler
 * @param onErrorHandler
 */
function fileDownload(requestUrl, requestData, onSuccessHandler, onErrorHandler) {

    $NC.showProgressMessage({
        type: 2,
        message: $NC.getDisplayMsg("JS.PDA_MAIN.022", "파일을 다운로드 중 입니다. 잠시만 기다려 주십시오...")
    });

    var requestParams = {
        P_DOWNLOAD_PARAMS: null
    };
    if (requestData) {
        requestParams.P_DOWNLOAD_PARAMS = $NC.toJson(requestData);
    }

    $.fileDownload(requestUrl, {
        parentElement: "#ctrFileView",
        httpMethod: "POST",
        enctype: "multipart/form-data",
        androidPostUnsupportedMessageHtml: null,
        cookieName: "neXosFileDownload",
        data: requestParams,
        successCallback: function(url) {

            $NC.hideProgressMessage();
            if ($.isFunction(onSuccessHandler)) {
                onSuccessHandler();
            }
            $("#ifmFileDownload").remove();
        },
        failCallback: function(responseHtml, url) {

            $NC.hideProgressMessage();
            if ($.isFunction(onErrorHandler)) {
                onErrorHandler(responseHtml);
            } else {
                $NC.onError(responseHtml);
            }
            $("#ifmFileDownload").remove();
        }
    });
}

/**
 * 로그인 성공시 호출되는 이벤트
 * 
 * @param ajaxData
 */
function onLogin(ajaxData) {

    var $ctrLoginLayer = $("#ctrLoginLayer");
    var loginType = $ctrLoginLayer.data("loginType");
    var PRE_USERINFO = $.extend({}, $NC.G_USERINFO);
    $NC.G_USERINFO = $NC.toObject(ajaxData);
    // Theme 적용
    var $body = $("body");
    var userTheme = $body.attr("user-theme");
    if ($NC.isNotNull(userTheme)) {
        $body.removeClass(userTheme);
    }
    userTheme = $NC.G_USERINFO.THEME_NM || "smoothness";
    $body.addClass(userTheme).attr("user-theme", userTheme);
    var $lblLoginServer = $("#lblLogin_Server").removeClass();
    if ($NC.isNotNull($NC.G_USERINFO._LOGIN_SERVER)) {
        $lblLoginServer.addClass("lblLoginServer " + $NC.G_USERINFO._LOGIN_SERVER);
    }
    // 로그인 사용자 정보 세팅
    if ($Android.isValid()) {
        $Android.callby("setUserInfo", $NC.toJson($NC.G_USERINFO));
    }

    // 비밀번호 사용기한 만료, 비밀번호 관리자 변경
    if ($NC.G_USERINFO.CHANGE_PWD_YN == $ND.C_YES //
        || $NC.G_USERINFO.ERROR_CHANGE_PWD_YN == $ND.C_YES) {
        $NC.setVisible($ctrLoginLayer, false);
        $NC.setVisible("#ctrMainView");
        $ctrLoginLayer.removeData("loginType");
        $NC.setValue("#edtUser_Id");
        $NC.setValue("#edtUser_Pwd");

        showChangeUserPwdPopup();
        return;
    }
    // 정상 로그인,, Version 체크
    if ($Android.isValid()) {
        var updateType = 0;
        if ($NC.G_USERINFO.PDA_APPLICATION_VERSION > $NC.G_VAR.PDA_APPLICATION_VERSION) {
            updateType = 1;
        }
        if ($NC.G_USERINFO.PDA_RESOURCE_VERSION > $NC.G_VAR.PDA_RESOURCE_VERSION) {
            updateType = updateType == 1 ? 3 : 2;
        }
        if (updateType > 0) {
            // 업데이트 전 로그아웃 처리
            $NC.G_VAR.isLogout = true;
            $NC.serviceCall("/WC/logout.do", {
                P_USER_ID: $NC.G_USERINFO.USER_ID
            });
            // updateType
            // 1: Application
            // 2: Resource
            // 3: Application + Resource
            $Android.callby("sendMessage", 3/*MSG_UPDATE*/, updateType/*UPDATE_TYPE*/, 0);
            return;
        }
    }
    refreshChildReferenceInfo();

    // 재로그인일 경우
    if (loginType == 1) {
        $NC.G_USERINFO.CENTER_CD = PRE_USERINFO.CENTER_CD;
        $NC.G_USERINFO.CENTER_NM = PRE_USERINFO.CENTER_NM;
        $NC.G_USERINFO.BU_CD = PRE_USERINFO.BU_CD;
        $NC.G_USERINFO.BU_NM = PRE_USERINFO.BU_NM;
        $NC.G_USERINFO.WORK_DATE = PRE_USERINFO.WORK_DATE;
    }
    // 0 - 정상로그인, 2 - 로그인된 상태에서 메인 새로고침
    else {
        // 작업일자 - 로그인일자로 세팅
        $NC.G_USERINFO.WORK_DATE = $NC.G_USERINFO.LOGIN_DATE;
    }

    // 로그인시 MainMenu 처리
    window._OnLoginMainMenu();

    // 메시지 조회
    $NC.serviceCallAndWait("/WC/getDataSet.do", {
        P_QUERY_ID: "WC.GET_CSMSG",
        P_QUERY_PARAMS: {
            P_SYS_LANG: $NC.G_USERINFO.SYS_LANG
        }
    }, onGetMsg);

    // 사용자 ID 기록 여부 체크, 기록
    if ($NC.isVisible($ctrLoginLayer)) {
        if ($NC.getValue("#chkSave_User_Id") == $ND.C_YES) {
            $NC.setLocalStorage("_SAVE_USER_ID", $ND.C_YES);
            $NC.setLocalStorage("_USER_ID", $NC.G_USERINFO.USER_ID);
        } else {
            $NC.setLocalStorage("_SAVE_USER_ID", $ND.C_NO);
            $NC.setLocalStorage("_USER_ID", null);
        }
        $NC.setVisible($ctrLoginLayer, false);
        $NC.setValue("#edtUser_Id");
        $NC.setValue("#edtUser_Pwd");
    }

    if ($Android.isValid()) {
        $Android.callby("sendMessage", 2/*MSG_LOGIN*/, 2/*정상로그인*/, 0);
    }

    $ctrLoginLayer.removeData("loginType");
    $NC.setVisible("#ctrMainView");

    // 재로그인일 경우
    if (loginType == 1) {
        // 오픈된 윈도우가 없으면 메뉴 표시
        if ($NC.G_VAR.lastWindow == null) {
            showMenu(true);
        } else {
            setFocusActiveWindow();
        }
    }
    // 재로그인이 아닐 경우
    else {
        showMenu(true);
    }

    // 비밀번호 변경 알림
    if (loginType == 0 && $NC.G_USERINFO.CHANGE_PWD_ALERT_YN == $ND.C_YES) {
        $NC.setVisible($ctrLoginLayer, false);
        $NC.setVisible("#ctrMainView");
        $ctrLoginLayer.removeData("loginType");
        $NC.setValue("#edtUser_Id");
        $NC.setValue("#edtUser_Pwd");

        showChangeUserPwdPopup();
        return;
    }

    if ($NC.G_USERINFO.USE_SECURITY_LOG === $ND.C_YES) {
        $NC.G_VAR.personalInfoPrograms = ($NC.G_USERINFO.PI_PROGRAMS || "").split(",");
        $NC.G_VAR.personalInfoColumns = ($NC.G_USERINFO.PI_COLUMNS || "").split(",");
        $NC.setInitCombo("/WC/getDataSet.do", {
            P_QUERY_ID: "WC.POP_CMCODE",
            P_QUERY_PARAMS: {
                P_COMMON_GRP: "WMSP24", // 개인정보 엑셀다운로드 사용
                P_COMMON_CD: $ND.C_ALL,
                P_VIEW_DIV: "1"
            }
        }, {
            selector: "#cboPI_Excel_Download_Cause_Div",
            codeField: "COMMON_CD",
            nameField: "COMMON_NM",
            fullNameField: "COMMON_CD_F"
        });
    }
    delete $NC.G_USERINFO.PI_PROGRAMS;
    delete $NC.G_USERINFO.PI_COLUMNS;
}

/**
 * 컬럼/화면 공통 메시지 Load시 호출되는 이벤트
 * 
 * @param ajaxData
 */
function onGetMsg(ajaxData) {

    $NC.setGlobalDisplayInfo(ajaxData);
    $NC.setInitDisplay();
    setReinitDisplayMain();
}

/**
 * 로그인 오류시 호출되는 이벤트
 * 
 * @param ajaxData
 */
function onLoginError(ajaxData) {

    $NC.G_USERINFO = null;
    $NC.onError(ajaxData);
    $("#ctrLoginLayer").removeData("loginType");
    $NC.setFocus("#edtUser_Pwd");
}

/**
 * 로그아웃 성공시 호출되는 이벤트
 * 
 * @param ajaxData
 */
function onLogout(ajaxData) {

    if ($Android.isValid()) {
        $Android.callby("sendMessage", 1/*MSG_LOAD_MAIN_PAGE*/);
    } else {
        window.location.replace($NC.G_VAR.baseUrl + "main/");
    }
}

function onResetUserPwd(ajaxData) {

    alert($NC.getDisplayMsg("JS.PDA_MAIN.XXX", "사용자 이메일로 임시 비밀번호가 정상적으로 발송되었습니다."));

    toggleLoginForm();
}

function onResetUserPwdError(ajaxData) {

    $NC.onError(ajaxData);
    $NC.setFocus("#edtReset_User_Id");
}

function getEncPayload(requestData) {

    var encSalt = $("#ctrLoginLayer").data("encSalt") || $NC.lPad("", 32, "0");
    var secret = encSalt.substring(0, 16);
    var iv = encSalt.substring(16);
    var cipher = window.CryptoJS.AES.encrypt($NC.toJson(requestData), window.CryptoJS.enc.Utf8.parse(secret), {
        iv: window.CryptoJS.enc.Utf8.parse(iv),
        padding: window.CryptoJS.pad.Pkcs7,
        mode: window.CryptoJS.mode.CBC
    });

    return {
        P_ENC_SALT: encSalt,
        P_ENC_PAYLOAD: cipher.toString()
    };
}

/**
 * 화면 메시지 재세팅
 */
function setReinitDisplayMain() {

    setLoginUserInfo();

    $NC.setTooltip("#btnLogout", $NC.getDisplayMsg("JS.PDA_MAIN.032", "현재 로그인한 사용자 로그아웃"));
}

function setLoginUserInfo() {

    $NC.setValue("#edtUser_Id_F", $NC.getDisplayCombo($NC.G_USERINFO.USER_ID, $NC.G_USERINFO.USER_NM));
    var $btnTopUser = $("#btnTopUser");
    var htmlUserInfo = "<span>" + $NC.G_USERINFO.USER_ID + " - " + $NC.G_USERINFO.USER_NM + "</span><br>" //
        + "<span>" + ($NC.G_USERINFO.WORK_DATE || $NC.G_USERINFO.LOGIN_DATE) //
        + " [" + $NC.G_USERINFO.CENTER_CD + "] " + $NC.G_USERINFO.BU_CD + "</span>";
    $btnTopUser.empty().append(htmlUserInfo);

    $NC.setTooltip($btnTopUser, $NC.G_USERINFO.USER_ID //
        + " - " + $NC.G_USERINFO.USER_NM //
        + "\n" + $NC.G_USERINFO.LOGIN_DATETIME //
        + " " + $NC.getDisplayMsg("JS.PDA_MAIN.023", "접속\n\n사용자 비밀번호를 변경하려면 버튼을 클릭하십시오."));
}

/**
 * 데이터 복사 Overlay 초기화
 */
function copyGridDataOverlayInitialize() {

    $("#ctrCopyGridDataView").draggable({
        containment: "#ctrWindows",
        scroll: false,
        drag: function(event, ui) {
            clearTimeout($NC.G_VAR.onCopyDataTimeout);
        },
        stop: function(event, ui) {
            $NC.setFocus("#edtCopyValue");
        }
    });

    $("#chkCopyOption") //
    .focus(function(e) {
        clearTimeout($NC.G_VAR.onCopyDataTimeout);
    }).bind("click blur", function(e) {
        $NC.setFocus("#edtCopyValue");
    }).change(function(e) {
        $NC.G_VAR.copyInfo.lastSearchVal = "";
        $NC.G_VAR.copyInfo.lastSearchIndex = -1;
    });

    $("#edtCopyValue") //
    .focus(function(e) {
        clearTimeout($NC.G_VAR.onCopyDataTimeout);
    }).blur(function(e) {
        $NC.G_VAR.onCopyDataTimeout = setTimeout(hideCopyGridData, $ND.C_TIMEOUT_CLOSE_FAST);
    }).keydown(function(e) {
        switch (e.keyCode) {
            // enter 무시
            case 13:
                e.preventDefault();
                break;
            // 정상 처리
            // Ctrl + [C, X]
            case 67:
            case 88:
                if (e.ctrlKey || e.metaKey) {
                    // 선택되어 있지 않을 경우 선택
                    var $edtCopyValue = $("#edtCopyValue");
                    if ($edtCopyValue.prop("selectionStart") == $edtCopyValue.prop("selectionEnd")) {
                        $edtCopyValue.prop("selectionStart", 0).prop("selectionEnd", -1);
                    }
                    hideCopyGridData();
                }
                break;
            // esc
            case 27:
                hideCopyGridData();
                e.preventDefault();
                break;
        }
    }).keyup(function(e) {
        if (e.keyCode != 13) {
            e.preventDefault();
            return;
        }

        if ($NC.G_VAR.copyInfo.columnField == $ND.C_ALL) {
            hideCopyGridData();
            return;
        }

        if ($NC.G_VAR.lastWindow == null || $NC.isNull($NC.G_VAR.copyInfo.targetGrid)) {
            alert($NC.getDisplayMsg("JS.PDA_MAIN.039", "검색할 그리드가 지정되지 않았습니다."));
            return;
        }

        var searchVal = $NC.getValue("#edtCopyValue");
        if ($NC.isNull(searchVal)) {
            alert($NC.getDisplayMsg("JS.PDA_MAIN.040", "검색할 값을 입력하십시오."));
            return;
        }
        var isFirst = false;
        if (searchVal != $NC.G_VAR.copyInfo.lastSearchVal) {
            $NC.G_VAR.copyInfo.lastSearchIndex = -1;
            $NC.G_VAR.copyInfo.lastSearchVal = searchVal;
            isFirst = true;
        }

        if ($NC.G_VAR.copyInfo.lastSearchIndex > -1) {
            $NC.G_VAR.copyInfo.lastSearchIndex += 1;
        }
        var isWhole = $NC.getValue("#chkCopyOption") == $ND.C_YES;

        var contentWindow = $NC.getChildWindow($NC.G_VAR.lastWindow);
        var grdObject = "G_" + $NC.G_VAR.copyInfo.targetGrid.toUpperCase();

        var searchIndex = $NC.getGridSearchRow(contentWindow[grdObject], {
            compareFn: function(rowData) {
                var compareVal = rowData[$NC.G_VAR.copyInfo.columnField] || "";
                return isWhole ? searchVal == compareVal : compareVal.indexOf(searchVal) > -1;
            },
            startIndex: $NC.G_VAR.copyInfo.lastSearchIndex
        });

        if (searchIndex == -1) {
            if (isFirst) {
                alert($NC.getDisplayMsg("JS.PDA_MAIN.041", "해당 값이 존재하지 않습니다."));
                $NC.G_VAR.copyInfo.lastSearchVal = "";
            } else {
                alert($NC.getDisplayMsg("JS.PDA_MAIN.042", "해당 값이 더이상 존재하지 않습니다."));
            }
            $NC.G_VAR.copyInfo.lastSearchIndex = -1;
        } else {
            $NC.setGridSelectRow(contentWindow[grdObject], searchIndex);

            $NC.setValue("#lblCopyColumn", $NC.G_VAR.copyInfo.columnName //
                + " (" + (searchIndex + 1) + "/" + $NC.G_VAR.copyInfo.rowCount + ")");
            $NC.G_VAR.copyInfo.lastSearchIndex = searchIndex;
        }
    });
}

/**
 * 데이터 복사 Overlay 보이기
 * 
 * @param selector
 * @param column
 * @param rowData
 * @param e
 * @param rowNum
 * @param rowCount
 */
function showCopyGridData(selector, column, rowData, e, rowNum, rowCount) {

    var $view = $NC.getView("#edtCopyValue");
    var grdObject = $NC.getChildWindow($NC.G_VAR.lastWindow)["G_" + selector.toUpperCase()];
    var copyValue = "";
    // 전체 항목일 경우
    if (e.shiftKey || e.altKey) {
        $NC.setValue("#lblCopyColumn", $NC.getDisplayMsg("JS.PDA_MAIN.043", "전체항목 (" + (rowNum + 1) + "/" + rowCount + ")", rowNum + 1, rowCount));

        if (rowData.__group) {
            rowData = $NC.getGridItemFromGroup(rowData, grdObject);
        }

        var colFields = [], colNames = [], colVals = [];
        var columns = grdObject.view.getColumns();
        var colIndex = 0, colCount = columns.length;
        for (; colIndex < colCount; colIndex++) {
            colFields.push(columns[colIndex].field);
            colNames.push(columns[colIndex].name);
        }
        for ( var field in rowData) {
            if (colFields.indexOf(field) > -1) {
                continue;
            }
            if ($NC.isNull(field) || field == "id" || field == "CRUD") {
                continue;
            }
            colFields.push(field);
            colNames.push($NC.getDisplayName(field, field));
        }
        colCount = colFields.length;

        for (colIndex = 0; colIndex < colCount; colIndex++) {
            colVals.push($NC.nullToDefault(rowData[colFields[colIndex]], ""));
        }
        if (e.shiftKey) {
            copyValue = colNames.join("\t") + "\n" + colVals.join("\t");
        } else {
            copyValue = colVals.join("\t");
        }

        $("#lblCopyComments").html($NC.getDisplayMsg("JS.PDA_MAIN.044", "데이터 복사: 값 선택 후 [Ctrl＋C] 키 입력"));
        $NC.setVisible($("#chkCopyOption").parent(), false);

        $NC.G_VAR.copyInfo.columnField = $ND.C_ALL;
        $NC.G_VAR.copyInfo.columnName = $NC.getDisplayMsg("JS.PDA_MAIN.045", "전체");
    }
    // 단일 항목일 경우
    else {
        // 컬럼 타이틀이 체크박스일 경우 Row 정보만 표시
        if ((column.name || "").indexOf("input") != -1) {
            $NC.setValue("#lblCopyColumn", "(" + (rowNum + 1) + "/" + rowCount + ")");
        } else {
            $NC.setValue("#lblCopyColumn", column.name + " (" + (rowNum + 1) + "/" + rowCount + ")");
        }

        if (rowData.__group) {
            rowData = $NC.getGridItemFromGroup(rowData, grdObject);
        }

        copyValue = rowData[column.field];
        $("#lblCopyComments").html($NC.getDisplayMsg("JS.PDA_MAIN.046", "데이터 검색: 검색할 값 입력 후 [Enter] 키 입력<br>데이터 복사: 값 선택 후 [Ctrl＋C] 키 입력"));
        $NC.setVisible($("#chkCopyOption").parent());

        $NC.G_VAR.copyInfo.columnField = column.field;
        $NC.G_VAR.copyInfo.columnName = column.name;
    }

    $NC.G_VAR.copyInfo.targetGrid = selector;
    $NC.G_VAR.copyInfo.rowCount = rowCount;

    $NC.G_VAR.lastWindow.focus(false);
    $NC.setValue($view, copyValue);
    $("#ctrCopyGridDataView").css("visibility", "hidden");
    $("#ctrCopyGridDataLayer").fadeIn("fast", function() {
        $("#ctrCopyGridDataView").css({
            "top": Math.ceil(($(window).height() - 60) / 2),
            "left": Math.ceil(($(window).width() - $("#ctrCopyGridDataView").outerWidth()) / 2),
            "visibility": "visible"
        });
        $NC.setFocus($view);
        $view.select();
    });
}

/**
 * 데이터 복사 Overlay 숨기기
 */
function hideCopyGridData() {

    clearTimeout($NC.G_VAR.onCopyDataTimeout);

    $NC.G_VAR.copyInfo.targetGrid = "";
    $NC.G_VAR.copyInfo.columnField = "";
    $NC.G_VAR.copyInfo.columnName = "";
    $NC.G_VAR.copyInfo.rowCount = 0;
    $NC.G_VAR.copyInfo.lastSearchVal = "";
    $NC.G_VAR.copyInfo.lastSearchIndex = -1;

    var $view = $("#ctrCopyGridDataLayer");
    if ($NC.isVisible($view)) {
        $view.fadeOut("fast", function() {
            setFocusActiveWindow();
        });
    }
}

/**
 * 엑셀 다운로드 Overla 초기화
 */
function piExcelDownloadOverlayInitialize() {

    $("#ctrPIExcelDownload").draggable({
        containment: "#ctrWindows",
        scroll: false,
        // drag: function(event, ui) { },
        stop: function(event, ui) {
            $NC.setFocus("#cboPI_Excel_Download_Cause_Div");
        }
    });

    $("#cboPI_Excel_Download_Cause_Div").change(function(e) {
        $("#edtPI_Excel_Download_Cause_Comment").focus().select();
    });
    $("#btnPIExcelDownloadCancel").click(hidePIExcelDownload);
}

/**
 * 엑셀 다운로드 Overlay 표시
 */
function showPIExcelDownload(exportCallback, params) {

    $NC.G_VAR.lastWindow.focus(false);
    // 사유구분은 마지막 선택 상태, 사유내역만 초기화
    $NC.setValue("#edtPI_Excel_Download_Cause_Comment");

    $("#ctrPIExcelDownload").css("visibility", "hidden");
    $("#ctrPIExcelDownloadLayer").fadeIn("fast", function() {
        $("#ctrPIExcelDownload").css({
            "top": Math.ceil(($(window).height() - 60) / 2),
            "left": Math.ceil(($(window).width() - $("#ctrPIExcelDownload").outerWidth()) / 2),
            "visibility": "visible"
        });
        $NC.setFocus("#edtPI_Excel_Download_Cause_Comment");
    });

    $("#btnPIExcelDownload").off("click").on("click", function() {
        // 개인정보 엑셀 다운로드 로그 저장
        // Window Type
        // 0: Main
        // 1: 프로그램 단위화면
        // 2: 프로그램 단위화면 서브 팝업
        // 3: 공통 코드검색, 출력 미리보기 팝업
        var ACTIVITY_COMMENT;
        var ACTIVITY_PROGRAM_ID;
        if ($NC.isNotNull($NC.G_VAR.lastWindow)) {
            var windowType = $NC.G_VAR.lastWindow.get("windowType");
            var G_PARAMETER = $NC.G_VAR.lastWindow.get("G_PARAMETER");
            ACTIVITY_PROGRAM_ID = G_PARAMETER.PROGRAM_ID || "";
            if (windowType == 3) {
                ACTIVITY_COMMENT = {
                    P_CAUSE_DIV: $NC.getValue("#cboPI_Excel_Download_Cause_Div"),
                    P_CAUSE_COMMENT: $NC.getValue("#edtPI_Excel_Download_Cause_Comment"),
                    P_QUERY_ID: G_PARAMETER.queryId,
                    P_QUERY_PARAMS: G_PARAMETER.queryParams
                };
            } else {
                ACTIVITY_COMMENT = {
                    P_CAUSE_DIV: $NC.getValue("#cboPI_Excel_Download_Cause_Div"),
                    P_CAUSE_COMMENT: $NC.getValue("#edtPI_Excel_Download_Cause_Comment"),
                    P_QUERY_ID: params.P_QUERY_ID,
                    P_QUERY_PARAMS: params.P_QUERY_PARAMS
                };
            }
        }
        var saveSuccess = false;
        $NC.serviceCallAndWait("/WC/writeActivityLog.do", {
            P_ACTIVITY_CD: ACTIVITY_PROGRAM_ID,
            P_ACTIVITY_COMMENT: objToParamString(ACTIVITY_COMMENT),
            P_ACTIVITY_DIV: "23", // 23 - 개인정보엑셀다운로드
            P_USER_ID: $NC.G_USERINFO.USER_ID
        }, function() {
            // 성공
            saveSuccess = true;
        }, function() {
            // 실패 메시지 표시 하지 않음
        });

        hidePIExcelDownload();
        if (saveSuccess) {
            if ($.isFunction(exportCallback)) {
                setTimeout(function() {
                    exportCallback();
                }, 100);
            }
        }
    });
}

/**
 * 엑셀 다운로드 Overlay 숨기기
 */
function hidePIExcelDownload() {

    var $view = $("#ctrPIExcelDownloadLayer");
    if ($NC.isVisible($view)) {
        $view.fadeOut("fast", function() {
            setFocusActiveWindow();
        });
    }
}

function objToParamString(obj, indent, preString) {
    indent = indent || "";
    var result = preString || "";
    if ($.isPlainObject(obj)) {
        var keys = Object.keys(obj), key;
        for (var rIndex = 0, rCount = keys.length; rIndex < rCount; rIndex++) {
            key = keys[rIndex];
            if ($.isPlainObject(obj[key])) {
                result += indent + key + ":\n";
                result += objToParamString(obj[key], indent + "    ", preString);
            } else {
                result += indent + key + ": " + obj[key] + "\n";
            }
        }
    }
    return result;
}

function isRunningServer() {

    var serverStatus = $NC.getServerStatus();
    if (serverStatus.error) {
        $NC.onError(serverStatus.error);
        return false;
    }
    return true;
}

/**
 * 인쇄 미리보기 호출 파라메터를 서비스 호출 파라메터로 변경
 */
function getPrintServiceParams(options) {

    var params = {
        P_REPORT_FILE: options.reportDoc,
        P_QUERY_ID: options.queryId,
        P_QUERY_PARAMS: "",
        P_CHECKED_VALUE: "",
        P_INTERNAL_QUERY_YN: $ND.C_NO,
        P_PRINT_COPY: 1
    };

    if ($NC.isNotNull(options.checkedValue)) {
        params.P_CHECKED_VALUE = options.checkedValue;
    }

    if ($NC.isNotNull(options.queryParams)) {
        params.P_QUERY_PARAMS = options.queryParams;
    }

    if ($NC.isNotNull(options.internalQueryYn)) {
        params.P_INTERNAL_QUERY_YN = options.internalQueryYn;
    }

    if ($NC.isNotNull(options.printCopy)) {
        params.P_PRINT_COPY = options.printCopy;
    }

    if ($NC.isNotNull(options.programId)) {
        params.P_PROGRAM_ID = options.programId;
    }

    if ($NC.isNotNull(options.reportTitle)) {
        params.P_REPORT_TITLE_NM = options.reportTitle;
    }

    params.P_USER_ID = $NC.G_USERINFO.USER_ID;
    params.P_USER_NM = $NC.G_USERINFO.USER_NM;
    params.P_CLIENT_IP = $NC.G_USERINFO.CLIENT_IP;

    return params;
}

/**
 * Android BackPressed 대한 처리
 * 
 * @param {String}
 *        message
 * @returns
 */
function canBackPressedAction(message) {

    var backKeyPressedMillis = (new Date()).getTime();
    if (backKeyPressedMillis > ($NC.G_VAR.lastBackKeyPressedMillis || 0) + 2000) {
        $NC.G_VAR.lastBackKeyPressedMillis = backKeyPressedMillis;
        if ($Android.isValid()) {
            $Android.callby("showToast", message);
        }
        return false;
    } else {
        if ($Android.isValid()) {
            $Android.callby("cancelToast");
        }
        return true;
    }
}

/**
 * Android BackPressed Event에 대한 처리
 * 
 * @returns
 */
function onNativeBackPressed() {

    // console.log("onNativeBackPressed");
    // 실행중인 화면(일반/팝업/공통팝업)이 있을 경우
    if ($NC.G_VAR.lastWindow != null) {
        if (canBackPressedAction("'뒤로' 버튼을 한번 더 누르시면 실행중인 화면이 종료됩니다.")) {
            // 화면 오류시 LoadingLayer 사라지지 않음, 화면 닫을때 숨김 처리
            if ($NC.isVisible("#ctrLoadingLayer")) {
                $NC.hideLoadingMessage(true);
            }
            removeActiveWindow();
        }
        return $ND.C_NO;
    }
    // 로그인 후 메뉴 표시 상태, 로그아웃 호출
    else if ($NC.isVisible("#ctrMenuView")) {
        if (canBackPressedAction("'뒤로' 버튼을 한번 더 누르시면 로그아웃 처리됩니다.")) {
            doLogout();
        }
        return $ND.C_NO;
    }
    return $ND.C_YES;
}

/**
 * Android SoftKeyboard Visible Event에 대한 처리
 * 
 * @param {Boolean}
 *        visible
 * @param {Number}
 *        height
 */
function onNativeKeyboardVisible(visible, height) {

    // console.log("onNativeKeyboardVisible: visible: " + visible + (visible ? ", height: " + height : ""));
}

/**
 * Android SoftKeybarod가 표시될 때 HTML Document - ActiveElement의 값 요청에 대한 처리
 * 
 * @returns
 */
function onNativeGetEditValue() {

    var contentDocument, contentWindow;
    if ($NC.G_VAR.lastWindow != null) {
        contentDocument = $NC.getChildDocument($NC.G_VAR.lastWindow);
        contentWindow = $NC.getChildWindow($NC.G_VAR.lastWindow);
    } else {
        contentDocument = document;
        contentWindow = window;
    }
    // ActiveElement 정보 전역변수에 기록
    $NC.G_VAR.activeElement = contentWindow.$(contentDocument.activeElement);
    $NC.G_VAR.activeValue = contentWindow.$NC.getValue($NC.G_VAR.activeElement);
    // console.log("onNativeGetEditValue: " + $NC.G_VAR.activeElement.prop("id") + "=" + $NC.G_VAR.activeValue);
    return $NC.G_VAR.activeValue;
}

/**
 * Android SoftKeyboard로 값 입력이 완료되었을 때에 대한 처리
 * 
 * @param {String}}
 *        value
 */
function onNativeSetEditValue(value) {

    // console.log("onNativeSetEditValue: " + $NC.G_VAR.activeElement.prop("id") + "=" + value);
    var /*contentDocument,*/contentWindow;
    if ($NC.G_VAR.lastWindow != null) {
        // contentDocument = $NC.getChildDocument($NC.G_VAR.lastWindow);
        contentWindow = $NC.getChildWindow($NC.G_VAR.lastWindow);
    } else {
        // contentDocument = document;
        contentWindow = window;
    }
    // 값이 변경되었을 때만 처리
    if ($NC.G_VAR.activeValue != value) {
        contentWindow.$NC.setValue($NC.G_VAR.activeElement, value);
        $NC.G_VAR.activeElement.change();
        $NC.G_VAR.activeElement.focus();
    }

    // 키보드 강제로 숨김
    $NC.hideSoftInput();
}

function onNativePrint(result, errorMessage) {

    // 정상 처리
    if (result == "0") {
        alert("인쇄 명령이 정상 처리되었습니다.");
    } else {
        alert("인쇄 명령 처리중 오류가 발생했습니다.\n" + errorMessage);
    }
}