/**
 * <pre>
 *  ==================================================================================================================================================
 *  프로그램ID         : popup
 *  프로그램명         : 공통코드검색 Class
 *  프로그램설명       : 공통코드검색 Class Javascript
 *  작성자             : Copyright (c) 2013 ASETEC Corporation. All rights reserved.
 *  작성일자           : 2016-12-14
 *  버전               : 1.0
 * 
 *  --------------------------------------------------------------------------------------------------------------------------------------------------
 *  버전       작성일자      작성자           설명
 *  ---------  ------------  ---------------  --------------------------------------------------------------------------------------------------------
 *  1.0        2016-12-14    ASETEC           신규작성
 *  --------------------------------------------------------------------------------------------------------------------------------------------------
 * 
 *  ==================================================================================================================================================
 * </pre>
 */

// ---------------------------------------------------------------------------------------------------------------------------------------------------
// 공통 코드검색 팝업
// 컨테이너ID(containerId)의 명칭 접두어는 divCommonPopup으로 지정
// common.js에서 해당 명칭으로 분기 처리 함
// ---------------------------------------------------------------------------------------------------------------------------------------------------
// 공통 컴포넌트 JS Include
(function($) {

    $.extend(true, window, {
        Nexos: {
            Popup: NexosPopup
        }
    });

    /**
     * Nexos.Popup, Javascript 공통 Popup Object<br>
     * <br> ※ 공통 Popup Object는 사이트별로 추가/수정 될 수 있음, 기본적인 처리, 호출 방법은 동일
     * 
     * @class
     * @alias $NP
     * @extends Function
     * @author ASETEC
     * @copyright ASETEC 2014-2020
     * @version 7.5.0
     * @example
     * 
     * <pre>
     * window[$NP] = new Nexos.Popup($NC);
     * </pre>
     */
    function NexosPopup($NC) {
        "use strict";

        // -------------------------------------------------------------------------------------------------------------------------------------------
        // Global Variable
        // TODO: Global Variable
        // Private Property
        // -------------------------------------------------------------------------------------------------------------------------------------------
        var $THIS = this;

        // -------------------------------------------------------------------------------------------------------------------------------------------
        // Public Property
        // -------------------------------------------------------------------------------------------------------------------------------------------
        /**
         * 현재 팝업 표시 여부<br>
         * 공통에서 활성화된 window가 공통팝업인지 체크하기 위한 값
         * 
         * @property {Boolean} G_SHOW_POPUP 현재 팝업 표시 여부
         * @since 6.0.0
         * @memberof $NP#
         */
        this.G_SHOW_POPUP = false;

        /**
         * 다음 우편번호/주소 검색 API 사용 여부
         * 
         * @property {Boolean} G_USE_DAUM_POSTCODE 다음 우편번호/주소 검색 API 사용 여부
         * @since 6.0.0
         * @memberof $NP#
         */
        this.G_USE_DAUM_POSTCODE = true;

        // -------------------------------------------------------------------------------------------------------------------------------------------
        // Public Function
        // TODO: Public Function - START
        // -------------------------------------------------------------------------------------------------------------------------------------------
        /**
         * 공통팝업 onClose 기본 Callback<br>
         * onClose Callback 별도 지정시 마지막에 필수 호출 필요
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function onPopupClose() {

            $THIS.G_SHOW_POPUP = false;
        }

        /**
         * 사업부 팝업
         * 
         * @param {Object}
         *        options 팝업 호출 옵션
         * 
         * <pre>
         * <b>호출 방법 1(단순 설정)</b>
         * options 에 쿼리 파라메터를 지정한 경우 파라메터를 제외하고 모두 기본값으로 팝업 실행
         * 
         * <b>호출 방법 2(상세 설정)</b>
         * title                [옵션]:      {String}        팝업 창 타이틀
         * columnTitle          [옵션]:      {Array}         컬럼 타이틀, ["코드", "명"], 미지정시 기본 값
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * queryParams          [필수]:      {String}        쿼리 파라메터 지정
         * querySearchParam     [옵션]:      {String}        팝업 창 검색시 검색 값을 입력할 파라메터 명
         * queryCanAll          [옵션]:      {String}        팝업 창 전체 검색 가능 여부
         * queryData            [옵션]:      {Array}         데이터, 데이터를 넘겨줄 경우 서비스 호출하지 않음
         * </pre>
         * 
         * @param {Function}
         *        onPopupSelect 선택 버튼 클릭시 호출될 이벤트
         * @param {Function}
         *        onPopupCancel 취소 버튼 클릭시 호출될 이벤트
         * @example
         * 
         * <pre>
         * Call:
         *     // 호출 방법 1(단순 설정)
         *     $NP.showBuPopup({
         *         P_BU_CD: $ND.C_ALL
         *     }, onBuPopup, function() {
         *         $NC.setFocus("#edtQBu_Cd", true);
         *     });
         * 
         *     // 호출 방법 2(상세 설정)
         *     $NP.showBuPopup({
         *         title: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "사업부 검색"),
         *         columnTitle: [
         *             $NC.getDisplayName("BU_CD", "사업부코드"),
         *             $NC.getDisplayName("BU_NM", "사업부명")
         *         ],
         *         queryParams: {
         *             P_BU_CD: $ND.C_ALL
         *         }
         *     }, onBuPopup, function() {
         *         $NC.setFocus("#edtQBu_Cd", true);
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function showBuPopup(options, onPopupSelect, onPopupCancel) {

            var requestData;
            if ($NC.isNull(options)) {
                return;
            }

            // 호출방법1일 경우, 파라메터 조정
            if ($NC.isNull(options.queryParams)) {
                options = {
                    queryParams: options
                };
            }

            _setTitleOptions(options,
            // 팝업 타이틀
            $NC.getDisplayName("POPUP_BU_CD", "사업부"),
            // 기본 컬럼타이틀
            [
                $NC.getDisplayName("BU_CD", "사업부코드"),
                $NC.getDisplayName("BU_NM", "사업부명")
            ],
            // 컬럼 정보
            [
                {
                    id: "BU_CD",
                    field: "BU_CD",
                    width: 70,
                    cssClass: "styCenter"
                },
                {
                    id: "BU_NM",
                    field: "BU_NM",
                    width: 150
                }
            ]);

            requestData = {
                containerId: "ctrCommonPopupBu",
                title: options.title,
                autoInquiry: true,
                width: 400,
                height: 450,
                requestUrl: options.requestUrl,
                queryId: $NC.nullToDefault(options.queryId, "WC.POP_CMBU"),
                queryParams: options.queryParams,
                queryData: options.queryData,
                querySearchParam: $NC.nullToDefault(options.querySearchParam, "P_BU_CD"),
                queryCanAll: $NC.nullToDefault(options.queryCanAll, true),
                columns: options.columns,
                multiSelect: options.multiSelect,
                multiValue: options.multiValue,
                addBase: $NC.nullToDefault(options.addBase, ""),
                onSelect: onPopupSelect,
                onCancel: onPopupCancel,
                onClose: $THIS.onPopupClose
            };

            _showPopup(requestData);
        }

        /**
         * 사업부 브랜드 팝업
         * 
         * @param {Object}
         *        options 팝업 호출 옵션
         * 
         * <pre>
         * <b>호출 방법 1(단순 설정)</b>
         * options 에 쿼리 파라메터를 지정한 경우 파라메터를 제외하고 모두 기본값으로 팝업 실행
         * 
         * <b>호출 방법 2(상세 설정)</b>
         * title                [옵션]:      {String}        팝업 창 타이틀
         * columnTitle          [옵션]:      {Array}         컬럼 타이틀, ["코드", "명"], 미지정시 기본 값
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * queryParams          [필수]:      {String}        쿼리 파라메터 지정
         * querySearchParam     [옵션]:      {String}        팝업 창 검색시 검색 값을 입력할 파라메터 명
         * queryCanAll          [옵션]:      {String}        팝업 창 전체 검색 가능 여부
         * queryData            [옵션]:      {Array}         데이터, 데이터를 넘겨줄 경우 서비스 호출하지 않음
         * </pre>
         * 
         * @param {Function}
         *        onPopupSelect 선택 버튼 클릭시 호출될 이벤트
         * @param {Function}
         *        onPopupCancel 취소 버튼 클릭시 호출될 이벤트
         * @example
         * 
         * <pre>
         * Call:
         *     // 호출 방법 1(단순 설정)
         *     $NP.showBuBrandPopup({
         *         P_BU_CD: BU_CD,
         *         P_BRAND_CD: $ND.C_ALL
         *     }, onBuBrandPopup, function() {
         *         $NC.setFocus("#edtQBrand_Cd", true);
         *     });
         * 
         *     // 호출 방법 2(상세 설정)
         *     $NP.showBuBrandPopup({
         *         title: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "사업부 브랜드 검색"),
         *         columnTitle: [
         *             $NC.getDisplayName("BRAND_CD", "브랜드코드"),
         *             $NC.getDisplayName("BRAND_NM", "브랜드명"),
         *             $NC.getDisplayName("CUST_NM", "고객사명")
         *         ],
         *         queryParams: {
         *             P_BU_CD: BU_CD,
         *             P_BRAND_CD: $ND.C_ALL
         *         }
         *     }, onBuBrandPopup, function() {
         *         $NC.setFocus("#edtQBrand_Cd", true);
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function showBuBrandPopup(options, onPopupSelect, onPopupCancel) {

            var requestData;
            if ($NC.isNull(options)) {
                return;
            }

            // 호출방법1일 경우, 파라메터 조정
            if ($NC.isNull(options.queryParams)) {
                options = {
                    queryParams: options
                };
            }

            _setTitleOptions(options,
            // 팝업 타이틀
            $NC.getDisplayName("POPUP_BU_BRAND_CD", "사업부 브랜드"),
            // 기본 컬럼타이틀
            [
                $NC.getDisplayName("BRAND_CD", "브랜드코드"),
                $NC.getDisplayName("BRAND_NM", "브랜드명"),
                $NC.getDisplayName("CUST_NM", "고객사명")
            ],
            // 컬럼 정보
            [
                {
                    id: "BRAND_CD",
                    field: "BRAND_CD",
                    width: 70,
                    cssClass: "styCenter"
                },
                {
                    id: "BRAND_NM",
                    field: "BRAND_NM",
                    width: 150
                },
                {
                    id: "CUST_NM",
                    field: "CUST_NM",
                    width: 120
                }
            ]);

            requestData = {
                containerId: "ctrCommonPopupBuBrand",
                title: options.title,
                autoInquiry: true,
                width: 400,
                height: 450,
                requestUrl: options.requestUrl,
                queryId: $NC.nullToDefault(options.queryId, "WC.POP_CMBUBRAND"),
                queryParams: options.queryParams,
                queryData: options.queryData,
                querySearchParam: $NC.nullToDefault(options.querySearchParam, "P_BRAND_CD"),
                queryCanAll: $NC.nullToDefault(options.queryCanAll, true),
                columns: options.columns,
                multiSelect: options.multiSelect,
                multiValue: options.multiValue,
                addBase: $NC.nullToDefault(options.addBase, ""),
                onSelect: onPopupSelect,
                onCancel: onPopupCancel,
                onClose: $THIS.onPopupClose
            };

            _showPopup(requestData);
        }

        /**
         * 고객사 브랜드 팝업
         * 
         * @param {Object}
         *        options 팝업 호출 옵션
         * 
         * <pre>
         * <b>호출 방법 1(단순 설정)</b>
         * options 에 쿼리 파라메터를 지정한 경우 파라메터를 제외하고 모두 기본값으로 팝업 실행
         * 
         * <b>호출 방법 2(상세 설정)</b>
         * title                [옵션]:      {String}        팝업 창 타이틀
         * columnTitle          [옵션]:      {Array}         컬럼 타이틀, ["코드", "명"], 미지정시 기본 값
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * queryParams          [필수]:      {String}        쿼리 파라메터 지정
         * querySearchParam     [옵션]:      {String}        팝업 창 검색시 검색 값을 입력할 파라메터 명
         * queryCanAll          [옵션]:      {String}        팝업 창 전체 검색 가능 여부
         * queryData            [옵션]:      {Array}         데이터, 데이터를 넘겨줄 경우 서비스 호출하지 않음
         * </pre>
         * 
         * @param {Function}
         *        onPopupSelect 선택 버튼 클릭시 호출될 이벤트
         * @param {Function}
         *        onPopupCancel 취소 버튼 클릭시 호출될 이벤트
         * @example
         * 
         * <pre>
         * Call:
         *     // 호출 방법 1(단순 설정)
         *     $NP.showCustBrandPopup({
         *         P_CUST_CD: CUST_CD,
         *         P_BRAND_CD: $ND.C_ALL
         *     }, onCustBrandPopup, function() {
         *         $NC.setFocus("#edtQBrand_Cd", true);
         *     });
         * 
         *     // 호출 방법 2(상세 설정)
         *     $NP.showCustBrandPopup({
         *         title: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "고객사 검색"),
         *         columnTitle: [
         *             $NC.getDisplayName("BRAND_CD", "브랜드코드"),
         *             $NC.getDisplayName("BRAND_NM", "브랜드명"),
         *             $NC.getDisplayName("CUST_NM", "고객사명")
         *         ],
         *         queryParams: {
         *             P_CUST_CD: CUST_CD,
         *             P_BRAND_CD: $ND.C_ALL
         *         }
         *     }, onCustBrandPopup, function() {
         *         $NC.setFocus("#edtQBrand_Cd", true);
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function showCustBrandPopup(options, onPopupSelect, onPopupCancel) {

            var requestData;
            if ($NC.isNull(options)) {
                return;
            }

            // 호출방법1일 경우, 파라메터 조정
            if ($NC.isNull(options.queryParams)) {
                options = {
                    queryParams: options
                };
            }

            _setTitleOptions(options,
            // 팝업 타이틀
            $NC.getDisplayName("POPUP_CUST_BRAND_CD", "고객사 브랜드"),
            // 기본 컬럼타이틀
            [
                $NC.getDisplayName("BRAND_CD", "브랜드코드"),
                $NC.getDisplayName("BRAND_NM", "브랜드명"),
                $NC.getDisplayName("CUST_NM", "고객사명")
            ],
            // 컬럼 정보
            [
                {
                    id: "BRAND_CD",
                    field: "BRAND_CD",
                    width: 70,
                    cssClass: "styCenter"
                },
                {
                    id: "BRAND_NM",
                    field: "BRAND_NM",
                    width: 150
                },
                {
                    id: "CUST_NM",
                    field: "CUST_NM",
                    width: 120
                }
            ]);

            requestData = {
                containerId: "ctrCommonPopupCustBrand",
                title: options.title,
                autoInquiry: true,
                width: 400,
                height: 450,
                requestUrl: options.requestUrl,
                queryId: $NC.nullToDefault(options.queryId, "WC.POP_CMCUSTBRAND"),
                queryParams: options.queryParams,
                queryData: options.queryData,
                querySearchParam: $NC.nullToDefault(options.querySearchParam, "P_BRAND_CD"),
                queryCanAll: $NC.nullToDefault(options.queryCanAll, true),
                columns: options.columns,
                multiSelect: options.multiSelect,
                multiValue: options.multiValue,
                addBase: $NC.nullToDefault(options.addBase, ""),
                onSelect: onPopupSelect,
                onCancel: onPopupCancel,
                onClose: $THIS.onPopupClose
            };

            _showPopup(requestData);
        }

        /**
         * 브랜드 팝업
         * 
         * @param {Object}
         *        options 팝업 호출 옵션
         * 
         * <pre>
         * <b>호출 방법 1(단순 설정)</b>
         * options 에 쿼리 파라메터를 지정한 경우 파라메터를 제외하고 모두 기본값으로 팝업 실행
         * 
         * <b>호출 방법 2(상세 설정)</b>
         * title                [옵션]:      {String}        팝업 창 타이틀
         * columnTitle          [옵션]:      {Array}         컬럼 타이틀, ["코드", "명"], 미지정시 기본 값
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * queryParams          [필수]:      {String}        쿼리 파라메터 지정
         * querySearchParam     [옵션]:      {String}        팝업 창 검색시 검색 값을 입력할 파라메터 명
         * queryCanAll          [옵션]:      {String}        팝업 창 전체 검색 가능 여부
         * queryData            [옵션]:      {Array}         데이터, 데이터를 넘겨줄 경우 서비스 호출하지 않음
         * </pre>
         * 
         * @param {Function}
         *        onPopupSelect 선택 버튼 클릭시 호출될 이벤트
         * @param {Function}
         *        onPopupCancel 취소 버튼 클릭시 호출될 이벤트
         * @example
         * 
         * <pre>
         * Call:
         *     // 호출 방법 1(단순 설정)
         *     $NP.showBrandPopup({
         *         P_BRAND_CD: $ND.C_ALL,
         *         P_VIEW_DIV: "2"
         *     }, onBrandPopup, function() {
         *         $NC.setFocus("#edtQBrand_Cd", true);
         *     });
         * 
         *     // 호출 방법 2(상세 설정)
         *     $NP.showBrandPopup({
         *         title: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "브랜드 검색"),
         *         columnTitle: [
         *             $NC.getDisplayName("BRAND_CD", "브랜드코드"),
         *             $NC.getDisplayName("BRAND_NM", "브랜드명"),
         *             $NC.getDisplayName("CUST_NM", "고객사명")
         *         ],
         *         queryParams: {
         *             P_BRAND_CD: $ND.C_ALL,
         *             P_VIEW_DIV: "2"
         *         }
         *     }, onBrandPopup, function() {
         *         $NC.setFocus("#edtQBrand_Cd", true);
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function showBrandPopup(options, onPopupSelect, onPopupCancel) {

            var requestData;
            if ($NC.isNull(options)) {
                return;
            }

            // 호출방법1일 경우, 파라메터 조정
            if ($NC.isNull(options.queryParams)) {
                options = {
                    queryParams: options
                };
            }

            _setTitleOptions(options,
            // 팝업 타이틀
            $NC.getDisplayName("POPUP_BRAND_CD", "브랜드"),
            // 기본 컬럼타이틀
            [
                $NC.getDisplayName("BRAND_CD", "브랜드코드"),
                $NC.getDisplayName("BRAND_NM", "브랜드명"),
                $NC.getDisplayName("CUST_NM", "고객사명")
            ],
            // 컬럼 정보
            [
                {
                    id: "BRAND_CD",
                    field: "BRAND_CD",
                    width: 70,
                    cssClass: "styCenter"
                },
                {
                    id: "BRAND_NM",
                    field: "BRAND_NM",
                    width: 150
                },
                {
                    id: "CUST_NM",
                    field: "CUST_NM",
                    width: 120
                }
            ]);

            requestData = {
                containerId: "ctrCommonPopupBrand",
                title: options.title,
                autoInquiry: true,
                width: 400,
                height: 450,
                requestUrl: options.requestUrl,
                queryId: $NC.nullToDefault(options.queryId, "WC.POP_CMBRAND"),
                queryParams: options.queryParams,
                queryData: options.queryData,
                querySearchParam: $NC.nullToDefault(options.querySearchParam, "P_BRAND_CD"),
                queryCanAll: $NC.nullToDefault(options.queryCanAll, true),
                columns: options.columns,
                multiSelect: options.multiSelect,
                multiValue: options.multiValue,
                addBase: $NC.nullToDefault(options.addBase, ""),
                onSelect: onPopupSelect,
                onCancel: onPopupCancel,
                onClose: $THIS.onPopupClose
            };

            _showPopup(requestData);
        }

        /**
         * 차량 팝업
         * 
         * @param {Object}
         *        options 팝업 호출 옵션
         * 
         * <pre>
         * <b>호출 방법 1(단순 설정)</b>
         * options 에 쿼리 파라메터를 지정한 경우 파라메터를 제외하고 모두 기본값으로 팝업 실행
         * 
         * <b>호출 방법 2(상세 설정)</b>
         * title                [옵션]:      {String}        팝업 창 타이틀
         * columnTitle          [옵션]:      {Array}         컬럼 타이틀, ["코드", "명"], 미지정시 기본 값
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * queryParams          [필수]:      {String}        쿼리 파라메터 지정
         * querySearchParam     [옵션]:      {String}        팝업 창 검색시 검색 값을 입력할 파라메터 명
         * queryCanAll          [옵션]:      {String}        팝업 창 전체 검색 가능 여부
         * queryData            [옵션]:      {Array}         데이터, 데이터를 넘겨줄 경우 서비스 호출하지 않음
         * </pre>
         * 
         * @param {Function}
         *        onPopupSelect 선택 버튼 클릭시 호출될 이벤트
         * @param {Function}
         *        onPopupCancel 취소 버튼 클릭시 호출될 이벤트
         * @example
         * 
         * <pre>
         * Call:
         *     // 호출 방법 1(단순 설정)
         *     $NP.showCarPopup({
         *         P_CAR_CD: $ND.C_ALL,
         *         P_VIEW_DIV: "2"
         *     }, onCarPopup, function() {
         *         $NC.setFocus("#edtQCar_Cd", true);
         *     });
         * 
         *     // 호출 방법 2(상세 설정)
         *     $NP.showCarPopup({
         *         title: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "차량 검색"),
         *         columnTitle: [
         *             $NC.getDisplayName("CAR_CD", "차량코드"),
         *             $NC.getDisplayName("CAR_NM", "차량명")
         *         ],
         *         queryParams: {
         *             P_CENTER_CD: CENTER_CD,
         *             P_CAR_CD: $ND.C_ALL,
         *             P_VIEW_DIV: "2"
         *         }
         *     }, onCarPopup, function() {
         *         $NC.setFocus("#edtQCar_Cd", true);
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function showCarPopup(options, onPopupSelect, onPopupCancel) {

            var requestData;
            if ($NC.isNull(options)) {
                return;
            }

            // 호출방법1일 경우, 파라메터 조정
            if ($NC.isNull(options.queryParams)) {
                options = {
                    queryParams: options
                };
            }

            _setTitleOptions(options,
            // 팝업 타이틀
            $NC.getDisplayName("POPUP_CAR_CD", "차량"),
            // 기본 컬럼타이틀
            [
                $NC.getDisplayName("CAR_CD", "차량코드"),
                $NC.getDisplayName("CAR_NM", "차량명")
            ],
            // 컬럼 정보
            [
                {
                    id: "CAR_CD",
                    field: "CAR_CD",
                    width: 70,
                    cssClass: "styCenter"
                },
                {
                    id: "CAR_NM",
                    field: "CAR_NM",
                    width: 150
                }
            ]);

            requestData = {
                containerId: "ctrCommonPopupCar",
                title: options.title,
                autoInquiry: true,
                width: 400,
                height: 450,
                requestUrl: options.requestUrl,
                queryId: $NC.nullToDefault(options.queryId, "WC.POP_CMCAR"),
                queryParams: options.queryParams,
                queryData: options.queryData,
                querySearchParam: $NC.nullToDefault(options.querySearchParam, "P_CAR_CD"),
                queryCanAll: $NC.nullToDefault(options.queryCanAll, true),
                columns: options.columns,
                multiSelect: options.multiSelect,
                multiValue: options.multiValue,
                addBase: $NC.nullToDefault(options.addBase, ""),
                onSelect: onPopupSelect,
                onCancel: onPopupCancel,
                onClose: $THIS.onPopupClose
            };

            _showPopup(requestData);
        }

        /**
         * 물류센터 팝업
         * 
         * @param {Object}
         *        options 팝업 호출 옵션
         * 
         * <pre>
         * <b>호출 방법 1(단순 설정)</b>
         * options 에 쿼리 파라메터를 지정한 경우 파라메터를 제외하고 모두 기본값으로 팝업 실행
         * 
         * <b>호출 방법 2(상세 설정)</b>
         * title                [옵션]:      {String}        팝업 창 타이틀
         * columnTitle          [옵션]:      {Array}         컬럼 타이틀, ["코드", "명"], 미지정시 기본 값
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * queryParams          [필수]:      {String}        쿼리 파라메터 지정
         * querySearchParam     [옵션]:      {String}        팝업 창 검색시 검색 값을 입력할 파라메터 명
         * queryCanAll          [옵션]:      {String}        팝업 창 전체 검색 가능 여부
         * queryData            [옵션]:      {Array}         데이터, 데이터를 넘겨줄 경우 서비스 호출하지 않음
         * </pre>
         * 
         * @param {Function}
         *        onPopupSelect 선택 버튼 클릭시 호출될 이벤트
         * @param {Function}
         *        onPopupCancel 취소 버튼 클릭시 호출될 이벤트
         * @example
         * 
         * <pre>
         * Call:
         *     // 호출 방법 1(단순 설정)
         *     $NP.showCenterPopup({
         *         P_CENTER_CD: $ND.C_ALL
         *     }, onCenterPopup, function() {
         *         $NC.setFocus("#edtQCenter_Cd", true);
         *     });
         * 
         *     // 호출 방법 2(상세 설정)
         *     $NP.showCenterPopup({
         *         title: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "물류센터 검색"),
         *         columnTitle: [
         *             $NC.getDisplayName("CENTER_CD", "물류센터코드"),
         *             $NC.getDisplayName("CENTER_NM", "물류센터명")
         *         ],
         *         queryParams: {
         *             P_CENTER_CD: $ND.C_ALL
         *         }
         *     }, onCenterPopup, function() {
         *         $NC.setFocus("#edtQCenter_Cd", true);
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function showCenterPopup(options, onPopupSelect, onPopupCancel) {

            var requestData;
            if ($NC.isNull(options)) {
                return;
            }

            // 호출방법1일 경우, 파라메터 조정
            if ($NC.isNull(options.queryParams)) {
                options = {
                    queryParams: options
                };
            }

            _setTitleOptions(options,
            // 팝업 타이틀
            $NC.getDisplayName("POPUP_CENTER_CD", "물류센터"),
            // 기본 컬럼타이틀
            [
                $NC.getDisplayName("CENTER_CD", "물류센터코드"),
                $NC.getDisplayName("CENTER_NM", "물류센터명")
            ],
            // 컬럼 정보
            [
                {
                    id: "CENTER_CD",
                    field: "CENTER_CD",
                    width: 70,
                    cssClass: "styCenter"
                },
                {
                    id: "CENTER_NM",
                    field: "CENTER_NM",
                    width: 150
                }
            ]);

            requestData = {
                containerId: "ctrCommonPopupCenter",
                title: options.title,
                autoInquiry: true,
                width: 400,
                height: 450,
                requestUrl: options.requestUrl,
                queryId: $NC.nullToDefault(options.queryId, "WC.POP_CMCENTER"),
                queryParams: options.queryParams,
                queryData: options.queryData,
                querySearchParam: $NC.nullToDefault(options.querySearchParam, "P_CENTER_CD"),
                queryCanAll: $NC.nullToDefault(options.queryCanAll, true),
                columns: options.columns,
                multiSelect: options.multiSelect,
                multiValue: options.multiValue,
                addBase: $NC.nullToDefault(options.addBase, ""),
                onSelect: onPopupSelect,
                onCancel: onPopupCancel,
                onClose: $THIS.onPopupClose
            };

            _showPopup(requestData);
        }

        /**
         * 상용코드 팝업
         * 
         * @param {Object}
         *        options 팝업 호출 옵션
         * 
         * <pre>
         * <b>호출 방법 1(단순 설정)</b>
         * options 에 쿼리 파라메터를 지정한 경우 파라메터를 제외하고 모두 기본값으로 팝업 실행
         * 
         * <b>호출 방법 2(상세 설정)</b>
         * title                [옵션]:      {String}        팝업 창 타이틀
         * columnTitle          [옵션]:      {Array}         컬럼 타이틀, ["코드", "명"], 미지정시 기본 값
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * queryParams          [필수]:      {String}        쿼리 파라메터 지정
         * querySearchParam     [옵션]:      {String}        팝업 창 검색시 검색 값을 입력할 파라메터 명
         * queryCanAll          [옵션]:      {String}        팝업 창 전체 검색 가능 여부
         * queryData            [옵션]:      {Array}         데이터, 데이터를 넘겨줄 경우 서비스 호출하지 않음
         * </pre>
         * 
         * @param {Function}
         *        onPopupSelect 선택 버튼 클릭시 호출될 이벤트
         * @param {Function}
         *        onPopupCancel 취소 버튼 클릭시 호출될 이벤트
         * @example
         * 
         * <pre>
         * Call:
         *     // 호출 방법 1(단순 설정)
         *     $NP.showCodePopup({
         *         P_COMMON_GRP: "LI.INBOUND_STATE",
         *         P_COMMON_CD: $ND.C_ALL,
         *         P_VIEW_DIV: "1"
         *     }, onCodePopup, function() {
         *         $NC.setFocus("#edtQInbound_State", true);
         *     });
         * 
         *     // 호출 방법 2(상세 설정)
         *     $NP.showCodePopup({
         *         title: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "공통코드 검색"),
         *         columnTitle: [
         *             $NC.getDisplayName("COMMON_CD", "공통코드"),
         *             $NC.getDisplayName("COMMON_NM", "공통코드명")
         *         ],
         *         queryParams: {
         *             P_COMMON_GRP: "LI.INBOUND_STATE",
         *             P_COMMON_CD: $ND.C_ALL,
         *             P_VIEW_DIV: "1"
         *         }
         *     }, onCodePopup, function() {
         *         $NC.setFocus("#edtQInbound_State", true);
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function showCodePopup(options, onPopupSelect, onPopupCancel) {

            var requestData;
            if ($NC.isNull(options)) {
                return;
            }

            // 호출방법1일 경우, 파라메터 조정
            if ($NC.isNull(options.queryParams)) {
                options = {
                    queryParams: options
                };
            }

            _setTitleOptions(options,
            // 팝업 타이틀
            $NC.getDisplayName("POPUP_COMMON_CD", "공통코드"),
            // 기본 컬럼타이틀
            [
                $NC.getDisplayName("COMMON_CD", "공통코드"),
                $NC.getDisplayName("COMMON_NM", "공통코드명")
            ],
            // 컬럼 정보
            [
                {
                    id: "COMMON_CD",
                    field: "COMMON_CD",
                    width: 70,
                    cssClass: "styCenter"
                },
                {
                    id: "COMMON_NM",
                    field: "COMMON_NM",
                    width: 150
                }
            ]);

            requestData = {
                containerId: "ctrCommonPopupCode",
                title: options.title,
                autoInquiry: true,
                width: 400,
                height: 450,
                requestUrl: options.requestUrl,
                queryId: $NC.nullToDefault(options.queryId, "WC.POP_CMCODE"),
                queryParams: options.queryParams,
                queryData: options.queryData,
                querySearchParam: $NC.nullToDefault(options.querySearchParam, "P_COMMON_CD"),
                queryCanAll: $NC.nullToDefault(options.queryCanAll, true),
                columns: options.columns,
                multiSelect: options.multiSelect,
                multiValue: options.multiValue,
                addBase: $NC.nullToDefault(options.addBase, ""),
                onSelect: onPopupSelect,
                onCancel: onPopupCancel,
                onClose: $THIS.onPopupClose
            };

            _showPopup(requestData);
        }

        /**
         * 고객사 팝업
         * 
         * @param {Object}
         *        options 팝업 호출 옵션
         * 
         * <pre>
         * <b>호출 방법 1(단순 설정)</b>
         * options 에 쿼리 파라메터를 지정한 경우 파라메터를 제외하고 모두 기본값으로 팝업 실행
         * 
         * <b>호출 방법 2(상세 설정)</b>
         * title                [옵션]:      {String}        팝업 창 타이틀
         * columnTitle          [옵션]:      {Array}         컬럼 타이틀, ["코드", "명"], 미지정시 기본 값
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * queryParams          [필수]:      {String}        쿼리 파라메터 지정
         * querySearchParam     [옵션]:      {String}        팝업 창 검색시 검색 값을 입력할 파라메터 명
         * queryCanAll          [옵션]:      {String}        팝업 창 전체 검색 가능 여부
         * queryData            [옵션]:      {Array}         데이터, 데이터를 넘겨줄 경우 서비스 호출하지 않음
         * </pre>
         * 
         * @param {Function}
         *        onPopupSelect 선택 버튼 클릭시 호출될 이벤트
         * @param {Function}
         *        onPopupCancel 취소 버튼 클릭시 호출될 이벤트
         * @example
         * 
         * <pre>
         * Call:
         *     // 호출 방법 1(단순 설정)
         *     $NP.showCustPopup({
         *         P_CUST_CD: CUST_CD
         *     }, onCustPopup, function() {
         *         $NC.setFocus("#edtQCust_Cd", true);
         *     });
         * 
         *     // 호출 방법 2(상세 설정)
         *     $NP.showCustPopup({
         *         title: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "고객사 검색"),
         *         columnTitle: [
         *             $NC.getDisplayName("CUST_CD", "고객사코드"),
         *             $NC.getDisplayName("CUST_NM", "고객사명")
         *         ],
         *         queryParams: {
         *             P_CUST_CD: CUST_CD
         *         }
         *     }, onCustPopup, function() {
         *         $NC.setFocus("#edtQCust_Cd", true);
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function showCustPopup(options, onPopupSelect, onPopupCancel) {

            var requestData;
            if ($NC.isNull(options)) {
                return;
            }

            // 호출방법1일 경우, 파라메터 조정
            if ($NC.isNull(options.queryParams)) {
                options = {
                    queryParams: options
                };
            }

            _setTitleOptions(options,
            // 팝업 타이틀
            $NC.getDisplayName("POPUP_CUST_CD", "고객사"),
            // 기본 컬럼타이틀
            [
                $NC.getDisplayName("CUST_CD", "고객사코드"),
                $NC.getDisplayName("CUST_NM", "고객사명")
            ],
            // 컬럼 정보
            [
                {
                    id: "CUST_CD",
                    field: "CUST_CD",
                    width: 70,
                    cssClass: "styCenter"
                },
                {
                    id: "CUST_NM",
                    field: "CUST_NM",
                    width: 150
                }
            ]);

            requestData = {
                containerId: "ctrCommonPopupCust",
                title: options.title,
                autoInquiry: true,
                width: 400,
                height: 450,
                requestUrl: options.requestUrl,
                queryId: $NC.nullToDefault(options.queryId, "WC.POP_CMCUST"),
                queryParams: options.queryParams,
                queryData: options.queryData,
                querySearchParam: $NC.nullToDefault(options.querySearchParam, "P_CUST_CD"),
                queryCanAll: $NC.nullToDefault(options.queryCanAll, true),
                columns: options.columns,
                multiSelect: options.multiSelect,
                multiValue: options.multiValue,
                addBase: $NC.nullToDefault(options.addBase, ""),
                onSelect: onPopupSelect,
                onCancel: onPopupCancel,
                onClose: $THIS.onPopupClose
            };

            _showPopup(requestData);
        }

        /**
         * 배송처 팝업
         * 
         * @param {Object}
         *        options 팝업 호출 옵션
         * 
         * <pre>
         * <b>호출 방법 1(단순 설정)</b>
         * options 에 쿼리 파라메터를 지정한 경우 파라메터를 제외하고 모두 기본값으로 팝업 실행
         * 
         * <b>호출 방법 2(상세 설정)</b>
         * title                [옵션]:      {String}        팝업 창 타이틀
         * columnTitle          [옵션]:      {Array}         컬럼 타이틀, ["코드", "명"], 미지정시 기본 값
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * queryParams          [필수]:      {String}        쿼리 파라메터 지정
         * querySearchParam     [옵션]:      {String}        팝업 창 검색시 검색 값을 입력할 파라메터 명
         * queryCanAll          [옵션]:      {String}        팝업 창 전체 검색 가능 여부
         * queryData            [옵션]:      {Array}         데이터, 데이터를 넘겨줄 경우 서비스 호출하지 않음
         * </pre>
         * 
         * @param {Function}
         *        onPopupSelect 선택 버튼 클릭시 호출될 이벤트
         * @param {Function}
         *        onPopupCancel 취소 버튼 클릭시 호출될 이벤트
         * @example
         * 
         * <pre>
         * Call:
         *     // 호출 방법 1(단순 설정)
         *     $NP.showDeliveryPopup({
         *         P_CUST_CD: CUST_CD,
         *         P_DELIVERY_CD: $ND.C_ALL,
         *         P_DELIVERY_DIV: $ND.C_ALL,
         *         P_VIEW_DIV: "2"
         *     }, onDeliveryPopup, function() {
         *         $NC.setFocus("#edtQDelivery_Cd", true);
         *     });
         * 
         *     // 호출 방법 2(상세 설정)
         *     $NP.showDeliveryPopup({
         *         title: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "온라인몰 검색"),
         *         columnTitle: [
         *             $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "온라인몰코드"),
         *             $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "온라인몰명")
         *         ],
         *         queryParams: {
         *             P_CUST_CD: CUST_CD,
         *             P_DELIVERY_CD: $ND.C_ALL,
         *             P_DELIVERY_DIV: "92", // 92 - 온라인몰
         *             P_VIEW_DIV: "2"
         *         }
         *     }, onDeliveryPopup, function() {
         *         $NC.setFocus("#edtQDelivery_Cd", true);
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function showDeliveryPopup(options, onPopupSelect, onPopupCancel) {

            var queryParams, requestData;
            if ($NC.isNull(options)) {
                return;
            }

            // 호출방법1일 경우, 파라메터 조정
            if ($NC.isNull(options.queryParams)) {
                options = {
                    queryParams: options
                };
            }

            _setTitleOptions(options,
            // 팝업 타이틀
            $NC.getDisplayName("POPUP_DELIVERY_CD", "배송처"),
            // 기본 컬럼타이틀
            [
                $NC.getDisplayName("DELIVERY_CD", "배송처코드"),
                $NC.getDisplayName("DELIVERY_NM", "배송처명")
            ],
            // 컬럼 정보
            [
                {
                    id: "DELIVERY_CD",
                    field: "DELIVERY_CD",
                    width: 70
                },
                {
                    id: "DELIVERY_NM",
                    field: "DELIVERY_NM",
                    width: 150
                }
            ]);

            queryParams = $NC.nullToDefault(options.queryParams, options);
            if (!("P_DELIVERY_DIV" in queryParams)) {
                queryParams["P_DELIVERY_DIV"] = $ND.C_ALL;
            }

            requestData = {
                containerId: "ctrCommonPopupDelivery",
                title: options.title,
                autoInquiry: false,
                width: 400,
                height: 450,
                requestUrl: options.requestUrl,
                queryId: $NC.nullToDefault(options.queryId, "WC.POP_CMDELIVERY"),
                queryParams: options.queryParams,
                queryData: options.queryData,
                querySearchParam: $NC.nullToDefault(options.querySearchParam, "P_DELIVERY_CD"),
                queryCanAll: $NC.nullToDefault(options.queryCanAll, true),
                columns: options.columns,
                multiSelect: options.multiSelect,
                multiValue: options.multiValue,
                addBase: $NC.nullToDefault(options.addBase, ""),
                onSelect: onPopupSelect,
                onCancel: onPopupCancel,
                onClose: $THIS.onPopupClose
            };

            _showPopup(requestData);
        }

        /**
         * 부서 팝업
         * 
         * @param {Object}
         *        options 팝업 호출 옵션
         * 
         * <pre>
         * <b>호출 방법 1(단순 설정)</b>
         * options 에 쿼리 파라메터를 지정한 경우 파라메터를 제외하고 모두 기본값으로 팝업 실행
         * 
         * <b>호출 방법 2(상세 설정)</b>
         * title                [옵션]:      {String}        팝업 창 타이틀
         * columnTitle          [옵션]:      {Array}         컬럼 타이틀, ["코드", "명"], 미지정시 기본 값
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * queryParams          [필수]:      {String}        쿼리 파라메터 지정
         * querySearchParam     [옵션]:      {String}        팝업 창 검색시 검색 값을 입력할 파라메터 명
         * queryCanAll          [옵션]:      {String}        팝업 창 전체 검색 가능 여부
         * queryData            [옵션]:      {Array}         데이터, 데이터를 넘겨줄 경우 서비스 호출하지 않음
         * </pre>
         * 
         * @param {Function}
         *        onPopupSelect 선택 버튼 클릭시 호출될 이벤트
         * @param {Function}
         *        onPopupCancel 취소 버튼 클릭시 호출될 이벤트
         * @example
         * 
         * <pre>
         * Call:
         *     // 호출 방법 1(단순 설정)
         *     $NP.showDeptPopup({
         *         P_CUST_CD: CUST_CD,
         *         P_DEPT_CD: $ND.C_ALL,
         *         P_VIEW_DIV: "2"
         *     }, onDeptPopup, function() {
         *         $NC.setFocus("#edtQDept_Cd", true);
         *     });
         * 
         *     // 호출 방법 2(상세 설정)
         *     $NP.showDeptPopup({
         *         title: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "부서 검색"),
         *         columnTitle: [
         *             $NC.getDisplayName("DEPT_CD", "부서코드"),
         *             $NC.getDisplayName("DEPT_NM", "부서명")
         *         ],
         *         queryParams: {
         *             P_CUST_CD: CUST_CD,
         *             P_DEPT_CD: $ND.C_ALL,
         *             P_VIEW_DIV: "2"
         *         }
         *     }, onDeptPopup, function() {
         *         $NC.setFocus("#edtQDept_Cd", true);
         *     });
         * </pre>
         * 
         * @since 7.0.0
         * @memberof $NP#
         */
        function showDeptPopup(options, onPopupSelect, onPopupCancel) {

            var requestData;
            if ($NC.isNull(options)) {
                return;
            }

            // 호출방법1일 경우, 파라메터 조정
            if ($NC.isNull(options.queryParams)) {
                options = {
                    queryParams: options
                };
            }

            _setTitleOptions(options,
            // 팝업 타이틀
            $NC.getDisplayName("POPUP_DEPT_CD", "부서"),
            // 기본 컬럼타이틀
            [
                $NC.getDisplayName("DEPT_CD", "부서코드"),
                $NC.getDisplayName("DEPT_NM", "부서명")
            ],
            // 컬럼 정보
            [
                {
                    id: "DEPT_CD",
                    field: "DEPT_CD",
                    width: 70
                },
                {
                    id: "DEPT_NM",
                    field: "DEPT_NM",
                    width: 150
                }
            ]);

            requestData = {
                containerId: "ctrCommonPopupDept",
                title: options.title,
                autoInquiry: false,
                width: 400,
                height: 450,
                requestUrl: options.requestUrl,
                queryId: $NC.nullToDefault(options.queryId, "WC.POP_CMDEPT"),
                queryParams: options.queryParams,
                queryData: options.queryData,
                querySearchParam: $NC.nullToDefault(options.querySearchParam, "P_DEPT_CD"),
                queryCanAll: $NC.nullToDefault(options.queryCanAll, true),
                columns: options.columns,
                multiSelect: options.multiSelect,
                multiValue: options.multiValue,
                addBase: $NC.nullToDefault(options.addBase, ""),
                onSelect: onPopupSelect,
                onCancel: onPopupCancel,
                onClose: $THIS.onPopupClose
            };

            _showPopup(requestData);
        }

        /**
         * 운송권역 팝업
         * 
         * @param {Object}
         *        options 팝업 호출 옵션
         * 
         * <pre>
         * <b>호출 방법 1(단순 설정)</b>
         * options 에 쿼리 파라메터를 지정한 경우 파라메터를 제외하고 모두 기본값으로 팝업 실행
         * 
         * <b>호출 방법 2(상세 설정)</b>
         * title                [옵션]:      {String}        팝업 창 타이틀
         * columnTitle          [옵션]:      {Array}         컬럼 타이틀, ["코드", "명"], 미지정시 기본 값
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * queryParams          [필수]:      {String}        쿼리 파라메터 지정
         * querySearchParam     [옵션]:      {String}        팝업 창 검색시 검색 값을 입력할 파라메터 명
         * queryCanAll          [옵션]:      {String}        팝업 창 전체 검색 가능 여부
         * queryData            [옵션]:      {Array}         데이터, 데이터를 넘겨줄 경우 서비스 호출하지 않음
         * </pre>
         * 
         * @param {Function}
         *        onPopupSelect 선택 버튼 클릭시 호출될 이벤트
         * @param {Function}
         *        onPopupCancel 취소 버튼 클릭시 호출될 이벤트
         * @example
         * 
         * <pre>
         * Call:
         *     // 호출 방법 1(단순 설정)
         *     $NP.showDeliveryAreaPopup({
         *         P_CENTER_CD: CENTER_CD,
         *         P_AREA_CD: $ND.C_ALL
         *     }, showDeliveryAreaPopup, function() {
         *         $NC.setFocus("#edtQArea_Cd", true);
         *     });
         * 
         *     // 호출 방법 2(상세 설정)
         *     $NP.showDeliveryAreaPopup({
         *         title: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "운송권역 검색"),
         *         columnTitle: [
         *             $NC.getDisplayName("AREA_CD", "운송권역코드"),
         *             $NC.getDisplayName("AREA_NM", "운송권역명")
         *         ],
         *         queryParams: {
         *             P_CENTER_CD: CENTER_CD,
         *             P_AREA_CD: $ND.C_ALL
         *         }
         *     }, showDeliveryAreaPopup, function() {
         *         $NC.setFocus("#edtQArea_Cd", true);
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function showDeliveryAreaPopup(options, onPopupSelect, onPopupCancel) {

            var requestData;
            if ($NC.isNull(options)) {
                return;
            }

            // 호출방법1일 경우, 파라메터 조정
            if ($NC.isNull(options.queryParams)) {
                options = {
                    queryParams: options
                };
            }

            _setTitleOptions(options,
            // 팝업 타이틀
            $NC.getDisplayName("POPUP_AREA_CD", "운송권역"),
            // 기본 컬럼타이틀
            [
                $NC.getDisplayName("AREA_CD", "운송권역코드"),
                $NC.getDisplayName("AREA_NM", "운송권역명")
            ],
            // 컬럼 정보
            [
                {
                    id: "AREA_CD",
                    field: "AREA_CD",
                    width: 70,
                    cssClass: "styCenter"
                },
                {
                    id: "AREA_NM",
                    field: "AREA_NM",
                    width: 150
                }
            ]);

            requestData = {
                containerId: "ctrCommonPopupDeliveryArea",
                title: options.title,
                autoInquiry: true,
                width: 400,
                height: 450,
                requestUrl: options.requestUrl,
                queryId: $NC.nullToDefault(options.queryId, "WC.POP_CMDELIVERYAREA"),
                queryParams: options.queryParams,
                queryData: options.queryData,
                querySearchParam: $NC.nullToDefault(options.querySearchParam, "P_AREA_CD"),
                queryCanAll: $NC.nullToDefault(options.queryCanAll, true),
                columns: options.columns,
                multiSelect: options.multiSelect,
                multiValue: options.multiValue,
                addBase: $NC.nullToDefault(options.addBase, ""),
                onSelect: onPopupSelect,
                onCancel: onPopupCancel,
                onClose: $THIS.onPopupClose
            };

            _showPopup(requestData);
        }

        /**
         * 공급처 팝업
         * 
         * @param {Object}
         *        options 팝업 호출 옵션
         * 
         * <pre>
         * <b>호출 방법 1(단순 설정)</b>
         * options 에 쿼리 파라메터를 지정한 경우 파라메터를 제외하고 모두 기본값으로 팝업 실행
         * 
         * <b>호출 방법 2(상세 설정)</b>
         * title                [옵션]:      {String}        팝업 창 타이틀
         * columnTitle          [옵션]:      {Array}         컬럼 타이틀, ["코드", "명"], 미지정시 기본 값
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * queryParams          [필수]:      {String}        쿼리 파라메터 지정
         * querySearchParam     [옵션]:      {String}        팝업 창 검색시 검색 값을 입력할 파라메터 명
         * queryCanAll          [옵션]:      {String}        팝업 창 전체 검색 가능 여부
         * queryData            [옵션]:      {Array}         데이터, 데이터를 넘겨줄 경우 서비스 호출하지 않음
         * </pre>
         * 
         * @param {Function}
         *        onPopupSelect 선택 버튼 클릭시 호출될 이벤트
         * @param {Function}
         *        onPopupCancel 취소 버튼 클릭시 호출될 이벤트
         * @example
         * 
         * <pre>
         * Call:
         *     // 호출 방법 1(단순 설정)
         *     $NP.showVendorPopup({
         *         P_CUST_CD: CUST_CD,
         *         P_VENDOR_CD: $ND.C_ALL,
         *         P_VIEW_DIV: "2"
         *     }, onVendorPopup, function() {
         *         $NC.setFocus("#edtQVendor_Cd", true);
         *     });
         * 
         *     // 호출 방법 2(상세 설정)
         *     $NP.showVendorPopup({
         *         title: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "공급처 검색"),
         *         columnTitle: [
         *             $NC.getDisplayName("VENDOR_CD", "공급처코드"),
         *             $NC.getDisplayName("VENDOR_NM", "공급처명")
         *         ],
         *         queryParams: {
         *             P_CUST_CD: CUST_CD,
         *             P_VENDOR_CD: $ND.C_ALL,
         *             P_VIEW_DIV: "2"
         *         }
         *     }, onVendorPopup, function() {
         *         $NC.setFocus("#edtQVendor_Cd", true);
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function showVendorPopup(options, onPopupSelect, onPopupCancel) {

            var requestData;
            if ($NC.isNull(options)) {
                return;
            }

            // 호출방법1일 경우, 파라메터 조정
            if ($NC.isNull(options.queryParams)) {
                options = {
                    queryParams: options
                };
            }

            _setTitleOptions(options,
            // 팝업 타이틀
            $NC.getDisplayName("POPUP_VENDOR_CD", "공급처"),
            // 기본 컬럼타이틀
            [
                $NC.getDisplayName("VENDOR_CD", "공급처코드"),
                $NC.getDisplayName("VENDOR_NM", "공급처명")
            ],
            // 컬럼 정보
            [
                {
                    id: "VENDOR_CD",
                    field: "VENDOR_CD",
                    width: 70
                },
                {
                    id: "VENDOR_NM",
                    field: "VENDOR_NM",
                    width: 150
                }
            ]);

            requestData = {
                containerId: "ctrCommonPopupVendor",
                title: options.title,
                autoInquiry: false,
                width: 400,
                height: 450,
                requestUrl: options.requestUrl,
                queryId: $NC.nullToDefault(options.queryId, "WC.POP_CMVENDOR"),
                queryParams: options.queryParams,
                queryData: options.queryData,
                querySearchParam: $NC.nullToDefault(options.querySearchParam, "P_VENDOR_CD"),
                queryCanAll: $NC.nullToDefault(options.queryCanAll, true),
                columns: options.columns,
                multiSelect: options.multiSelect,
                multiValue: options.multiValue,
                addBase: $NC.nullToDefault(options.addBase, ""),
                onSelect: onPopupSelect,
                onCancel: onPopupCancel,
                onClose: $THIS.onPopupClose
            };

            _showPopup(requestData);
        }

        /**
         * 상품 팝업
         * 
         * @param {Object}
         *        options 팝업 호출 옵션
         * 
         * <pre>
         * <b>호출 방법 1(단순 설정)</b>
         * options 에 쿼리 파라메터를 지정한 경우 파라메터를 제외하고 모두 기본값으로 팝업 실행
         * 
         * <b>호출 방법 2(상세 설정)</b>
         * title                [옵션]:      {String}        팝업 창 타이틀
         * columnTitle          [옵션]:      {Array}         컬럼 타이틀, ["코드", "명"], 미지정시 기본 값
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * queryParams          [필수]:      {String}        쿼리 파라메터 지정
         * querySearchParam     [옵션]:      {String}        팝업 창 검색시 검색 값을 입력할 파라메터 명
         * queryCanAll          [옵션]:      {String}        팝업 창 전체 검색 가능 여부
         * queryData            [옵션]:      {Array}         데이터, 데이터를 넘겨줄 경우 서비스 호출하지 않음
         * </pre>
         * 
         * @param {Function}
         *        onPopupSelect 선택 버튼 클릭시 호출될 이벤트
         * @param {Function}
         *        onPopupCancel 취소 버튼 클릭시 호출될 이벤트
         * @example
         * 
         * <pre>
         * Call:
         *     // 호출 방법 1(단순 설정)
         *     $NP.showItemPopup({
         *         P_BU_CD: BU_CD,
         *         P_BRAND_CD: BRAND_CD,
         *         P_ITEM_CD: $ND.C_ALL,
         *         P_VIEW_DIV: "2",
         *         P_DEPART_CD: $ND.C_ALL,
         *         P_LINE_CD: $ND.C_ALL,
         *         P_CLASS_CD: $ND.C_ALL
         *     }, onItemPopup, function() {
         *         $NC.setFocus("#edtQItem_Cd", true);
         *     });
         * 
         *     // 호출 방법 2(상세 설정)
         *     $NP.showItemPopup({
         *         title: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "상품 검색"),
         *         columnTitle: [
         *             $NC.getDisplayName("ITEM_CD", "상품코드"),
         *             $NC.getDisplayName("ITEM_BAR_CD", "상품바코드"),
         *             $NC.getDisplayName("ITEM_NM", "상품명"),
         *             $NC.getDisplayName("ITEM_SPEC", "규격"),
         *             $NC.getDisplayName("BRAND_NM", "브랜드명")
         *         ],
         *         queryParams: {
         *             P_BU_CD: BU_CD,
         *             P_BRAND_CD: BRAND_CD,
         *             P_ITEM_CD: $ND.C_ALL,
         *             P_VIEW_DIV: "2",
         *             P_DEPART_CD: $ND.C_ALL,
         *             P_LINE_CD: $ND.C_ALL,
         *             P_CLASS_CD: $ND.C_ALL
         *         }
         *     }, onItemPopup, function() {
         *         $NC.setFocus("#edtQItem_Cd", true);
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function showItemPopup(options, onPopupSelect, onPopupCancel) {

            var requestData;
            if ($NC.isNull(options)) {
                return;
            }

            // 호출방법1일 경우, 파라메터 조정
            if ($NC.isNull(options.queryParams)) {
                options = {
                    queryParams: options
                };
            }

            _setTitleOptions(options,
            // 팝업 타이틀
            $NC.getDisplayName("POPUP_ITEM_CD", "상품"),
            // 기본 컬럼타이틀
            [
                $NC.getDisplayName("ITEM_CD", "상품코드"),
                $NC.getDisplayName("ITEM_BAR_CD", "상품바코드"),
                $NC.getDisplayName("ITEM_NM", "상품명"),
                $NC.getDisplayName("ITEM_SPEC", "규격"),
                $NC.getDisplayName("BRAND_NM", "브랜드명")
            ],
            // 컬럼 정보
            [
                {
                    id: "ITEM_CD",
                    field: "ITEM_CD",
                    width: 90
                },
                {
                    id: "ITEM_BAR_CD",
                    field: "ITEM_BAR_CD",
                    width: 120
                },
                {
                    id: "ITEM_NM",
                    field: "ITEM_NM",
                    width: 150
                },
                {
                    id: "ITEM_SPEC",
                    field: "ITEM_SPEC",
                    width: 100
                },
                {
                    id: "BRAND_NM",
                    field: "BRAND_NM",
                    width: 120
                }
            ]);

            requestData = {
                containerId: "ctrCommonPopupItem",
                title: options.title,
                autoInquiry: false,
                width: 480, // 400, // 컬럼수가 많아 사이즈 조정
                height: 500, // 450,
                requestUrl: options.requestUrl,
                queryId: $NC.nullToDefault(options.queryId, "WC.POP_CMITEM"),
                queryParams: options.queryParams,
                queryData: options.queryData,
                querySearchParam: $NC.nullToDefault(options.querySearchParam, "P_ITEM_CD"),
                queryCanAll: $NC.nullToDefault(options.queryCanAll, true),
                columns: options.columns,
                multiSelect: options.multiSelect,
                multiValue: options.multiValue,
                addBase: $NC.nullToDefault(options.addBase, ""),
                onSelect: onPopupSelect,
                onCancel: onPopupCancel,
                onClose: $THIS.onPopupClose
            };

            _showPopup(requestData);
        }

        /**
         * 상품그룹 팝업
         * 
         * @param {Object}
         *        options 팝업 호출 옵션
         * 
         * <pre>
         * <b>호출 방법 1(단순 설정)</b>
         * options 에 쿼리 파라메터를 지정한 경우 파라메터를 제외하고 모두 기본값으로 팝업 실행
         * 
         * <b>호출 방법 2(상세 설정)</b>
         * title                [옵션]:      {String}        팝업 창 타이틀
         * columnTitle          [옵션]:      {Array}         컬럼 타이틀, ["코드", "명"], 미지정시 기본 값
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * queryParams          [필수]:      {String}        쿼리 파라메터 지정
         * querySearchParam     [옵션]:      {String}        팝업 창 검색시 검색 값을 입력할 파라메터 명
         * queryCanAll          [옵션]:      {String}        팝업 창 전체 검색 가능 여부
         * queryData            [옵션]:      {Array}         데이터, 데이터를 넘겨줄 경우 서비스 호출하지 않음
         * </pre>
         * 
         * @param {Function}
         *        onPopupSelect 선택 버튼 클릭시 호출될 이벤트
         * @param {Function}
         *        onPopupCancel 취소 버튼 클릭시 호출될 이벤트
         * @example
         * 
         * <pre>
         * Call:
         *     // 호출 방법 1(단순 설정)
         *     $NP.showItemGroupPopup({
         *         P_CUST_CD: CUST_CD
         *     }, onItemGroupPopup, function() {
         *         $NC.setFocus("#edtQDepart_Cd", true);
         *     });
         * 
         *     // 호출 방법 2(상세 설정)
         *     $NP.showItemGroupPopup({
         *         title: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "상품그룹 검색"),
         *         columnTitle: [
         *             $NC.getDisplayName("DEPART_CD", "대분류코드"),
         *             $NC.getDisplayName("DEPART_NM", "대분류명"),
         *             $NC.getDisplayName("DEPART_NM", "대분류명"),
         *             $NC.getDisplayName("LINE_NM", "중분류명"),
         *             $NC.getDisplayName("CLASS_CD", "소분류코드"),
         *             $NC.getDisplayName("CLASS_NM", "소분류명")
         *         ],
         *         queryParams: {
         *             P_CUST_CD: CUST_CD
         *         }
         *     }, onItemGroupPopup, function() {
         *         $NC.setFocus("#edtQDepart_Cd", true);
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function showItemGroupPopup(options, onPopupSelect, onPopupCancel) {

            var requestData;
            if ($NC.isNull(options)) {
                return;
            }

            // 호출방법1일 경우, 파라메터 조정
            if ($NC.isNull(options.queryParams)) {
                options = {
                    queryParams: options
                };
            }

            _setTitleOptions(options,
            // 팝업 타이틀
            $NC.getDisplayName("POPUP_ITEM_GROUP", "상품그룹"),
            // 기본 컬럼타이틀
            [
                $NC.getDisplayName("DEPART_CD", "대분류코드"),
                $NC.getDisplayName("DEPART_NM", "대분류명"),
                $NC.getDisplayName("DEPART_NM", "대분류명"),
                $NC.getDisplayName("LINE_NM", "중분류명"),
                $NC.getDisplayName("CLASS_CD", "소분류코드"),
                $NC.getDisplayName("CLASS_NM", "소분류명")
            ],
            // 컬럼 정보
            [
                {
                    id: "DEPART_CD",
                    field: "DEPART_CD",
                    width: 70,
                    cssClass: "styCenter"
                },
                {
                    id: "DEPART_NM",
                    field: "DEPART_NM",
                    width: 100
                },
                {
                    id: "LINE_CD",
                    field: "LINE_CD",
                    width: 70,
                    cssClass: "styCenter"
                },
                {
                    id: "LINE_NM",
                    field: "LINE_NM",
                    width: 100
                },
                {
                    id: "CLASS_CD",
                    field: "CLASS_CD",
                    width: 70,
                    cssClass: "styCenter"
                },
                {
                    id: "CLASS_NM",
                    field: "CLASS_NM",
                    width: 100
                }
            ]);

            requestData = {
                containerId: "ctrCommonPopupItemGroup",
                title: options.title,
                autoInquiry: true,
                width: 500,
                height: 450,
                requestUrl: options.requestUrl,
                queryId: $NC.nullToDefault(options.queryId, "WC.POP_CMITEMGROUP"),
                queryParams: options.queryParams,
                queryData: options.queryData,
                querySearchParam: $NC.nullToDefault(options.querySearchParam, "P_BRAND_CD"),
                queryCanAll: $NC.nullToDefault(options.queryCanAll, true),
                columns: options.columns,
                multiSelect: options.multiSelect,
                multiValue: options.multiValue,
                addBase: $NC.nullToDefault(options.addBase, ""),
                onSelect: onPopupSelect,
                onCancel: onPopupCancel,
                onClose: $THIS.onPopupClose
            };

            _showPopup(requestData);
        }

        /**
         * 로케이션 팝업
         * 
         * @param {Object}
         *        options 팝업 호출 옵션
         * 
         * <pre>
         * <b>호출 방법 1(단순 설정)</b>
         * options 에 쿼리 파라메터를 지정한 경우 파라메터를 제외하고 모두 기본값으로 팝업 실행
         * 
         * <b>호출 방법 2(상세 설정)</b>
         * title                [옵션]:      {String}        팝업 창 타이틀
         * columnTitle          [옵션]:      {Array}         컬럼 타이틀, ["코드", "명"], 미지정시 기본 값
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * queryParams          [필수]:      {String}        쿼리 파라메터 지정
         * querySearchParam     [옵션]:      {String}        팝업 창 검색시 검색 값을 입력할 파라메터 명
         * queryCanAll          [옵션]:      {String}        팝업 창 전체 검색 가능 여부
         * queryData            [옵션]:      {Array}         데이터, 데이터를 넘겨줄 경우 서비스 호출하지 않음
         * </pre>
         * 
         * @param {Function}
         *        onPopupSelect 선택 버튼 클릭시 호출될 이벤트
         * @param {Function}
         *        onPopupCancel 취소 버튼 클릭시 호출될 이벤트
         * @example
         * 
         * <pre>
         * Call:
         *     // 호출 방법 1(단순 설정)
         *     $NP.showLocationPopup({
         *         P_CENTER_CD: CENTER_CD,
         *         P_ZONE_CD: "",
         *         P_BANK_CD: "",
         *         P_BAY_CD: "",
         *         P_LEV_CD: "",
         *         P_LOCATION_CD: $ND.C_ALL,
         *         P_ZONE_DIV_ATTR01_CD: "1", // 존구분 특성01(존특성), 1 - 일반, 2- 유통가공, 3 - 보세
         *         P_INOUT_DIV: "1", // 1 - 입고(적치), 2 - 출고, NULL - 전체, 필수
         *         P_LOC_DIV_ATTR03_CD: "", // 로케이션구분 특성03(셀특성), 센터운영화면(필수)
         *         P_POLICY_VAL: "", // 입고(적치)/출고불가능 로케이션 사용 정책(입고 - LC410, 출고 - LC411), 기타입출고화면(필수)
         *     }, onLocationPopup, function() {
         *         $NC.setFocus("#edtQLocation_Cd", true);
         *     });
         * 
         *     // 호출 방법 1 - 1(입고(적치))
         *     $NP.showLocationPopup({
         *         P_CENTER_CD: CENTER_CD,
         *         P_ZONE_CD: "",
         *         P_BANK_CD: "",
         *         P_BAY_CD: "",
         *         P_LEV_CD: "",
         *         P_LOCATION_CD: $ND.C_ALL,
         *         P_ZONE_DIV_ATTR01_CD: "1", // 존구분 특성01(존특성), 1 - 일반, 2- 유통가공, 3 - 보세
         *         P_INOUT_DIV: "1" // 1 - 입고(적치), 2 - 출고, NULL - 전체, 필수
         *     }, onLocationPopup, function() {
         *         $NC.setFocus("#edtQLocation_Cd", true);
         *     });
         * 
         *     // 호출 방법 1 - 2(출고)
         *     $NP.showLocationPopup({
         *         P_CENTER_CD: CENTER_CD,
         *         P_ZONE_CD: "",
         *         P_BANK_CD: "",
         *         P_BAY_CD: "",
         *         P_LEV_CD: "",
         *         P_LOCATION_CD: $ND.C_ALL,
         *         P_ZONE_DIV_ATTR01_CD: "1", // 존구분 특성01(존특성), 1 - 일반, 2- 유통가공, 3 - 보세
         *         P_INOUT_DIV: "2" // 1 - 입고(적치), 2 - 출고, NULL - 전체, 필수
         *     }, onLocationPopup, function() {
         *         $NC.setFocus("#edtQLocation_Cd", true);
         *     });
         * 
         *     // 호출 방법 2(상세 설정)
         *     $NP.showLocationPopup({
         *         title: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "로케이션 검색"),
         *         columnTitle: [
         *             $NC.getDisplayName("ZONE_CD", "존코드"),
         *             $NC.getDisplayName("ZONE_NM", "존명"),
         *             $NC.getDisplayName("LOCATION_CD", "로케이션")
         *         ],
         *         queryParams: {
         *             P_CENTER_CD: CENTER_CD,
         *             P_ZONE_CD: "",
         *             P_BANK_CD: "",
         *             P_BAY_CD: "",
         *             P_LEV_CD: "",
         *             P_LOCATION_CD: $ND.C_ALL,
         *             P_ZONE_DIV_ATTR01_CD: "1", // 존구분 특성01(존특성), 1 - 일반, 2- 유통가공, 3 - 보세
         *             P_INOUT_DIV: "1", // 1 - 입고(적치), 2 - 출고, NULL - 전체, 필수
         *             P_LOC_DIV_ATTR03_CD: "", // 로케이션구분 특성03(셀특성), 센터운영화면(필수)
         *             P_POLICY_VAL: "", // 입고(적치)/출고불가능 로케이션 사용 정책(입고 - LC410, 출고 - LC411), 기타입출고화면(필수)
         *         }
         *     }, onLocationPopup, function() {
         *         $NC.setFocus("#edtQLocation_Cd", true);
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function showLocationPopup(options, onPopupSelect, onPopupCancel) {

            var requestData;
            if ($NC.isNull(options)) {
                return;
            }

            // 호출방법1일 경우, 파라메터 조정
            if ($NC.isNull(options.queryParams)) {
                options = {
                    queryParams: options
                };
            }

            _setTitleOptions(options,
            // 팝업 타이틀
            $NC.getDisplayName("POPUP_LOCATION_CD", "로케이션"),
            // 기본 컬럼타이틀
            [
                $NC.getDisplayName("ZONE_CD", "존코드"),
                $NC.getDisplayName("ZONE_NM", "존명"),
                $NC.getDisplayName("LOCATION_CD", "로케이션")
            ],
            // 컬럼 정보
            [
                {
                    id: "ZONE_CD",
                    field: "ZONE_CD",
                    width: 70,
                    cssClass: "styCenter"
                },
                {
                    id: "ZONE_NM",
                    field: "ZONE_NM",
                    width: 100
                },
                {
                    id: "LOCATION_CD",
                    field: "LOCATION_CD",
                    width: 100,
                    cssClass: "styCenter"
                }
            ]);

            requestData = {
                containerId: "ctrCommonPopupLocation",
                title: options.title,
                autoInquiry: false,
                width: 400,
                height: 450,
                requestUrl: options.requestUrl,
                queryId: $NC.nullToDefault(options.queryId, "WC.POP_CMLOCATION"),
                queryParams: options.queryParams,
                queryData: options.queryData,
                querySearchParam: $NC.nullToDefault(options.querySearchParam, "P_LOCATION_CD"),
                queryCanAll: $NC.nullToDefault(options.queryCanAll, true),
                columns: options.columns,
                multiSelect: options.multiSelect,
                multiValue: options.multiValue,
                addBase: $NC.nullToDefault(options.addBase, ""),
                onSelect: onPopupSelect,
                onCancel: onPopupCancel,
                onClose: $THIS.onPopupClose
            };

            _showPopup(requestData);
        }

        /**
         * 자재 팝업
         * 
         * @param {Object}
         *        options 팝업 호출 옵션
         * 
         * <pre>
         * <b>호출 방법 1(단순 설정)</b>
         * options 에 쿼리 파라메터를 지정한 경우 파라메터를 제외하고 모두 기본값으로 팝업 실행
         * 
         * <b>호출 방법 2(상세 설정)</b>
         * title                [옵션]:      {String}        팝업 창 타이틀
         * columnTitle          [옵션]:      {Array}         컬럼 타이틀, ["코드", "명"], 미지정시 기본 값
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * queryParams          [필수]:      {String}        쿼리 파라메터 지정
         * querySearchParam     [옵션]:      {String}        팝업 창 검색시 검색 값을 입력할 파라메터 명
         * queryCanAll          [옵션]:      {String}        팝업 창 전체 검색 가능 여부
         * queryData            [옵션]:      {Array}         데이터, 데이터를 넘겨줄 경우 서비스 호출하지 않음
         * </pre>
         * 
         * @param {Function}
         *        onPopupSelect 선택 버튼 클릭시 호출될 이벤트
         * @param {Function}
         *        onPopupCancel 취소 버튼 클릭시 호출될 이벤트
         * @example
         * 
         * <pre>
         * Call:
         *     // 호출 방법 1(단순 설정)
         *     $NP.showMaterialPopup({
         *             P_CUST_CD: CUST_CD,
         *             P_MATERIAL_CD: $ND.C_ALL
         *     }, onMaterialPopup, function() {
         *         $NC.setFocus("#edtQMaterial_Cd", true);
         *     });
         * 
         *     // 호출 방법 2(상세 설정)
         *     $NP.showMaterialPopup({
         *         title: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "자재 검색"),
         *         columnTitle: [
         *             $NC.getDisplayName("MATERIAL_CD", "자재코드"),
         *             $NC.getDisplayName("MATERIAL_NM", "자재명"),
         *             $NC.getDisplayName("PROCESSING_DIV_D", "가공작업구분"),
         *             $NC.getDisplayName("CUST_NM", "고객사명")
         *         ],
         *         queryParams: {
         *             P_CUST_CD: CUST_CD,
         *             P_MATERIAL_CD: $ND.C_ALL
         *         }
         *     }, onMaterialPopup, function() {
         *         $NC.setFocus("#edtQMaterial_Cd", true);
         *     });
         * </pre>
         * 
         * @since 7.5.0
         * @memberof $NP#
         */
        function showMaterialPopup(options, onPopupSelect, onPopupCancel) {

            var requestData;
            if ($NC.isNull(options)) {
                return;
            }

            // 호출방법1일 경우, 파라메터 조정
            if ($NC.isNull(options.queryParams)) {
                options = {
                    queryParams: options
                };
            }

            _setTitleOptions(options,
            // 팝업 타이틀
            $NC.getDisplayName("POPUP_MATERIAL_CD", "자재"),
            // 기본 컬럼타이틀
            [
                $NC.getDisplayName("MATERIAL_CD", "자재코드"),
                $NC.getDisplayName("MATERIAL_NM", "저재코드명"),
                $NC.getDisplayName("PROCESSING_DIV_D", "가공작업구분"),
                $NC.getDisplayName("CUST_NM", "고객사명")
            ],
            // 컬럼 정보
            [
                {
                    id: "MATERIAL_CD",
                    field: "MATERIAL_CD",
                    width: 70
                },
                {
                    id: "MATERIAL_NM",
                    field: "MATERIAL_NM",
                    width: 90
                },
                {
                    id: "PROCESSING_DIV_D",
                    field: "PROCESSING_DIV_D",
                    width: 90
                }
            ]);

            requestData = {
                containerId: "ctrCommonPopupMaterial",
                title: options.title,
                autoInquiry: false,
                width: 400,
                height: 450,
                requestUrl: options.requestUrl,
                queryId: $NC.nullToDefault(options.queryId, "WC.POP_CMMATERIAL"),
                queryParams: options.queryParams,
                queryData: options.queryData,
                querySearchParam: $NC.nullToDefault(options.querySearchParam, "P_MATERIAL_CD"),
                queryCanAll: $NC.nullToDefault(options.queryCanAll, true),
                columns: options.columns,
                multiSelect: options.multiSelect,
                multiValue: options.multiValue,
                addBase: $NC.nullToDefault(options.addBase, ""),
                onSelect: onPopupSelect,
                onCancel: onPopupCancel,
                onClose: $THIS.onPopupClose
            };

            _showPopup(requestData);
        }

        /**
         * 조직 팝업
         * 
         * @param {Object}
         *        options 팝업 호출 옵션
         * 
         * <pre>
         * <b>호출 방법 1(단순 설정)</b>
         * options 에 쿼리 파라메터를 지정한 경우 파라메터를 제외하고 모두 기본값으로 팝업 실행
         * 
         * <b>호출 방법 2(상세 설정)</b>
         * title                [옵션]:      {String}        팝업 창 타이틀
         * columnTitle          [옵션]:      {Array}         컬럼 타이틀, ["코드", "명"], 미지정시 기본 값
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * queryParams          [필수]:      {String}        쿼리 파라메터 지정
         * querySearchParam     [옵션]:      {String}        팝업 창 검색시 검색 값을 입력할 파라메터 명
         * queryCanAll          [옵션]:      {String}        팝업 창 전체 검색 가능 여부
         * queryData            [옵션]:      {Array}         데이터, 데이터를 넘겨줄 경우 서비스 호출하지 않음
         * </pre>
         * 
         * @param {Function}
         *        onPopupSelect 선택 버튼 클릭시 호출될 이벤트
         * @param {Function}
         *        onPopupCancel 취소 버튼 클릭시 호출될 이벤트
         * @example
         * 
         * <pre>
         * Call:
         *     // 호출 방법 1(단순 설정)
         *     $NP.showOrgnPopup({
         *         P_ORGN_DIV: "1", // 1-조직, 2-서비스
         *         P_ORGN_CD: $ND.C_ALL,
         *         P_VIEW_DIV: "2"
         *     }, onOrgnPopup, function() {
         *         $NC.setFocus("#edtQOrgn_Cd", true);
         *     });
         * 
         *     // 호출 방법 2(상세 설정)
         *     $NP.showOrgnPopup({
         *         title: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "조직 검색"),
         *         columnTitle: [
         *             $NC.getDisplayName("ORGN_CD", "조직코드"),
         *             $NC.getDisplayName("ORGN_NM", "조직명")
         *         ],
         *         queryParams: {
         *             P_ORGN_DIV: "1", // 1-조직, 2-서비스
         *             P_ORGN_CD: $ND.C_ALL,
         *             P_VIEW_DIV: "2"
         *         }
         *     }, onOrgnPopup, function() {
         *         $NC.setFocus("#edtQOrgn_Cd", true);
         *     });
         * </pre>
         * 
         * @since 7.1.0
         * @memberof $NP#
         */
        function showOrgnPopup(options, onPopupSelect, onPopupCancel) {

            var requestData;
            if ($NC.isNull(options)) {
                return;
            }

            // 호출방법1일 경우, 파라메터 조정
            if ($NC.isNull(options.queryParams)) {
                options = {
                    queryParams: options
                };
            }

            _setTitleOptions(options,
            // 팝업 타이틀
            $NC.getDisplayName("POP_CMORGN", "조직"),
            // 기본 컬럼타이틀
            [
                $NC.getDisplayName("ORGN_CD", "조직코드"),
                $NC.getDisplayName("ORGN_NM", "조직명")
            ],
            // 컬럼 정보
            [
                {
                    id: "ORGN_CD",
                    field: "ORGN_CD",
                    width: 70,
                    cssClass: "styCenter"
                },
                {
                    id: "ORGN_NM",
                    field: "ORGN_NM",
                    width: 100
                }
            ]);

            requestData = {
                containerId: "ctrCommonPopupOrgn",
                title: options.title,
                autoInquiry: false,
                width: 400,
                height: 450,
                requestUrl: options.requestUrl,
                queryId: $NC.nullToDefault(options.queryId, "WC.POP_CMORGN"),
                queryParams: options.queryParams,
                queryData: options.queryData,
                querySearchParam: $NC.nullToDefault(options.querySearchParam, "P_ORGN_CD"),
                queryCanAll: $NC.nullToDefault(options.queryCanAll, true),
                columns: options.columns,
                multiSelect: options.multiSelect,
                multiValue: options.multiValue,
                addBase: $NC.nullToDefault(options.addBase, ""),
                onSelect: onPopupSelect,
                onCancel: onPopupCancel,
                onClose: $THIS.onPopupClose
            };

            _showPopup(requestData);
        }

        /**
         * 우편번호 팝업
         * 
         * @param {Object}
         *        options 팝업 호출 옵션
         * 
         * <pre>
         * <b>호출 방법 1(단순 설정)</b>
         * options 에 쿼리 파라메터를 지정한 경우 파라메터를 제외하고 모두 기본값으로 팝업 실행
         * 
         * <b>호출 방법 2(상세 설정)</b>
         * title                [옵션]:      {String}        팝업 창 타이틀
         * columnTitle          [옵션]:      {Array}         컬럼 타이틀, ["코드", "명"], 미지정시 기본 값
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * queryParams          [필수]:      {String}        쿼리 파라메터 지정
         * querySearchParam     [옵션]:      {String}        팝업 창 검색시 검색 값을 입력할 파라메터 명
         * queryCanAll          [옵션]:      {String}        팝업 창 전체 검색 가능 여부
         * queryData            [옵션]:      {Array}         데이터, 데이터를 넘겨줄 경우 서비스 호출하지 않음
         * </pre>
         * 
         * @param {Function}
         *        onPopupSelect 선택 버튼 클릭시 호출될 이벤트
         * @param {Function}
         *        onPopupCancel 취소 버튼 클릭시 호출될 이벤트
         * @example
         * 
         * <pre>
         * Call:
         *     // 호출 방법 1(단순 설정)
         *     $NP.showPostPopup({
         *         P_ADDR_NM: $ND.C_ALL
         *     }, onPostPopup, function() {
         *         $NC.setFocus("#edtQAddr_Detail", true);
         *     });
         * 
         *     // 호출 방법 2(상세 설정)
         *     $NP.showPostPopup({
         *         title: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "우편번호 검색"),
         *         columnTitle: [
         *             $NC.getDisplayName("ZIP_CD", "우편번호"),
         *             $NC.getDisplayName("ADDR_NM", "주소")
         *         ],
         *         queryParams: {
         *             P_ADDR_NM: $ND.C_ALL
         *         }
         *     }, onPostPopup, function() {
         *         $NC.setFocus("#edtQAddr_Detail", true);
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function showPostPopup(options, onPopupSelect, onPopupCancel) {

            var requestData;
            if ($THIS.G_USE_DAUM_POSTCODE) {
                $THIS.showDaumPostcodePopup(options, onPopupSelect, onPopupCancel);
                return;
            }

            if ($NC.isNull(options)) {
                return;
            }

            // 호출방법1일 경우, 파라메터 조정
            if ($NC.isNull(options.queryParams)) {
                options = {
                    queryParams: options
                };
            }

            _setTitleOptions(options,
            // 팝업 타이틀
            $NC.getDisplayName("POPUP_ZIP_CD", "우편번호"),
            // 기본 컬럼타이틀
            [
                $NC.getDisplayName("ZIP_CD", "우편번호"),
                $NC.getDisplayName("ADDR_NM", "주소")
            ],
            // 컬럼 정보
            [
                {
                    id: "ZIP_CD",
                    field: "ZIP_CD",
                    width: 70,
                    cssClass: "styCenter"
                },
                {
                    id: "ADDR_NM",
                    field: "ADDR_NM",
                    width: 150
                }
            ]);

            requestData = {
                containerId: "ctrCommonPopupZip",
                title: options.title,
                autoInquiry: false,
                width: 400,
                height: 450,
                requestUrl: options.requestUrl,
                queryId: $NC.nullToDefault(options.queryId, "WC.POP_CMPOST"),
                queryParams: options.queryParams,
                queryData: options.queryData,
                querySearchParam: $NC.nullToDefault(options.querySearchParam, "P_ADDR_NM"),
                queryCanAll: $NC.nullToDefault(options.queryCanAll, false),
                columns: options.columns,
                multiSelect: options.multiSelect,
                multiValue: options.multiValue,
                addBase: $NC.nullToDefault(options.addBase, ""),
                onSelect: onPopupSelect,
                onCancel: onPopupCancel,
                onClose: $THIS.onPopupClose
            };

            _showPopup(requestData);
        }

        /**
         * 다음 우편번호 서비스 팝업
         * 
         * @param {Object}
         *        options 팝업 호출 옵션
         * 
         * <pre>
         * <b>호출 방법 1(단순 설정)</b>
         * options 에 쿼리 파라메터를 지정한 경우 파라메터를 제외하고 모두 기본값으로 팝업 실행
         * 
         * <b>호출 방법 2(상세 설정)</b>
         * title                [옵션]:      {String}        팝업 창 타이틀
         * columnTitle          [옵션]:      {Array}         컬럼 타이틀, ["코드", "명"], 미지정시 기본 값
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * queryParams          [필수]:      {String}        쿼리 파라메터 지정
         * querySearchParam     [옵션]:      {String}        팝업 창 검색시 검색 값을 입력할 파라메터 명
         * queryCanAll          [옵션]:      {String}        팝업 창 전체 검색 가능 여부
         * queryData            [옵션]:      {Array}         데이터, 데이터를 넘겨줄 경우 서비스 호출하지 않음
         * </pre>
         * 
         * @param {Function}
         *        onPopupSelect 선택 버튼 클릭시 호출될 이벤트
         * @param {Function}
         *        onPopupCancel 취소 버튼 클릭시 호출될 이벤트
         * @example
         * 
         * <pre>
         * Call:
         *     // 호출 방법 1(단순 설정)
         *     $NP.showDaumPostcodePopup({
         *         P_ADDR_NM: $ND.C_ALL
         *     }, onPostPopup, function() {
         *         $NC.setFocus("#edtQAddr_Detail", true);
         *     });
         * 
         *     // 호출 방법 2(상세 설정)
         *     $NP.showDaumPostcodePopup({
         *         title: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "우편번호 검색"),
         *         queryParams: {
         *             P_ADDR_NM: $ND.C_ALL
         *         }
         *     }, onPostPopup, function() {
         *         $NC.setFocus("#edtQAddr_Detail", true);
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function showDaumPostcodePopup(options, onPopupSelect, onPopupCancel) {

            var requestData, url;
            if ($NC.isNull(options)) {
                return;
            }

            // 호출방법1일 경우, 파라메터 조정
            if ($NC.isNull(options.queryParams)) {
                options = {
                    queryParams: options
                };
            }

            _setTitleOptions(options,
            // 팝업 타이틀
            $NC.getDisplayName("POPUP_ZIP_CD", "우편번호"),
            // 기본 타이틀
            null,
            // 컬럼 정보
            null);

            // 모바일 프로그램일 경우, 팝업 위치가 하위 레벨이 아닌 동일 레벨에 있으므로 조정
            url = $.browser.urlPrefix + $NC.G_MAIN.$NC.G_VAR.baseUrl;
            if (url.indexOf("/mobile") != -1) {
                url += "../";
            }
            url += "popup/daumpostcodepopup.html";

            requestData = {
                containerId: "ctrCommonPopupDaumPostcode",
                url: url,
                title: options.title,
                width: 400,
                height: 480,
                requestUrl: options.requestUrl,
                queryId: $NC.nullToDefault(options.queryId, "WC.POP_CMPOST"),
                queryParams: options.queryParams,
                queryData: options.queryData,
                querySearchParam: $NC.nullToDefault(options.querySearchParam, "P_ADDR_NM"),
                queryCanAll: $NC.isNull(options.queryCanAll) ? false : options.queryCanAll,
                onSelect: onPopupSelect,
                onCancel: onPopupCancel,
                onClose: $THIS.onPopupClose
            };

            _showPopup(requestData);
        }

        /**
         * 관련사 팝업
         * 
         * @param {Object}
         *        options 팝업 호출 옵션
         * 
         * <pre>
         * <b>호출 방법 1(단순 설정)</b>
         * options 에 쿼리 파라메터를 지정한 경우 파라메터를 제외하고 모두 기본값으로 팝업 실행
         * 
         * <b>호출 방법 2(상세 설정)</b>
         * title                [옵션]:      {String}        팝업 창 타이틀
         * columnTitle          [옵션]:      {Array}         컬럼 타이틀, ["코드", "명"], 미지정시 기본 값
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * queryParams          [필수]:      {String}        쿼리 파라메터 지정
         * querySearchParam     [옵션]:      {String}        팝업 창 검색시 검색 값을 입력할 파라메터 명
         * queryCanAll          [옵션]:      {String}        팝업 창 전체 검색 가능 여부
         * queryData            [옵션]:      {Array}         데이터, 데이터를 넘겨줄 경우 서비스 호출하지 않음
         * </pre>
         * 
         * @param {Function}
         *        onPopupSelect 선택 버튼 클릭시 호출될 이벤트
         * @param {Function}
         *        onPopupCancel 취소 버튼 클릭시 호출될 이벤트
         * @example
         * 
         * <pre>
         * Call:
         *     // 호출 방법 1(단순 설정)
         *     $NP.showReferencePopup({
         *         P_REF_CUST_CD: $ND.C_ALL,
         *         P_REF_CUST_DIV: $ND.C_ALL,
         *         P_VIEW_DIV: "2"
         *     }, onReferencePopup, function() {
         *         $NC.setFocus("#edtQReference_Cd", true);
         *     });
         * 
         *     // 호출 방법 2(상세 설정)
         *     $NP.showReferencePopup({
         *         title: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "제약사 검색"),
         *         columnTitle: [
         *             $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "제약사코드"),
         *             $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "제약사명")
         *         ],
         *         queryParams: {
         *             P_REF_CUST_CD: $ND.C_ALL,
         *             P_REF_CUST_DIV: "2", // 제약사
         *             P_VIEW_DIV: "2"
         *         }
         *     }, onReferencePopup, function() {
         *         $NC.setFocus("#edtQMaker_Cd", true);
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function showReferencePopup(options, onPopupSelect, onPopupCancel) {

            var requestData;
            if ($NC.isNull(options)) {
                return;
            }

            // 호출방법1일 경우, 파라메터 조정
            if ($NC.isNull(options.queryParams)) {
                options = {
                    queryParams: options
                };
            }

            _setTitleOptions(options,
            // 팝업 타이틀
            $NC.getDisplayName("POPUP_REF_CUST_CD", "관련사"),
            // 기본 컬럼타이틀
            [
                $NC.getDisplayName("REF_CUST_CD", "관련사코드"),
                $NC.getDisplayName("REF_CUST_NM", "관련사명")
            ],
            // 컬럼 정보
            [
                {
                    id: "REF_CUST_CD",
                    field: "REF_CUST_CD",
                    width: 70
                },
                {
                    id: "REF_CUST_NM",
                    field: "REF_CUST_NM",
                    width: 150
                }
            ]);

            requestData = {
                containerId: "ctrCommonPopupReference",
                title: options.title,
                autoInquiry: true,
                width: 400,
                height: 450,
                requestUrl: options.requestUrl,
                queryId: $NC.nullToDefault(options.queryId, "WC.POP_CMREFERENCE"),
                queryParams: options.queryParams,
                queryData: options.queryData,
                querySearchParam: $NC.nullToDefault(options.querySearchParam, "P_REF_CUST_CD"),
                queryCanAll: $NC.nullToDefault(options.queryCanAll, true),
                columns: options.columns,
                multiSelect: options.multiSelect,
                multiValue: options.multiValue,
                addBase: $NC.nullToDefault(options.addBase, ""),
                onSelect: onPopupSelect,
                onCancel: onPopupCancel,
                onClose: $THIS.onPopupClose
            };

            _showPopup(requestData);
        }

        /**
         * 운송사 팝업
         * 
         * @param {Object}
         *        options 팝업 호출 옵션
         * 
         * <pre>
         * <b>호출 방법 1(단순 설정)</b>
         * options 에 쿼리 파라메터를 지정한 경우 파라메터를 제외하고 모두 기본값으로 팝업 실행
         * 
         * <b>호출 방법 2(상세 설정)</b>
         * title                [옵션]:      {String}        팝업 창 타이틀
         * columnTitle          [옵션]:      {Array}         컬럼 타이틀, ["코드", "명"], 미지정시 기본 값
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * queryParams          [필수]:      {String}        쿼리 파라메터 지정
         * querySearchParam     [옵션]:      {String}        팝업 창 검색시 검색 값을 입력할 파라메터 명
         * queryCanAll          [옵션]:      {String}        팝업 창 전체 검색 가능 여부
         * queryData            [옵션]:      {Array}         데이터, 데이터를 넘겨줄 경우 서비스 호출하지 않음
         * </pre>
         * 
         * @param {Function}
         *        onPopupSelect 선택 버튼 클릭시 호출될 이벤트
         * @param {Function}
         *        onPopupCancel 취소 버튼 클릭시 호출될 이벤트
         * @example
         * 
         * <pre>
         * Call:
         *     // 호출 방법 1(단순 설정)
         *     $NP.showCarrierPopup({
         *         P_CARRIER_CD: CARRIER_CD,
         *         P_CARRIER_DIV: $ND.C_ALL,
         *         P_VIEW_DIV: "1"
         *     }, onCarrierPopup, function() {
         *         $NC.setFocus("#edtQCarrier_Cd", true);
         *     });
         * 
         *     // 호출 방법 2(상세 설정)
         *     $NP.showCarrierPopup({
         *         title: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "운송사 검색"),
         *         columnTitle: [
         *             $NC.getDisplayName("CARRIER_CD", "운송사코드"),
         *             $NC.getDisplayName("CARRIER_NM", "운송사명")
         *         ],
         *         queryParams: {
         *             P_CARRIER_CD: CARRIER_CD,
         *             P_CARRIER_DIV: $ND.C_ALL,
         *             P_VIEW_DIV: "1"
         *         }
         *     }, onCarrierPopup, function() {
         *         $NC.setFocus("#edtQCarrier_Cd", true);
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function showCarrierPopup(options, onPopupSelect, onPopupCancel) {

            var requestData;
            if ($NC.isNull(options)) {
                return;
            }

            // 호출방법1일 경우, 파라메터 조정
            if ($NC.isNull(options.queryParams)) {
                options = {
                    queryParams: options
                };
            }

            _setTitleOptions(options,
            // 팝업 타이틀
            $NC.getDisplayName("POPUP_CARRIER_CD", "운송사"),
            // 기본 컬럼타이틀
            [
                $NC.getDisplayName("CARRIER_CD", "운송사코드"),
                $NC.getDisplayName("CARRIER_NM", "운송사명")
            ],
            // 컬럼 정보
            [
                {
                    id: "CARRIER_CD",
                    field: "CARRIER_CD",
                    width: 70
                },
                {
                    id: "CARRIER_NM",
                    field: "CARRIER_NM",
                    width: 150
                }
            ]);

            requestData = {
                containerId: "ctrCommonPopupCarrier",
                title: options.title,
                autoInquiry: true,
                width: 400,
                height: 450,
                requestUrl: options.requestUrl,
                queryId: $NC.nullToDefault(options.queryId, "WC.POP_CMCARRIER"),
                queryParams: options.queryParams,
                queryData: options.queryData,
                querySearchParam: $NC.nullToDefault(options.querySearchParam, "P_CARRIER_CD"),
                queryCanAll: $NC.nullToDefault(options.queryCanAll, true),
                columns: options.columns,
                multiSelect: options.multiSelect,
                multiValue: options.multiValue,
                addBase: $NC.nullToDefault(options.addBase, ""),
                onSelect: onPopupSelect,
                onCancel: onPopupCancel,
                onClose: $THIS.onPopupClose
            };

            _showPopup(requestData);
        }

        /**
         * 존 팝업
         * 
         * @param {Object}
         *        options 팝업 호출 옵션
         * 
         * <pre>
         * <b>호출 방법 1(단순 설정)</b>
         * options 에 쿼리 파라메터를 지정한 경우 파라메터를 제외하고 모두 기본값으로 팝업 실행
         * 
         * <b>호출 방법 2(상세 설정)</b>
         * title                [옵션]:      {String}        팝업 창 타이틀
         * columnTitle          [옵션]:      {Array}         컬럼 타이틀, ["코드", "명"], 미지정시 기본 값
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * queryParams          [필수]:      {String}        쿼리 파라메터 지정
         * querySearchParam     [옵션]:      {String}        팝업 창 검색시 검색 값을 입력할 파라메터 명
         * queryCanAll          [옵션]:      {String}        팝업 창 전체 검색 가능 여부
         * queryData            [옵션]:      {Array}         데이터, 데이터를 넘겨줄 경우 서비스 호출하지 않음
         * </pre>
         * 
         * @param {Function}
         *        onPopupSelect 선택 버튼 클릭시 호출될 이벤트
         * @param {Function}
         *        onPopupCancel 취소 버튼 클릭시 호출될 이벤트
         * @example
         * 
         * <pre>
         * Call:
         *     // 호출 방법 1(단순 설정)
         *     $NP.showZonePopup({
         *         P_CENTER_CD: CENTER_CD,
         *         P_ZONE_CD: $ND.C_ALL,
         *         P_ZONE_DIV_ATTR01_CD: "1" // 1 - 일반, 2- 유통가공, 3 - 보세
         *     }, onZonePopup, function() {
         *         $NC.setFocus("#edtQZone_Cd", true);
         *     });
         * 
         *     // 호출 방법 2(상세 설정)
         *     $NP.showZonePopup({
         *         title: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "존 검색"),
         *         columnTitle: [
         *             $NC.getDisplayName("ZONE_CD", "존코드"),
         *             $NC.getDisplayName("ZONE_NM", "존명")
         *         ],
         *         queryParams: {
         *             P_CENTER_CD: CENTER_CD,
         *             P_ZONE_CD: $ND.C_ALL,
         *             P_ZONE_DIV_ATTR01_CD: "1" // 1 - 일반, 2- 유통가공, 3 - 보세
         *         }
         *     }, onZonePopup, function() {
         *         $NC.setFocus("#edtQZone_Cd", true);
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function showZonePopup(options, onPopupSelect, onPopupCancel) {

            var requestData;
            if ($NC.isNull(options)) {
                return;
            }

            // 호출방법1일 경우, 파라메터 조정
            if ($NC.isNull(options.queryParams)) {
                options = {
                    queryParams: options
                };
            }

            _setTitleOptions(options,
            // 팝업 타이틀
            $NC.getDisplayName("POPUP_ZONE_CD", "존"),
            // 기본 컬럼타이틀
            [
                $NC.getDisplayName("ZONE_CD", "존코드"),
                $NC.getDisplayName("ZONE_NM", "존명")
            ],
            // 컬럼 정보
            [
                {
                    id: "ZONE_CD",
                    field: "ZONE_CD",
                    width: 70,
                    cssClass: "styCenter"
                },
                {
                    id: "ZONE_NM",
                    field: "ZONE_NM",
                    width: 150
                }
            ]);

            requestData = {
                containerId: "ctrCommonPopupZone",
                title: options.title,
                autoInquiry: true,
                width: 400,
                height: 450,
                requestUrl: options.requestUrl,
                queryId: $NC.nullToDefault(options.queryId, "WC.POP_CMZONE"),
                queryParams: options.queryParams,
                queryData: options.queryData,
                querySearchParam: $NC.nullToDefault(options.querySearchParam, "P_ZONE_CD"),
                queryCanAll: $NC.nullToDefault(options.queryCanAll, true),
                columns: options.columns,
                multiSelect: options.multiSelect,
                multiValue: options.multiValue,
                addBase: $NC.nullToDefault(options.addBase, ""),
                onSelect: onPopupSelect,
                onCancel: onPopupCancel,
                onClose: $THIS.onPopupClose
            };

            _showPopup(requestData);
        }

        /**
         * 사용자 팝업
         * 
         * @param {Object}
         *        options 팝업 호출 옵션
         * 
         * <pre>
         * <b>호출 방법 1(단순 설정)</b>
         * options 에 쿼리 파라메터를 지정한 경우 파라메터를 제외하고 모두 기본값으로 팝업 실행
         * 
         * <b>호출 방법 2(상세 설정)</b>
         * title                [옵션]:      {String}        팝업 창 타이틀
         * columnTitle          [옵션]:      {Array}         컬럼 타이틀, ["코드", "명"], 미지정시 기본 값
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * queryParams          [필수]:      {String}        쿼리 파라메터 지정
         * querySearchParam     [옵션]:      {String}        팝업 창 검색시 검색 값을 입력할 파라메터 명
         * queryCanAll          [옵션]:      {String}        팝업 창 전체 검색 가능 여부
         * queryData            [옵션]:      {Array}         데이터, 데이터를 넘겨줄 경우 서비스 호출하지 않음
         * </pre>
         * 
         * @param {Function}
         *        onPopupSelect 선택 버튼 클릭시 호출될 이벤트
         * @param {Function}
         *        onPopupCancel 취소 버튼 클릭시 호출될 이벤트
         * @example
         * 
         * <pre>
         * Call:
         *     // 호출 방법 1(단순 설정)
         *     $NP.showUserPopup({
         *         P_USER_ID: $ND.C_ALL,
         *         P_CERTIFY_DIV: $ND.C_ALL
         *     }, onUserPopup, function() {
         *         $NC.setFocus("#edtQUser_Id", true);
         *     });
         * 
         *     // 호출 방법 2(상세 설정)
         *     $NP.showUserPopup({
         *         title: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "사용자 검색"),
         *         columnTitle: [
         *             $NC.getDisplayName("USER_ID", "사용자ID"),
         *             $NC.getDisplayName("USER_NM", "사용자명")
         *         ],
         *         queryParams: {
         *             P_USER_ID: $ND.C_ALL,
         *             P_CERTIFY_DIV: $ND.C_ALL
         *         }
         *     }, onUserPopup, function() {
         *         $NC.setFocus("#edtQUser_Id", true);
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function showUserPopup(options, onPopupSelect, onPopupCancel) {

            var requestData;
            if ($NC.isNull(options)) {
                return;
            }

            // 호출방법1일 경우, 파라메터 조정
            if ($NC.isNull(options.queryParams)) {
                options = {
                    queryParams: options
                };
            }

            _setTitleOptions(options,
            // 팝업 타이틀
            $NC.getDisplayName("POPUP_USER_ID", "사용자"),
            // 기본 컬럼타이틀
            [
                $NC.getDisplayName("USER_ID", "사용자ID"),
                $NC.getDisplayName("USER_NM", "사용자명")
            ],
            // 컬럼 정보
            [
                {
                    id: "USER_ID",
                    field: "USER_ID",
                    width: 70
                },
                {
                    id: "USER_NM",
                    field: "USER_NM",
                    width: 150
                }
            ]);

            requestData = {
                containerId: "ctrCommonPopupUser",
                title: options.title,
                autoInquiry: true,
                width: 400,
                height: 450,
                requestUrl: options.requestUrl,
                queryId: $NC.nullToDefault(options.queryId, "WC.POP_CSUSER"),
                queryParams: options.queryParams,
                queryData: options.queryData,
                querySearchParam: $NC.nullToDefault(options.querySearchParam, "P_USER_ID"),
                queryCanAll: $NC.nullToDefault(options.queryCanAll, true),
                columns: options.columns,
                multiSelect: options.multiSelect,
                multiValue: options.multiValue,
                addBase: $NC.nullToDefault(options.addBase, ""),
                onSelect: onPopupSelect,
                onCancel: onPopupCancel,
                onClose: $THIS.onPopupClose
            };

            _showPopup(requestData);
        }

        /**
         * 사용자 사업부 팝업
         * 
         * @param {Object}
         *        options 팝업 호출 옵션
         * 
         * <pre>
         * <b>호출 방법 1(단순 설정)</b>
         * options 에 쿼리 파라메터를 지정한 경우 파라메터를 제외하고 모두 기본값으로 팝업 실행
         * 
         * <b>호출 방법 2(상세 설정)</b>
         * title                [옵션]:      {String}        팝업 창 타이틀
         * columnTitle          [옵션]:      {Array}         컬럼 타이틀, ["코드", "명"], 미지정시 기본 값
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * queryParams          [필수]:      {String}        쿼리 파라메터 지정
         * querySearchParam     [옵션]:      {String}        팝업 창 검색시 검색 값을 입력할 파라메터 명
         * queryCanAll          [옵션]:      {String}        팝업 창 전체 검색 가능 여부
         * queryData            [옵션]:      {Array}         데이터, 데이터를 넘겨줄 경우 서비스 호출하지 않음
         * </pre>
         * 
         * @param {Function}
         *        onPopupSelect 선택 버튼 클릭시 호출될 이벤트
         * @param {Function}
         *        onPopupCancel 취소 버튼 클릭시 호출될 이벤트
         * @example
         * 
         * <pre>
         * Call:
         *     // 호출 방법 1(단순 설정)
         *     $NP.showUserBuPopup({
         *         P_USER_ID: $NC.G_USERINFO.USER_ID,
         *         P_BU_CD: $ND.C_ALL,
         *         P_CUST_CD: $ND.C_ALL
         *     }, onUserBuPopup, function() {
         *         $NC.setFocus("#edtQBu_Cd", true);
         *     });
         * 
         *     // 호출 방법 2(상세 설정)
         *     $NP.showUserBuPopup({
         *         title: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "사업부 검색"),
         *         columnTitle: [
         *             $NC.getDisplayName("BU_CD", "사업부코드"),
         *             $NC.getDisplayName("BU_NM", "사업부명")
         *         ],
         *         queryParams: {
         *             P_USER_ID: $NC.G_USERINFO.USER_ID,
         *             P_BU_CD: $ND.C_ALL,
         *             P_CUST_CD: $ND.C_ALL
         *         }
         *     }, onUserBuPopup, function() {
         *         $NC.setFocus("#edtQBu_Cd", true);
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function showUserBuPopup(options, onPopupSelect, onPopupCancel) {

            var requestData;
            if ($NC.isNull(options)) {
                return;
            }

            // 호출방법1일 경우, 파라메터 조정
            if ($NC.isNull(options.queryParams)) {
                options = {
                    queryParams: options
                };
            }

            _setTitleOptions(options,
            // 팝업 타이틀
            $NC.getDisplayName("POPUP_BU_CD", "사업부"),
            // 기본 컬럼타이틀
            [
                $NC.getDisplayName("BU_CD", "사업부코드"),
                $NC.getDisplayName("BU_NM", "사업부명")
            ],
            // 컬럼 정보
            [
                {
                    id: "BU_CD",
                    field: "BU_CD",
                    width: 70,
                    cssClass: "styCenter"
                },
                {
                    id: "BU_NM",
                    field: "BU_NM",
                    width: 150
                }
            ]);

            requestData = {
                containerId: "ctrCommonPopupUserBu",
                title: options.title,
                autoInquiry: true,
                width: 400,
                height: 450,
                requestUrl: options.requestUrl,
                queryId: $NC.nullToDefault(options.queryId, "WC.POP_CSUSERBU"),
                queryParams: options.queryParams,
                queryData: options.queryData,
                querySearchParam: $NC.nullToDefault(options.querySearchParam, "P_BU_CD"),
                queryCanAll: $NC.nullToDefault(options.queryCanAll, true),
                columns: options.columns,
                multiSelect: options.multiSelect,
                multiValue: options.multiValue,
                addBase: $NC.nullToDefault(options.addBase, ""),
                onSelect: onPopupSelect,
                onCancel: onPopupCancel,
                onClose: $THIS.onPopupClose
            };

            _showPopup(requestData);
        }

        /**
         * 사용자 브랜드 팝업
         * 
         * @param {Object}
         *        options 팝업 호출 옵션
         * 
         * <pre>
         * <b>호출 방법 1(단순 설정)</b>
         * options 에 쿼리 파라메터를 지정한 경우 파라메터를 제외하고 모두 기본값으로 팝업 실행
         * 
         * <b>호출 방법 2(상세 설정)</b>
         * title                [옵션]:      {String}        팝업 창 타이틀
         * columnTitle          [옵션]:      {Array}         컬럼 타이틀, ["코드", "명"], 미지정시 기본 값
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * queryParams          [필수]:      {String}        쿼리 파라메터 지정
         * querySearchParam     [옵션]:      {String}        팝업 창 검색시 검색 값을 입력할 파라메터 명
         * queryCanAll          [옵션]:      {String}        팝업 창 전체 검색 가능 여부
         * queryData            [옵션]:      {Array}         데이터, 데이터를 넘겨줄 경우 서비스 호출하지 않음
         * </pre>
         * 
         * @param {Function}
         *        onPopupSelect 선택 버튼 클릭시 호출될 이벤트
         * @param {Function}
         *        onPopupCancel 취소 버튼 클릭시 호출될 이벤트
         * @example
         * 
         * <pre>
         * Call:
         *     // 호출 방법 1(단순 설정)
         *     $NP.showUserBrandPopup({
         *         P_USER_ID: $NC.G_USERINFO.USER_ID,
         *         P_BRAND_CD: $ND.C_ALL
         *     }, onUserBrandPopup, function() {
         *         $NC.setFocus("#edtQBrand_Cd", true);
         *     });
         * 
         *     // 호출 방법 2(상세 설정)
         *     $NP.showUserBrandPopup({
         *         title: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "사용자 브랜드 검색"),
         *         columnTitle: [
         *             $NC.getDisplayName("BRAND_CD", "브랜드코드"),
         *             $NC.getDisplayName("BRAND_NM", "브랜드명"),
         *             $NC.getDisplayName("CUST_NM", "고객사명")
         *         ],
         *         queryParams: {
         *             P_USER_ID: $NC.G_USERINFO.USER_ID,
         *             P_BRAND_CD: $ND.C_ALL
         *         }
         *     }, onUserBrandPopup, function() {
         *         $NC.setFocus("#edtQBrand_Cd", true);
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function showUserBrandPopup(options, onPopupSelect, onPopupCancel) {

            var requestData;
            if ($NC.isNull(options)) {
                return;
            }

            // 호출방법1일 경우, 파라메터 조정
            if ($NC.isNull(options.queryParams)) {
                options = {
                    queryParams: options
                };
            }

            _setTitleOptions(options,
            // 팝업 타이틀
            $NC.getDisplayName("POPUP_USER_BRAND_CD", "사용자 브랜드"),
            // 기본 컬럼타이틀
            [
                $NC.getDisplayName("BRAND_CD", "브랜드코드"),
                $NC.getDisplayName("BRAND_NM", "브랜드명"),
                $NC.getDisplayName("CUST_NM", "고객사명")
            ],
            // 컬럼 정보
            [
                {
                    id: "BRAND_CD",
                    field: "BRAND_CD",
                    width: 70,
                    cssClass: "styCenter"
                },
                {
                    id: "BRAND_NM",
                    field: "BRAND_NM",
                    width: 150
                },
                {
                    id: "CUST_NM",
                    field: "CUST_NM",
                    width: 120
                }
            ]);

            requestData = {
                containerId: "ctrCommonPopupUserBrand",
                title: options.title,
                autoInquiry: true,
                width: 400,
                height: 450,
                requestUrl: options.requestUrl,
                queryId: $NC.nullToDefault(options.queryId, "WC.POP_CSUSERBRAND"),
                queryParams: options.queryParams,
                queryData: options.queryData,
                querySearchParam: $NC.nullToDefault(options.querySearchParam, "P_BRAND_CD"),
                queryCanAll: $NC.nullToDefault(options.queryCanAll, true),
                columns: options.columns,
                multiSelect: options.multiSelect,
                multiValue: options.multiValue,
                addBase: $NC.nullToDefault(options.addBase, ""),
                onSelect: onPopupSelect,
                onCancel: onPopupCancel,
                onClose: $THIS.onPopupClose
            };

            _showPopup(requestData);
        }

        /**
         * 사용자 물류센터 팝업
         * 
         * @param {Object}
         *        options 팝업 호출 옵션
         * 
         * <pre>
         * <b>호출 방법 1(단순 설정)</b>
         * options 에 쿼리 파라메터를 지정한 경우 파라메터를 제외하고 모두 기본값으로 팝업 실행
         * 
         * <b>호출 방법 2(상세 설정)</b>
         * title                [옵션]:      {String}        팝업 창 타이틀
         * columnTitle          [옵션]:      {Array}         컬럼 타이틀, ["코드", "명"], 미지정시 기본 값
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * queryParams          [필수]:      {String}        쿼리 파라메터 지정
         * querySearchParam     [옵션]:      {String}        팝업 창 검색시 검색 값을 입력할 파라메터 명
         * queryCanAll          [옵션]:      {String}        팝업 창 전체 검색 가능 여부
         * queryData            [옵션]:      {Array}         데이터, 데이터를 넘겨줄 경우 서비스 호출하지 않음
         * </pre>
         * 
         * @param {Function}
         *        onPopupSelect 선택 버튼 클릭시 호출될 이벤트
         * @param {Function}
         *        onPopupCancel 취소 버튼 클릭시 호출될 이벤트
         * @example
         * 
         * <pre>
         * Call:
         *     // 호출 방법 1(단순 설정)
         *     $NP.showUserCenterPopup({
         *         P_USER_ID: $NC.G_USERINFO.USER_ID,
         *         P_CENTER_CD: $ND.C_ALL
         *     }, onUserCenterPopup, function() {
         *         $NC.setFocus("#edtQCenter_Cd", true);
         *     });
         * 
         *     // 호출 방법 2(상세 설정)
         *     $NP.showUserCenterPopup({
         *         title: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "사용자 물류센터 검색"),
         *         columnTitle: [
         *             $NC.getDisplayName("CENTER_CD", "물류센터코드"),
         *             $NC.getDisplayName("CENTER_NM", "물류센터명")
         *         ],
         *         queryParams: {
         *             P_USER_ID: $NC.G_USERINFO.USER_ID,
         *             P_CENTER_CD: $ND.C_ALL
         *         }
         *     }, onUserCenterPopup, function() {
         *         $NC.setFocus("#edtQCenter_Cd", true);
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function showUserCenterPopup(options, onPopupSelect, onPopupCancel) {

            var requestData;
            if ($NC.isNull(options)) {
                return;
            }

            // 호출방법1일 경우, 파라메터 조정
            if ($NC.isNull(options.queryParams)) {
                options = {
                    queryParams: options
                };
            }

            _setTitleOptions(options,
            // 팝업 타이틀
            $NC.getDisplayName("POPUP_USER_CENTER_CD", "사용자 물류센터"),
            // 기본 컬럼타이틀
            [
                $NC.getDisplayName("CENTER_CD", "물류센터코드"),
                $NC.getDisplayName("CENTER_NM", "물류센터명")
            ],
            // 컬럼 정보
            [
                {
                    id: "CENTER_CD",
                    field: "CENTER_CD",
                    width: 70,
                    cssClass: "styCenter"
                },
                {
                    id: "CENTER_NM",
                    field: "CENTER_NM",
                    width: 150
                }
            ]);

            requestData = {
                containerId: "ctrCommonPopupUserCenter",
                title: options.title,
                autoInquiry: true,
                width: 400,
                height: 450,
                requestUrl: options.requestUrl,
                queryId: $NC.nullToDefault(options.queryId, "WC.POP_CSUSERCENTER"),
                queryParams: options.queryParams,
                queryData: options.queryData,
                querySearchParam: $NC.nullToDefault(options.querySearchParam, "P_CENTER_CD"),
                queryCanAll: $NC.nullToDefault(options.queryCanAll, true),
                columns: options.columns,
                multiSelect: options.multiSelect,
                multiValue: options.multiValue,
                addBase: $NC.nullToDefault(options.addBase, ""),
                onSelect: onPopupSelect,
                onCancel: onPopupCancel,
                onClose: $THIS.onPopupClose
            };

            _showPopup(requestData);
        }

        /**
         * 사용자 고객사 팝업
         * 
         * @param {Object}
         *        options 팝업 호출 옵션
         * 
         * <pre>
         * <b>호출 방법 1(단순 설정)</b>
         * options 에 쿼리 파라메터를 지정한 경우 파라메터를 제외하고 모두 기본값으로 팝업 실행
         * 
         * <b>호출 방법 2(상세 설정)</b>
         * title                [옵션]:      {String}        팝업 창 타이틀
         * columnTitle          [옵션]:      {Array}         컬럼 타이틀, ["코드", "명"], 미지정시 기본 값
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * queryParams          [필수]:      {String}        쿼리 파라메터 지정
         * querySearchParam     [옵션]:      {String}        팝업 창 검색시 검색 값을 입력할 파라메터 명
         * queryCanAll          [옵션]:      {String}        팝업 창 전체 검색 가능 여부
         * queryData            [옵션]:      {Array}         데이터, 데이터를 넘겨줄 경우 서비스 호출하지 않음
         * </pre>
         * 
         * @param {Function}
         *        onPopupSelect 선택 버튼 클릭시 호출될 이벤트
         * @param {Function}
         *        onPopupCancel 취소 버튼 클릭시 호출될 이벤트
         * @example
         * 
         * <pre>
         * Call:
         *     // 호출 방법 1(단순 설정)
         *     $NP.showUserCustPopup({
         *         P_USER_ID: $NC.G_USERINFO.USER_ID,
         *         P_CUST_CD: $ND.C_ALL
         *     }, onUserCustPopup, function() {
         *         $NC.setFocus("#edtQCust_Cd", true);
         *     });
         * 
         *     // 호출 방법 2(상세 설정)
         *     $NP.showUserCustPopup({
         *         title: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "사용자 고객사 검색"),
         *         columnTitle: [
         *             $NC.getDisplayName("CUST_CD", "고객사코드"),
         *             $NC.getDisplayName("CUST_NM", "고객사명")
         *         ],
         *         queryParams: {
         *             P_USER_ID: $NC.G_USERINFO.USER_ID,
         *             P_CUST_CD: $ND.C_ALL
         *         }
         *     }, onUserCustPopup, function() {
         *         $NC.setFocus("#edtQCust_Cd", true);
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function showUserCustPopup(options, onPopupSelect, onPopupCancel) {

            var requestData;
            if ($NC.isNull(options)) {
                return;
            }

            // 호출방법1일 경우, 파라메터 조정
            if ($NC.isNull(options.queryParams)) {
                options = {
                    queryParams: options
                };
            }

            _setTitleOptions(options,
            // 팝업 타이틀
            $NC.getDisplayName("POPUP_USER_CUST_CD", "고객사"),
            // 기본 컬럼타이틀
            [
                $NC.getDisplayName("CUST_CD", "고객사코드"),
                $NC.getDisplayName("CUST_NM", "고객사명")
            ],
            // 컬럼 정보
            [
                {
                    id: "CUST_CD",
                    field: "CUST_CD",
                    width: 70,
                    cssClass: "styCenter"
                },
                {
                    id: "CUST_NM",
                    field: "CUST_NM",
                    width: 150
                }
            ]);

            requestData = {
                containerId: "ctrCommonPopupUserCust",
                title: options.title,
                autoInquiry: true,
                width: 400,
                height: 450,
                requestUrl: options.requestUrl,
                queryId: $NC.nullToDefault(options.queryId, "WC.POP_CSUSERCUST"),
                queryParams: options.queryParams,
                queryData: options.queryData,
                querySearchParam: $NC.nullToDefault(options.querySearchParam, "P_CUST_CD"),
                queryCanAll: $NC.nullToDefault(options.queryCanAll, true),
                columns: options.columns,
                multiSelect: options.multiSelect,
                multiValue: options.multiValue,
                addBase: $NC.nullToDefault(options.addBase, ""),
                onSelect: onPopupSelect,
                onCancel: onPopupCancel,
                onClose: $THIS.onPopupClose
            };

            _showPopup(requestData);
        }

        /**
         * 재고 LOT번호 팝업
         * 
         * @param {Object}
         *        options 팝업 호출 옵션
         * 
         * <pre>
         * <b>호출 방법 1(단순 설정)</b>
         * options 에 쿼리 파라메터를 지정한 경우 파라메터를 제외하고 모두 기본값으로 팝업 실행
         * 
         * <b>호출 방법 2(상세 설정)</b>
         * title                [옵션]:      {String}        팝업 창 타이틀
         * columnTitle          [옵션]:      {Array}         컬럼 타이틀, ["코드", "명"], 미지정시 기본 값
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * queryParams          [필수]:      {String}        쿼리 파라메터 지정
         * querySearchParam     [옵션]:      {String}        팝업 창 검색시 검색 값을 입력할 파라메터 명
         * queryCanAll          [옵션]:      {String}        팝업 창 전체 검색 가능 여부
         * queryData            [옵션]:      {Array}         데이터, 데이터를 넘겨줄 경우 서비스 호출하지 않음
         * </pre>
         * 
         * @param {Function}
         *        onPopupSelect 선택 버튼 클릭시 호출될 이벤트
         * @param {Function}
         *        onPopupCancel 취소 버튼 클릭시 호출될 이벤트
         * @example
         * 
         * <pre>
         * Call:
         *     // 호출 방법 1(단순 설정)
         *     $NP.showItemLotPopup({
         *         P_CENTER_CD: CENTER_CD,
         *         P_BU_CD: BU_CD,
         *         P_BRAND_CD: BRAND_CD,
         *         P_ITEM_CD: ITEM_CD,
         *         P_ITEM_STATE: ITEM_STATE,
         *         P_ITEM_LOT: $ND.C_ALL
         *     }, onItemLotPopup, function() {
         *         $NC.setFocus("#edtQItem_Lot", true);
         *     });
         * 
         *     // 호출 방법 2(상세 설정)
         *     $NP.showItemLotPopup({
         *         title: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "재고 LOT번호 검색"),
         *         columnTitle: [
         *             $NC.getDisplayName("ITEM_LOT", "LOT번호"),
         *             $NC.getDisplayName("STOCK_QTY", "재고수량"),
         *             $NC.getDisplayName("PSTOCK_QTY", "가용재고")
         *         ],
         *         queryParams: {
         *             P_CENTER_CD: CENTER_CD,
         *             P_BU_CD: BU_CD,
         *             P_BRAND_CD: BRAND_CD,
         *             P_ITEM_CD: ITEM_CD,
         *             P_ITEM_STATE: ITEM_STATE,
         *             P_ITEM_LOT: $ND.C_ALL
         *         }
         *     }, onItemLotPopup, function() {
         *         $NC.setFocus("#edtQItem_Lot", true);
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function showItemLotPopup(options, onPopupSelect, onPopupCancel) {

            var requestData;
            if ($NC.isNull(options)) {
                return;
            }

            // 호출방법1일 경우, 파라메터 조정
            if ($NC.isNull(options.queryParams)) {
                options = {
                    queryParams: options
                };
            }

            _setTitleOptions(options,
            // 팝업 타이틀
            $NC.getDisplayName("POPUP_STOCK_ITEM_LOT", "재고 LOT번호"),
            // 기본 컬럼타이틀
            [
                $NC.getDisplayName("ITEM_LOT", "LOT번호"),
                $NC.getDisplayName("STOCK_QTY", "재고수량"),
                $NC.getDisplayName("PSTOCK_QTY", "가용재고")
            ],
            // 컬럼 정보
            [
                {
                    id: "ITEM_LOT",
                    field: "ITEM_LOT",
                    width: 150
                },
                {
                    id: "STOCK_QTY",
                    field: "STOCK_QTY",
                    width: 90,
                    cssClass: "styRight"
                },
                {
                    id: "PSTOCK_QTY",
                    field: "PSTOCK_QTY",
                    width: 90,
                    cssClass: "styRight"
                }
            ]);

            requestData = {
                containerId: "ctrCommonPopupItemLot",
                title: options.title,
                autoInquiry: true,
                width: 400,
                height: 450,
                requestUrl: options.requestUrl,
                queryId: $NC.nullToDefault(options.queryId, "WC.POP_ITEM_LOT"),
                queryParams: options.queryParams,
                queryData: options.queryData,
                querySearchParam: $NC.nullToDefault(options.querySearchParam, "P_ITEM_LOT"),
                queryCanAll: $NC.nullToDefault(options.queryCanAll, true),
                columns: options.columns,
                multiSelect: options.multiSelect,
                multiValue: options.multiValue,
                addBase: $NC.nullToDefault(options.addBase, ""),
                onSelect: onPopupSelect,
                onCancel: onPopupCancel,
                onClose: $THIS.onPopupClose
            };

            _showPopup(requestData);
        }

        /**
         * 터미널 팝업
         * 
         * @param {Object}
         *        options 팝업 호출 옵션
         * 
         * <pre>
         * <b>호출 방법 1(단순 설정)</b>
         * options 에 쿼리 파라메터를 지정한 경우 파라메터를 제외하고 모두 기본값으로 팝업 실행
         * 
         * <b>호출 방법 2(상세 설정)</b>
         * title                [옵션]:      {String}        팝업 창 타이틀
         * columnTitle          [옵션]:      {Array}         컬럼 타이틀, ["코드", "명"], 미지정시 기본 값
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * queryParams          [필수]:      {String}        쿼리 파라메터 지정
         * querySearchParam     [옵션]:      {String}        팝업 창 검색시 검색 값을 입력할 파라메터 명
         * queryCanAll          [옵션]:      {String}        팝업 창 전체 검색 가능 여부
         * queryData            [옵션]:      {Array}         데이터, 데이터를 넘겨줄 경우 서비스 호출하지 않음
         * </pre>
         * 
         * @param {Function}
         *        onPopupSelect 선택 버튼 클릭시 호출될 이벤트
         * @param {Function}
         *        onPopupCancel 취소 버튼 클릭시 호출될 이벤트
         * @example
         * 
         * <pre>
         * Call:
         *     // 호출 방법 1(단순 설정)
         *     $NP.showTerminalPopup({
         *         P_TML_CD: $ND.C_ALL,
         *         P_VIEW_DIV: "1"
         *     }, onTerminalPopup, function() {
         *         $NC.setFocus("#edtQTml_Cd", true);
         *     });
         * 
         *     // 호출 방법 2(상세 설정)
         *     $NP.showTerminalPopup({
         *         title: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "터미널 검색"),
         *         columnTitle: [
         *             $NC.getDisplayName("TML_CD", "터미널코드"),
         *             $NC.getDisplayName("TML_NM", "터미널명")
         *         ],
         *         queryParams: {
         *             P_TML_CD: $ND.C_ALL,
         *             P_VIEW_DIV: "1"
         *         }
         *     }, onTerminalPopup, function() {
         *         $NC.setFocus("#edtQTml_Cd", true);
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function showTerminalPopup(options, onPopupSelect, onPopupCancel) {

            var requestData;
            if ($NC.isNull(options)) {
                return;
            }

            // 호출방법1일 경우, 파라메터 조정
            if ($NC.isNull(options.queryParams)) {
                options = {
                    queryParams: options
                };
            }

            _setTitleOptions(options,
            // 팝업 타이틀
            $NC.getDisplayName("POPUP_TML_CD", "터미널"),
            // 기본 컬럼타이틀
            [
                $NC.getDisplayName("TML_CD", "터미널코드"),
                $NC.getDisplayName("TML_NM", "터미널명")
            ],
            // 컬럼 정보
            [
                {
                    id: "TML_CD",
                    field: "TML_CD",
                    width: 70,
                    cssClass: "styCenter"
                },
                {
                    id: "TML_NM",
                    field: "TML_NM",
                    width: 150
                }
            ]);

            requestData = {
                containerId: "ctrCommonPopupTerminal",
                title: options.title,
                autoInquiry: true,
                width: 400,
                height: 450,
                requestUrl: options.requestUrl,
                queryId: $NC.nullToDefault(options.queryId, "WC.POP_CMWBTERMINAL"),
                queryParams: options.queryParams,
                queryData: options.queryData,
                querySearchParam: $NC.nullToDefault(options.querySearchParam, "P_TML_CD"),
                queryCanAll: $NC.nullToDefault(options.queryCanAll, true),
                columns: options.columns,
                multiSelect: options.multiSelect,
                multiValue: options.multiValue,
                addBase: $NC.nullToDefault(options.addBase, ""),
                onSelect: onPopupSelect,
                onCancel: onPopupCancel,
                onClose: $THIS.onPopupClose
            };

            _showPopup(requestData);
        }

        /**
         * 재고 유통기한 팝업
         * 
         * @param {Object}
         *        options 팝업 호출 옵션
         * 
         * <pre>
         * <b>호출 방법 1(단순 설정)</b>
         * options 에 쿼리 파라메터를 지정한 경우 파라메터를 제외하고 모두 기본값으로 팝업 실행
         * 
         * <b>호출 방법 2(상세 설정)</b>
         * title                [옵션]:      {String}        팝업 창 타이틀
         * columnTitle          [옵션]:      {Array}         컬럼 타이틀, ["코드", "명"], 미지정시 기본 값
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * queryParams          [필수]:      {String}        쿼리 파라메터 지정
         * querySearchParam     [옵션]:      {String}        팝업 창 검색시 검색 값을 입력할 파라메터 명
         * queryCanAll          [옵션]:      {String}        팝업 창 전체 검색 가능 여부
         * queryData            [옵션]:      {Array}         데이터, 데이터를 넘겨줄 경우 서비스 호출하지 않음
         * </pre>
         * 
         * @param {Function}
         *        onPopupSelect 선택 버튼 클릭시 호출될 이벤트
         * @param {Function}
         *        onPopupCancel 취소 버튼 클릭시 호출될 이벤트
         * @example
         * 
         * <pre>
         * Call:
         *     // 호출 방법 1(단순 설정)
         *     $NP.showValidDatePopup({
         *         P_CENTER_CD: CENTER_CD,
         *         P_BU_CD: BU_CD,
         *         P_BRAND_CD: BRAND_CD,
         *         P_ITEM_CD: ITEM_CD,
         *         P_ITEM_STATE: ITEM_STATE,
         *         P_ITEM_LOT: ITEM_LOT
         *     }, onValidDatePopup, function() {
         *         $NC.setFocus("#edtQBatch_No", true);
         *     });
         * 
         *     // 호출 방법 2(상세 설정)
         *     $NP.showValidDatePopup({
         *         title: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "재고 유통기한/제조번호 검색"),
         *         columnTitle: [
         *             $NC.getDisplayName("VALID_DATE", "유통기한"),
         *             $NC.getDisplayName("BATCH_NO", "제조번호"),
         *             $NC.getDisplayName("STOCK_QTY", "재고수량"),
         *             $NC.getDisplayName("PSTOCK_QTY", "가용재고")
         *         ],
         *         queryParams: {
         *             P_CENTER_CD: CENTER_CD,
         *             P_BU_CD: BU_CD,
         *             P_BRAND_CD: BRAND_CD,
         *             P_ITEM_CD: ITEM_CD,
         *             P_ITEM_STATE: ITEM_STATE,
         *             P_ITEM_LOT: ITEM_LOT
         *         }
         *     }, onValidDatePopup, function() {
         *         $NC.setFocus("#edtQValid_Date", true);
         *     });
         * </pre>
         * 
         * @since 7.0.0
         * @memberof $NP#
         */
        function showValidDatePopup(options, onPopupSelect, onPopupCancel) {

            var requestData;
            if ($NC.isNull(options)) {
                return;
            }

            // 호출방법1일 경우, 파라메터 조정
            if ($NC.isNull(options.queryParams)) {
                options = {
                    queryParams: options
                };
            }

            _setTitleOptions(options,
            // 팝업 타이틀
            $NC.getDisplayName("POPUP_STOCK_VALID_DATE", "재고 유통기한"),
            // 기본 컬럼타이틀
            [
                $NC.getDisplayName("VALID_DATE", "유통기한"),
                $NC.getDisplayName("STOCK_QTY", "재고수량"),
                $NC.getDisplayName("PSTOCK_QTY", "가용재고")
            ],
            // 컬럼 정보
            [
                {
                    id: "VALID_DATE",
                    field: "VALID_DATE",
                    width: 100,
                    cssClass: "styCenter"
                },
                {
                    id: "STOCK_QTY",
                    field: "STOCK_QTY",
                    width: 90,
                    cssClass: "styRight"
                },
                {
                    id: "PSTOCK_QTY",
                    field: "PSTOCK_QTY",
                    width: 90,
                    cssClass: "styRight"
                }
            ]);

            requestData = {
                containerId: "ctrCommonPopupItemLot",
                title: options.title,
                autoInquiry: true,
                width: 400,
                height: 450,
                requestUrl: options.requestUrl,
                queryId: $NC.nullToDefault(options.queryId, "WC.POP_VALID_DATE"),
                queryParams: options.queryParams,
                queryData: options.queryData,
                querySearchParam: $NC.nullToDefault(options.querySearchParam, "P_VALID_DATE"),
                queryCanAll: $NC.nullToDefault(options.queryCanAll, true),
                columns: options.columns,
                multiSelect: options.multiSelect,
                multiValue: options.multiValue,
                addBase: $NC.nullToDefault(options.addBase, ""),
                onSelect: onPopupSelect,
                onCancel: onPopupCancel,
                onClose: $THIS.onPopupClose
            };

            _showPopup(requestData);
        }

        /**
         * 택배기준(운송사) 팝업
         * 
         * @param {Object}
         *        options 팝업 호출 옵션
         * 
         * <pre>
         * <b>호출 방법 1(단순 설정)</b>
         * options 에 쿼리 파라메터를 지정한 경우 파라메터를 제외하고 모두 기본값으로 팝업 실행
         * 
         * <b>호출 방법 2(상세 설정)</b>
         * title                [옵션]:      {String}        팝업 창 타이틀
         * columnTitle          [옵션]:      {Array}         컬럼 타이틀, ["코드", "명"], 미지정시 기본 값
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * queryParams          [필수]:      {String}        쿼리 파라메터 지정
         * querySearchParam     [옵션]:      {String}        팝업 창 검색시 검색 값을 입력할 파라메터 명
         * queryCanAll          [옵션]:      {String}        팝업 창 전체 검색 가능 여부
         * queryData            [옵션]:      {Array}         데이터, 데이터를 넘겨줄 경우 서비스 호출하지 않음
         * </pre>
         * 
         * @param {Function}
         *        onPopupSelect 선택 버튼 클릭시 호출될 이벤트
         * @param {Function}
         *        onPopupCancel 취소 버튼 클릭시 호출될 이벤트
         * @example
         * 
         * <pre>
         * Call:
         *     // 호출 방법 1(단순 설정)
         *     $NP.showWbBasePopup({
         *         P_CARRIER_CD: CARRIER_CD,
         *         P_CUST_CD: CUST_CD,
         *         P_ATTR05_CD: "1"
         *     }, onWbBasePopup, function() {
         *         $NC.setFocus("#edtQCarrier_Cd", true);
         *     });
         * 
         *     // 호출 방법 2(상세 설정)
         *     $NP.showWbBasePopup({
         *         title: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "운송사 검색"),
         *         columnTitle: [
         *             $NC.getDisplayName("CARRIER_CD", "운송사코드"),
         *             $NC.getDisplayName("CARRIER_NM", "운송사명")
         *         ],
         *         queryParams: {
         *             P_CARRIER_CD: CARRIER_CD,
         *             P_CUST_CD : CUST_CD,
         *             P_ATTR05_CD : "1"
         *         }
         *     }, onCarrierPopup, function() {
         *         $NC.setFocus("#edtQCarrier_Cd", true);
         *     });
         * </pre>
         * 
         * @since 7.1.0
         * @memberof $NP#
         */
        function showWbBasePopup(options, onPopupSelect, onPopupCancel) {

            var requestData;
            if ($NC.isNull(options)) {
                return;
            }

            // 호출방법1일 경우, 파라메터 조정
            if ($NC.isNull(options.queryParams)) {
                options = {
                    queryParams: options
                };
            }

            _setTitleOptions(options,
            // 팝업 타이틀
            $NC.getDisplayName("POPUP_WBBASE", "택배운송사"),
            // 기본 컬럼타이틀
            [
                $NC.getDisplayName("CARRIER_CD", "운송사코드"),
                $NC.getDisplayName("CARRIER_NM", "운송사명")
            ],
            // 컬럼 정보
            [
                {
                    id: "CARRIER_CD",
                    field: "CARRIER_CD",
                    width: 70
                },
                {
                    id: "CARRIER_NM",
                    field: "CARRIER_NM",
                    width: 150
                }
            ]);

            requestData = {
                containerId: "ctrCommonPopupWbBase",
                title: options.title,
                autoInquiry: true,
                width: 400,
                height: 450,
                requestUrl: options.requestUrl,
                queryId: $NC.nullToDefault(options.queryId, "WC.POP_CMWBBASE"),
                queryParams: options.queryParams,
                queryData: options.queryData,
                querySearchParam: $NC.nullToDefault(options.querySearchParam, "P_CARRIER_CD"),
                queryCanAll: $NC.nullToDefault(options.queryCanAll, true),
                columns: options.columns,
                multiSelect: options.multiSelect,
                multiValue: options.multiValue,
                addBase: $NC.nullToDefault(options.addBase, ""),
                onSelect: onPopupSelect,
                onCancel: onPopupCancel,
                onClose: $THIS.onPopupClose
            };

            _showPopup(requestData);
        }

        /**
         * 사업부 수수료 구분 팝업
         * 
         * @param {Object}
         *        options 팝업 호출 옵션
         * 
         * <pre>
         * <b>호출 방법 1(단순 설정)</b>
         * options 에 쿼리 파라메터를 지정한 경우 파라메터를 제외하고 모두 기본값으로 팝업 실행
         * 
         * <b>호출 방법 2(상세 설정)</b>
         * title                [옵션]:      {String}        팝업 창 타이틀
         * columnTitle          [옵션]:      {Array}         컬럼 타이틀, ["코드", "명"], 미지정시 기본 값
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * queryParams          [필수]:      {String}        쿼리 파라메터 지정
         * querySearchParam     [옵션]:      {String}        팝업 창 검색시 검색 값을 입력할 파라메터 명
         * queryCanAll          [옵션]:      {String}        팝업 창 전체 검색 가능 여부
         * queryData            [옵션]:      {Array}         데이터, 데이터를 넘겨줄 경우 서비스 호출하지 않음
         * </pre>
         * 
         * @param {Function}
         *        onPopupSelect 선택 버튼 클릭시 호출될 이벤트
         * @param {Function}
         *        onPopupCancel 취소 버튼 클릭시 호출될 이벤트
         * @example
         * 
         * <pre>
         * Call:
         *     // 호출 방법 1(단순 설정)
         *     $NP.showBuContractPopup({
         *         P_CENTER_CD: CENTER_CD,
         *         P_BU_CD: BU_CD,
         *         P_FEE_GRP: "10",
         *         P_FEE_DIV: $ND.C_ALL,
         *         P_VIEW_DIV: "2"
         *     }, onBuContractPopup, function() {
         *         $NC.setFocus("#edtQFee_Div", true);
         *     });
         * 
         *     // 호출 방법 2(상세 설정)
         *     $NP.showBuContractPopup({
         *         title: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "수수료구분 검색"),
         *         columnTitle: [
         *             $NC.getDisplayName("FEE_DIV", "수수료구분"),
         *             $NC.getDisplayName("FEE_DIV_D", "수수료구분명"),
         *             $NC.getDisplayName("CONTRACT_NO", "계약번호"),
         *             $NC.getDisplayName("CONTRACT_NM", "계약명")
         *         ],
         *         queryParams: {
         *         P_CENTER_CD: CENTER_CD,
         *         P_BU_CD: BU_CD,
         *         P_FEE_GRP: "10",
         *         P_FEE_DIV: $ND.C_ALL,
         *         P_VIEW_DIV: "2"
         *         }
         *     }, onCarrierPopup, function() {
         *         $NC.setFocus("#edtQFee_Div", true);
         *     });
         * </pre>
         * 
         * @since 7.1.0
         * @memberof $NP#
         */
        function showBuContractPopup(options, onPopupSelect, onPopupCancel) {

            var requestData;
            if ($NC.isNull(options)) {
                return;
            }

            // 호출방법1일 경우, 파라메터 조정
            if ($NC.isNull(options.queryParams)) {
                options = {
                    queryParams: options
                };
            }

            _setTitleOptions(options,
            // 팝업 타이틀
            $NC.getDisplayName("POPUP_BUCONTRACT", "수수료구분"),
            // 기본 컬럼타이틀
            [
                $NC.getDisplayName("FEE_DIV", "수수료구분"),
                $NC.getDisplayName("FEE_DIV_D", "수수료구분명"),
                $NC.getDisplayName("CONTRACT_NO", "계약번호"),
                $NC.getDisplayName("CONTRACT_NM", "계약명")
            ],
            // 컬럼 정보
            [
                {
                    id: "FEE_DIV",
                    field: "FEE_DIV",
                    width: 90
                },
                {
                    id: "FEE_DIV_D",
                    field: "FEE_DIV_D",
                    width: 120
                },
                {
                    id: "CONTRACT_NO",
                    field: "CONTRACT_NO",
                    width: 90
                },
                {
                    id: "CONTRACT_NM",
                    field: "CONTRACT_NM",
                    width: 150
                }
            ]);

            requestData = {
                containerId: "ctrCommonPopupBuContract",
                title: options.title,
                autoInquiry: true,
                width: 400,
                height: 450,
                requestUrl: options.requestUrl,
                queryId: $NC.nullToDefault(options.queryId, "WC.POP_LFBUCONTRACT"),
                queryParams: options.queryParams,
                queryData: options.queryData,
                querySearchParam: $NC.nullToDefault(options.querySearchParam, "P_FEE_DIV"),
                queryCanAll: $NC.nullToDefault(options.queryCanAll, true),
                columns: options.columns,
                multiSelect: options.multiSelect,
                multiValue: options.multiValue,
                addBase: $NC.nullToDefault(options.addBase, ""),
                onSelect: onPopupSelect,
                onCancel: onPopupCancel,
                onClose: $THIS.onPopupClose
            };

            _showPopup(requestData);
        }

        /**
         * 계약번호 팝업
         * 
         * @param {Object}
         *        options 팝업 호출 옵션
         * 
         * <pre>
         * <b>호출 방법 1(단순 설정)</b>
         * options 에 쿼리 파라메터를 지정한 경우 파라메터를 제외하고 모두 기본값으로 팝업 실행
         * 
         * <b>호출 방법 2(상세 설정)</b>
         * title                [옵션]:      {String}        팝업 창 타이틀
         * columnTitle          [옵션]:      {Array}         컬럼 타이틀, ["코드", "명"], 미지정시 기본 값
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * queryParams          [필수]:      {String}        쿼리 파라메터 지정
         * querySearchParam     [옵션]:      {String}        팝업 창 검색시 검색 값을 입력할 파라메터 명
         * queryCanAll          [옵션]:      {String}        팝업 창 전체 검색 가능 여부
         * queryData            [옵션]:      {Array}         데이터, 데이터를 넘겨줄 경우 서비스 호출하지 않음
         * </pre>
         * 
         * @param {Function}
         *        onPopupSelect 선택 버튼 클릭시 호출될 이벤트
         * @param {Function}
         *        onPopupCancel 취소 버튼 클릭시 호출될 이벤트
         * @example
         * 
         * <pre>
         * Call:
         *     // 호출 방법 1(단순 설정)
         *     $NP.showContractPopup({
         *         P_CONTRACT_NO: CONTRACT_NO,
         *         P_PRICE_DIV: "01",
         *         P_VIEW_DIV: "2"
         *     }, onContractPopup, function() {
         *         $NC.setFocus("#edtQContract_No", true);
         *     });
         * 
         *     // 호출 방법 2(상세 설정)
         *     $NP.showContractPopup({
         *         title: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "계약번호 검색"),
         *         columnTitle: [
         *             $NC.getDisplayName("CONTRACT_NO", "계약번호"),
         *             $NC.getDisplayName("CONTRACT_NM", "계약명")
         *         ],
         *         queryParams: {
         *         P_CONTRACT_NO: CONTRACT_NO,
         *         P_PRICE_DIV: "01",
         *         P_VIEW_DIV: "2"
         *         }
         *     }, onContractPopup, function() {
         *         $NC.setFocus("#edtQContract_No", true);
         *     });
         * </pre>
         * 
         * @since 7.5.0
         * @memberof $NP#
         */
        function showContractPopup(options, onPopupSelect, onPopupCancel) {

            var requestData;
            if ($NC.isNull(options)) {
                return;
            }

            // 호출방법1일 경우, 파라메터 조정
            if ($NC.isNull(options.queryParams)) {
                options = {
                    queryParams: options
                };
            }

            _setTitleOptions(options,
            // 팝업 타이틀
            $NC.getDisplayName("POPUP_CONTRACT", "계약번호"),
            // 기본 컬럼타이틀
            [
                $NC.getDisplayName("CONTRACT_NO", "계약번호"),
                $NC.getDisplayName("CONTRACT_NM", "계약명"),
                $NC.getDisplayName("CUST_CD", "고객사코드"),
                $NC.getDisplayName("CUST_NM", "고객사명")
            ],
            // 컬럼 정보
            [
                {
                    id: "CONTRACT_NO",
                    field: "CONTRACT_NO",
                    width: 80
                },
                {
                    id: "CONTRACT_NM",
                    field: "CONTRACT_NM",
                    width: 150
                },
                {
                    id: "CUST_CD",
                    field: "CUST_CD",
                    width: 70
                },
                {
                    id: "CUST_NM",
                    field: "CUST_NM",
                    width: 140
                }
            ]);

            requestData = {
                containerId: "ctrCommonPopupContract",
                title: options.title,
                autoInquiry: true,
                width: 400,
                height: 450,
                requestUrl: options.requestUrl,
                queryId: $NC.nullToDefault(options.queryId, "WC.POP_LFCONTRACT"),
                queryParams: options.queryParams,
                queryData: options.queryData,
                querySearchParam: $NC.nullToDefault(options.querySearchParam, "P_CONTRACT_NO"),
                queryCanAll: $NC.nullToDefault(options.queryCanAll, true),
                columns: options.columns,
                multiSelect: options.multiSelect,
                multiValue: options.multiValue,
                addBase: $NC.nullToDefault(options.addBase, ""),
                onSelect: onPopupSelect,
                onCancel: onPopupCancel,
                onClose: $THIS.onPopupClose
            };

            _showPopup(requestData);
        }

        /**
         * 계약번호, 정산구분 팝업
         * 
         * @param {Object}
         *        options 팝업 호출 옵션
         * 
         * <pre>
         * <b>호출 방법 1(단순 설정)</b>
         * options 에 쿼리 파라메터를 지정한 경우 파라메터를 제외하고 모두 기본값으로 팝업 실행
         * 
         * <b>호출 방법 2(상세 설정)</b>
         * title                [옵션]:      {String}        팝업 창 타이틀
         * columnTitle          [옵션]:      {Array}         컬럼 타이틀, ["코드", "명"], 미지정시 기본 값
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * queryParams          [필수]:      {String}        쿼리 파라메터 지정
         * querySearchParam     [옵션]:      {String}        팝업 창 검색시 검색 값을 입력할 파라메터 명
         * queryCanAll          [옵션]:      {String}        팝업 창 전체 검색 가능 여부
         * queryData            [옵션]:      {Array}         데이터, 데이터를 넘겨줄 경우 서비스 호출하지 않음
         * </pre>
         * 
         * @param {Function}
         *        onPopupSelect 선택 버튼 클릭시 호출될 이벤트
         * @param {Function}
         *        onPopupCancel 취소 버튼 클릭시 호출될 이벤트
         * @example
         * 
         * <pre>
         * Call:
         *     // 호출 방법 1(단순 설정)
         *     $NP.showContractBillPopup({
         *         P_CENTER_CD: $NC.getValue("#cboCenter_Cd"),
         *         P_BU_CD: $NC.getValue("#edtBu_Cd"),
         *         P_CONTRACT_NO: CONTRACT_NO,
         *         P_BILL_DIV: "10",
         *         P_PRICE_DIV: "01",
         *         P_VIEW_DIV: "2"
         *     }, onContractBillPopup, function() {
         *         $NC.setFocus("#edtQContract_No", true);
         *     });
         * 
         *     // 호출 방법 2(상세 설정)
         *     $NP.showContractBillPopup({
         *         title: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "계약번호 검색"),
         *         columnTitle: [
         *             $NC.getDisplayName("CONTRACT_NO", "계약번호"),
         *             $NC.getDisplayName("CONTRACT_NM", "계약명")
         *             $NC.getDisplayName("BILL_DIV", "정산구분"),
         *             $NC.getDisplayName("BILL_DIV_D", "정산구분명")
         *         ],
         *         queryParams: {
         *         P_CENTER_CD: $NC.getValue("#cboCenter_Cd"),
         *         P_BU_CD: $NC.getValue("#edtBu_Cd"),
         *         P_CONTRACT_NO: CONTRACT_NO,
         *         P_BILL_DIV: "10",
         *         P_PRICE_DIV: "01",
         *         P_VIEW_DIV: "2"
         *         }
         *     }, onContractBillPopup, function() {
         *         $NC.setFocus("#edtQContract_No", true);
         *     });
         * </pre>
         * 
         * @since 7.5.0
         * @memberof $NP#
         */
        function showContractBillPopup(options, onPopupSelect, onPopupCancel) {

            var requestData;
            if ($NC.isNull(options)) {
                return;
            }

            // 호출방법1일 경우, 파라메터 조정
            if ($NC.isNull(options.queryParams)) {
                options = {
                    queryParams: options
                };
            }

            _setTitleOptions(options,
            // 팝업 타이틀
            $NC.getDisplayName("POPUP_CONTRACTBILL", "계약번호"),
            // 기본 컬럼타이틀
            [
                $NC.getDisplayName("CONTRACT_NO", "계약번호"),
                $NC.getDisplayName("CONTRACT_NM", "계약명"),
                $NC.getDisplayName("BILL_DIV", "정산구분"),
                $NC.getDisplayName("BILL_DIV_D", "정산구분명")
            ],
            // 컬럼 정보
            [
                {
                    id: "CONTRACT_NO",
                    field: "CONTRACT_NO",
                    width: 80
                },
                {
                    id: "CONTRACT_NM",
                    field: "CONTRACT_NM",
                    width: 150
                },
                {
                    id: "BILL_DIV",
                    field: "BILL_DIV",
                    width: 80
                },
                {
                    id: "BILL_DIV_D",
                    field: "BILL_DIV_D",
                    width: 150
                }
            ]);

            requestData = {
                containerId: "ctrCommonPopupContractBill",
                title: options.title,
                autoInquiry: true,
                width: 400,
                height: 450,
                requestUrl: options.requestUrl,
                queryId: $NC.nullToDefault(options.queryId, "WC.POP_LFCONTRACTBILL"),
                queryParams: options.queryParams,
                queryData: options.queryData,
                querySearchParam: $NC.nullToDefault(options.querySearchParam, "P_CONTRACT_NO"),
                queryCanAll: $NC.nullToDefault(options.queryCanAll, true),
                columns: options.columns,
                multiSelect: options.multiSelect,
                multiValue: options.multiValue,
                addBase: $NC.nullToDefault(options.addBase, ""),
                onSelect: onPopupSelect,
                onCancel: onPopupCancel,
                onClose: $THIS.onPopupClose
            };

            _showPopup(requestData);
        }

        /**
         * 정산구분 팝업
         * 
         * @param {Object}
         *        options 팝업 호출 옵션
         * 
         * <pre>
         * <b>호출 방법 1(단순 설정)</b>
         * options 에 쿼리 파라메터를 지정한 경우 파라메터를 제외하고 모두 기본값으로 팝업 실행
         * 
         * <b>호출 방법 2(상세 설정)</b>
         * title                [옵션]:      {String}        팝업 창 타이틀
         * columnTitle          [옵션]:      {Array}         컬럼 타이틀, ["코드", "명"], 미지정시 기본 값
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * queryParams          [필수]:      {String}        쿼리 파라메터 지정
         * querySearchParam     [옵션]:      {String}        팝업 창 검색시 검색 값을 입력할 파라메터 명
         * queryCanAll          [옵션]:      {String}        팝업 창 전체 검색 가능 여부
         * queryData            [옵션]:      {Array}         데이터, 데이터를 넘겨줄 경우 서비스 호출하지 않음
         * </pre>
         * 
         * @param {Function}
         *        onPopupSelect 선택 버튼 클릭시 호출될 이벤트
         * @param {Function}
         *        onPopupCancel 취소 버튼 클릭시 호출될 이벤트
         * @example
         * 
         * <pre>
         * Call:
         *     // 호출 방법 1(단순 설정)
         *     $NP.showBillPopup({
         *         P_BILL_DIV: BILL_DIV,
         *         P_PRICE_DIV: "01",
         *         P_VIEW_DIV: "2"
         *     }, onBillPopup, function() {
         *         $NC.setFocus("#edtQBill_No", true);
         *     });
         * 
         *     // 호출 방법 2(상세 설정)
         *     $NP.showBillPopup({
         *         title: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "정산구분 검색"),
         *         columnTitle: [
         *             $NC.getDisplayName("BILL_DIV", "정산구분"),
         *             $NC.getDisplayName("BILL_DIV_D", "정산구분명")
         *         ],
         *         queryParams: {
         *         P_BILL_DIV: BILL_DIV,
         *         P_PRICE_DIV: "01",
         *         P_VIEW_DIV: "2"
         *         }
         *     }, onBillPopup, function() {
         *         $NC.setFocus("#edtQBill_No", true);
         *     });
         * </pre>
         * 
         * @since 7.5.0
         * @memberof $NP#
         */
        function showBillPopup(options, onPopupSelect, onPopupCancel) {

            var requestData;
            if ($NC.isNull(options)) {
                return;
            }

            // 호출방법1일 경우, 파라메터 조정
            if ($NC.isNull(options.queryParams)) {
                options = {
                    queryParams: options
                };
            }

            _setTitleOptions(options,
            // 팝업 타이틀
            $NC.getDisplayName("POPUP_BILL", "정산구분"),
            // 기본 컬럼타이틀
            [
                $NC.getDisplayName("BILL_DIV", "정산구분"),
                $NC.getDisplayName("BILL_DIV_D", "정산구분명")
            ],
            // 컬럼 정보
            [
                {
                    id: "BILL_DIV",
                    field: "BILL_DIV",
                    width: 80
                },
                {
                    id: "BILL_DIV_D",
                    field: "BILL_DIV_D",
                    width: 150
                }
            ]);

            requestData = {
                containerId: "ctrCommonPopupBill",
                title: options.title,
                autoInquiry: true,
                width: 400,
                height: 450,
                requestUrl: options.requestUrl,
                queryId: $NC.nullToDefault(options.queryId, "WC.POP_LFBILL"),
                queryParams: options.queryParams,
                queryData: options.queryData,
                querySearchParam: $NC.nullToDefault(options.querySearchParam, "P_BILL_DIV"),
                queryCanAll: $NC.nullToDefault(options.queryCanAll, true),
                columns: options.columns,
                multiSelect: options.multiSelect,
                multiValue: options.multiValue,
                addBase: $NC.nullToDefault(options.addBase, ""),
                onSelect: onPopupSelect,
                onCancel: onPopupCancel,
                onClose: $THIS.onPopupClose
            };

            _showPopup(requestData);
        }

        /**
         * 포장박스(정산) 팝업
         * 
         * @param {Object}
         *        options 팝업 호출 옵션
         * 
         * <pre>
         * <b>호출 방법 1(단순 설정)</b>
         * options 에 쿼리 파라메터를 지정한 경우 파라메터를 제외하고 모두 기본값으로 팝업 실행
         * 
         * <b>호출 방법 2(상세 설정)</b>
         * title                [옵션]:      {String}        팝업 창 타이틀
         * columnTitle          [옵션]:      {Array}         컬럼 타이틀, ["코드", "명"], 미지정시 기본 값
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * queryParams          [필수]:      {String}        쿼리 파라메터 지정
         * querySearchParam     [옵션]:      {String}        팝업 창 검색시 검색 값을 입력할 파라메터 명
         * queryCanAll          [옵션]:      {String}        팝업 창 전체 검색 가능 여부
         * queryData            [옵션]:      {Array}         데이터, 데이터를 넘겨줄 경우 서비스 호출하지 않음
         * </pre>
         * 
         * @param {Function}
         *        onPopupSelect 선택 버튼 클릭시 호출될 이벤트
         * @param {Function}
         *        onPopupCancel 취소 버튼 클릭시 호출될 이벤트
         * @example
         * 
         * <pre>
         * Call:
         *     // 호출 방법 1(단순 설정)
         *     $NP.showBillBoxPopup({
         *         P_CONTRACT_NO: args.val,
         *         P_BILL_DIV: args.val,
         *         P_BU_CD: $ND.C_ALL,
         *         P_BOX_SIZE_CD: args.val,
         *         P_VIEW_DIV: "1"
         *     }, onBillBoxPopup, function() {
         *         $NC.setFocus("#edtQBill_No", true);
         *     });
         * 
         *     // 호출 방법 2(상세 설정)
         *     $NP.showBillBoxPopup({
         *         title: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "박스코드 검색"),
         *         columnTitle: [
         *             $NC.getDisplayName("BOX_SIZE_CD", "박스코드"),
         *             $NC.getDisplayName("BOX_SIZE_NM", "박스코드명"),
         *             $NC.getDisplayName("BU_CD", "사업부코드"),
         *             $NC.getDisplayName("BU_NM", "사업부명")
         *         ],
         *         queryParams: {
         *         P_CONTRACT_NO: args.val,
         *         P_BILL_DIV: args.val,
         *         P_BU_CD: $ND.C_ALL,
         *         P_BOX_SIZE_CD: args.val,
         *         P_VIEW_DIV: "1"
         *         }
         *     }, onBillBoxPopup, function() {
         *         $NC.setFocus("#edtQBill_No", true);
         *     });
         * </pre>
         * 
         * @since 7.5.0
         * @memberof $NP#
         */
        function showBillBoxPopup(options, onPopupSelect, onPopupCancel) {

            var requestData;
            if ($NC.isNull(options)) {
                return;
            }

            // 호출방법1일 경우, 파라메터 조정
            if ($NC.isNull(options.queryParams)) {
                options = {
                    queryParams: options
                };
            }

            _setTitleOptions(options,
            // 팝업 타이틀
            $NC.getDisplayName("POPUP_BILLBOX", "박스코드"),
            // 기본 컬럼타이틀
            [
                $NC.getDisplayName("BOX_SIZE_CD", "박스코드"),
                $NC.getDisplayName("BOX_SIZE_NM", "박스코드명"),
                $NC.getDisplayName("BU_CD", "사업부코드"),
                $NC.getDisplayName("BU_NM", "사업부명")
            ],
            // 컬럼 정보
            [
                {
                    id: "BOX_SIZE_CD",
                    field: "BOX_SIZE_CD",
                    width: 80
                },
                {
                    id: "BOX_SIZE_NM",
                    field: "BOX_SIZE_NM",
                    width: 150
                },
                {
                    id: "BU_CD",
                    field: "BU_CD",
                    width: 80
                },
                {
                    id: "BU_NM",
                    field: "BU_NM",
                    width: 150
                }
            ]);

            requestData = {
                containerId: "ctrCommonPopupBillBox",
                title: options.title,
                autoInquiry: true,
                width: 400,
                height: 450,
                requestUrl: options.requestUrl,
                queryId: $NC.nullToDefault(options.queryId, "WC.POP_LFBILLBOX"),
                queryParams: options.queryParams,
                queryData: options.queryData,
                querySearchParam: $NC.nullToDefault(options.querySearchParam, "P_BOX_SIZE_CD"),
                queryCanAll: $NC.nullToDefault(options.queryCanAll, true),
                columns: options.columns,
                multiSelect: options.multiSelect,
                multiValue: options.multiValue,
                addBase: $NC.nullToDefault(options.addBase, ""),
                onSelect: onPopupSelect,
                onCancel: onPopupCancel,
                onClose: $THIS.onPopupClose
            };

            _showPopup(requestData);
        }

        /**
         * 사업부 정보 검색
         * 
         * @param {Object}
         *        options 호출 옵션
         * 
         * <pre>
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * queryParams          [필수]:      {String}        쿼리 파라메터 지정
         * showErrorMessage     [옵션]:      {Boolean}       미지정 또는 true 시 검색 결과가 없을 시 오류 메시지 표시
         * errorMessage         [옵션]:      {String}        오류 메시지, 미지정시 기본 오류메시지
         * </pre>
         * 
         * @returns {Array}
         * @example
         * 
         * <pre>
         * Get:
         *     var P_QUERY_PARAMS = {
         *         P_BU_CD: args.val
         *     };
         * 
         *     O_RESULT_DATA = $NP.getBuInfo({
         *         queryParams: P_QUERY_PARAMS
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function getBuInfo(options) {

            return _getDataSet(options, "WC.POP_CMBU", $NC.getDisplayMsg("JS.POPUP.002", "등록되어 있지 않은 사업부입니다."));
        }

        /**
         * 사업부 브랜드 정보 검색
         * 
         * @param {Object}
         *        options 호출 옵션
         * 
         * <pre>
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * queryParams          [필수]:      {String}        쿼리 파라메터 지정
         * showErrorMessage     [옵션]:      {Boolean}       미지정 또는 true 시 검색 결과가 없을 시 오류 메시지 표시
         * errorMessage         [옵션]:      {String}        오류 메시지, 미지정시 기본 오류메시지
         * </pre>
         * 
         * @returns {Array}
         * @example
         * 
         * <pre>
         * Get:
         *     var P_QUERY_PARAMS = {
         *         P_BU_CD: BU_CD,
         *         P_DELIVERY_CD: args.val
         *     };
         * 
         *     O_RESULT_DATA = $NP.getBuBrandInfo({
         *         queryParams: P_QUERY_PARAMS
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function getBuBrandInfo(options) {

            return _getDataSet(options, "WC.POP_CMBUBRAND", $NC.getDisplayMsg("JS.POPUP.003", "사업부에 등록되어 있지 않은 브랜드입니다."));
        }

        /**
         * 고객사 브랜드 정보 검색
         * 
         * @param {Object}
         *        options 호출 옵션
         * 
         * <pre>
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * queryParams          [필수]:      {String}        쿼리 파라메터 지정
         * showErrorMessage     [옵션]:      {Boolean}       미지정 또는 true 시 검색 결과가 없을 시 오류 메시지 표시
         * errorMessage         [옵션]:      {String}        오류 메시지, 미지정시 기본 오류메시지
         * </pre>
         * 
         * @returns {Array}
         * @example
         * 
         * <pre>
         * Get:
         *     var P_QUERY_PARAMS = {
         *         P_CUST_CD: CUST_CD,
         *         P_BRAND_CD: args.val
         *     };
         * 
         *     O_RESULT_DATA = $NP.getCustBrandInfo({
         *         queryParams: P_QUERY_PARAMS
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function getCustBrandInfo(options) {

            return _getDataSet(options, "WC.POP_CMCUSTBRAND", $NC.getDisplayMsg("JS.POPUP.004", "고객사에 등록되어 있지 않은 브랜드입니다."));
        }

        /**
         * 브랜드 정보 검색
         * 
         * @param {Object}
         *        options 호출 옵션
         * 
         * <pre>
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * queryParams          [필수]:      {String}        쿼리 파라메터 지정
         * showErrorMessage     [옵션]:      {Boolean}       미지정 또는 true 시 검색 결과가 없을 시 오류 메시지 표시
         * errorMessage         [옵션]:      {String}        오류 메시지, 미지정시 기본 오류메시지
         * </pre>
         * 
         * @returns {Array}
         * @example
         * 
         * <pre>
         * Get:
         *     var P_QUERY_PARAMS = {
         *         P_BRAND_CD: args.val,
         *         P_VIEW_DIV: "1"
         *     };
         * 
         *     O_RESULT_DATA = $NP.getBrandInfo({
         *         queryParams: P_QUERY_PARAMS
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function getBrandInfo(options) {

            return _getDataSet(options, "WC.POP_CMBRAND", $NC.getDisplayMsg("JS.POPUP.005", "등록되어 있지 않은 브랜드입니다."));
        }

        /**
         * 차량정보 검색
         * 
         * @param {Object}
         *        options 호출 옵션
         * 
         * <pre>
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * queryParams          [필수]:      {String}        쿼리 파라메터 지정
         * showErrorMessage     [옵션]:      {Boolean}       미지정 또는 true 시 검색 결과가 없을 시 오류 메시지 표시
         * errorMessage         [옵션]:      {String}        오류 메시지, 미지정시 기본 오류메시지
         * </pre>
         * 
         * @returns {Array}
         * @example
         * 
         * <pre>
         * Get:
         *     var P_QUERY_PARAMS = {
         *         P_CAR_CD: args.val,
         *         P_VIEW_DIV: "1"
         *     };
         * 
         *     O_RESULT_DATA = $NP.getCarInfo({
         *         queryParams: P_QUERY_PARAMS
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function getCarInfo(options) {

            return _getDataSet(options, "WC.POP_CMCAR", $NC.getDisplayMsg("JS.POPUP.006", "등록되어 있지 않은 차량입니다."));
        }

        /**
         * 물류센터정보 검색
         * 
         * @param {Object}
         *        options 호출 옵션
         * 
         * <pre>
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * queryParams          [필수]:      {String}        쿼리 파라메터 지정
         * showErrorMessage     [옵션]:      {Boolean}       미지정 또는 true 시 검색 결과가 없을 시 오류 메시지 표시
         * errorMessage         [옵션]:      {String}        오류 메시지, 미지정시 기본 오류메시지
         * </pre>
         * 
         * @returns {Array}
         * @example
         * 
         * <pre>
         * Get:
         *     var P_QUERY_PARAMS = {
         *         P_CENTER_CD: args.val
         *     };
         * 
         *     O_RESULT_DATA = $NP.getCenterInfo({
         *         queryParams: P_QUERY_PARAMS
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function getCenterInfo(options) {

            return _getDataSet(options, "WC.POP_CMCENTER", $NC.getDisplayMsg("JS.POPUP.007", "등록되어 있지 않은 물류센터입니다."));
        }

        /**
         * 공통코드정보 검색
         * 
         * @param {Object}
         *        options 호출 옵션
         * 
         * <pre>
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * queryParams          [필수]:      {String}        쿼리 파라메터 지정
         * showErrorMessage     [옵션]:      {Boolean}       미지정 또는 true 시 검색 결과가 없을 시 오류 메시지 표시
         * errorMessage         [옵션]:      {String}        오류 메시지, 미지정시 기본 오류메시지
         * </pre>
         * 
         * @returns {Array}
         * @example
         * 
         * <pre>
         * Get:
         *     var P_QUERY_PARAMS = {
         *         P_COMMON_GRP: "ITEM_STATE",
         *         P_COMMON_CD: args.val,
         *         P_VIEW_DIV: "1"
         *     };
         * 
         *     O_RESULT_DATA = $NP.getCodeInfo({
         *         queryParams: P_QUERY_PARAMS
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function getCodeInfo(options) {

            return _getDataSet(options, "WC.POP_CMCODE", $NC.getDisplayMsg("JS.POPUP.008", "등록되어 있지 않은 코드입니다."));
        }

        /**
         * 고객사정보 검색
         * 
         * @param {Object}
         *        options 호출 옵션
         * 
         * <pre>
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * queryParams          [필수]:      {String}        쿼리 파라메터 지정
         * showErrorMessage     [옵션]:      {Boolean}       미지정 또는 true 시 검색 결과가 없을 시 오류 메시지 표시
         * errorMessage         [옵션]:      {String}        오류 메시지, 미지정시 기본 오류메시지
         * </pre>
         * 
         * @returns {Array}
         * @example
         * 
         * <pre>
         * Get:
         *     var P_QUERY_PARAMS = {
         *         P_CUST_CD: args.val
         *     };
         * 
         *     O_RESULT_DATA = $NP.getCustInfo({
         *         queryParams: P_QUERY_PARAMS
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function getCustInfo(options) {

            return _getDataSet(options, "WC.POP_CMCUST", $NC.getDisplayMsg("JS.POPUP.009", "등록되어 있지 않은 고객사입니다."));
        }

        /**
         * 운송권역정보 검색
         * 
         * @param {Object}
         *        options 호출 옵션
         * 
         * <pre>
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * queryParams          [필수]:      {String}        쿼리 파라메터 지정
         * showErrorMessage     [옵션]:      {Boolean}       미지정 또는 true 시 검색 결과가 없을 시 오류 메시지 표시
         * errorMessage         [옵션]:      {String}        오류 메시지, 미지정시 기본 오류메시지
         * </pre>
         * 
         * @returns {Array}
         * @example
         * 
         * <pre>
         * Get:
         *     var P_QUERY_PARAMS = {
         *         P_CENTER_CD: CENTER_CD,
         *         P_AREA_CD: args.val
         *     };
         * 
         *     O_RESULT_DATA = $NP.getDeliveryAreaInfo({
         *         queryParams: P_QUERY_PARAMS
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function getDeliveryAreaInfo(options) {

            return _getDataSet(options, "WC.POP_CMDELIVERYAREA", $NC.getDisplayMsg("JS.POPUP.010", "등록되어 있지 않은 운송권역입니다."));
        }

        /**
         * 배송처정보 검색
         * 
         * @param {Object}
         *        options 호출 옵션
         * 
         * <pre>
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * queryParams          [필수]:      {String}        쿼리 파라메터 지정
         * showErrorMessage     [옵션]:      {Boolean}       미지정 또는 true 시 검색 결과가 없을 시 오류 메시지 표시
         * errorMessage         [옵션]:      {String}        오류 메시지, 미지정시 기본 오류메시지
         * </pre>
         * 
         * @returns {Array}
         * @example
         * 
         * <pre>
         * Get:
         *     var P_QUERY_PARAMS = {
         *         P_CUST_CD: CUST_CD,
         *         P_DELIVERY_CD: args.val,
         *         P_DELIVERY_DIV: $ND.C_ALL,
         *         P_VIEW_DIV: "1"
         *     };
         * 
         *     O_RESULT_DATA = $NP.getDeliveryInfo({
         *         queryParams: P_QUERY_PARAMS
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function getDeliveryInfo(options) {

            return _getDataSet(options, "WC.POP_CMDELIVERY", $NC.getDisplayMsg("JS.POPUP.011", "등록되어 있지 않은 배송처입니다."));
        }

        /**
         * 부서정보 검색
         * 
         * @param {Object}
         *        options 호출 옵션
         * 
         * <pre>
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * queryParams          [필수]:      {String}        쿼리 파라메터 지정
         * showErrorMessage     [옵션]:      {Boolean}       미지정 또는 true 시 검색 결과가 없을 시 오류 메시지 표시
         * errorMessage         [옵션]:      {String}        오류 메시지, 미지정시 기본 오류메시지
         * </pre>
         * 
         * @returns {Array}
         * @example
         * 
         * <pre>
         * Get:
         *     var P_QUERY_PARAMS = {
         *         P_CUST_CD: CUST_CD,
         *         P_DEPT_CD: args.val,
         *         P_VIEW_DIV: "1"
         *     };
         * 
         *     O_RESULT_DATA = $NP.getDeptInfo({
         *         queryParams: P_QUERY_PARAMS
         *     });
         * </pre>
         * 
         * @since 7.0.0
         * @memberof $NP#
         */
        function getDeptInfo(options) {

            return _getDataSet(options, "WC.POP_CMDEPT", $NC.getDisplayMsg("JS.POPUP.025", "등록되어 있지 않은 부서입니다."));
        }

        /**
         * 상품 정보 검색
         * 
         * @param {Object}
         *        options 호출 옵션
         * 
         * <pre>
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * queryParams          [필수]:      {String}        쿼리 파라메터 지정
         * showErrorMessage     [옵션]:      {Boolean}       미지정 또는 true 시 검색 결과가 없을 시 오류 메시지 표시
         * errorMessage         [옵션]:      {String}        오류 메시지, 미지정시 기본 오류메시지
         * </pre>
         * 
         * @returns {Array}
         * @example
         * 
         * <pre>
         * Get:
         *     var P_QUERY_PARAMS = {
         *         P_BU_CD: BU_CD,
         *         P_BRAND_CD: $ND.C_ALL,
         *         P_ITEM_CD: args.val,
         *         P_VIEW_DIV: "2",
         *         P_DEPART_CD: $ND.C_ALL,
         *         P_LINE_CD: $ND.C_ALL,
         *         P_CLASS_CD: $ND.C_ALL
         *     };
         * 
         *     O_RESULT_DATA = $NP.getItemInfo({
         *         queryParams: P_QUERY_PARAMS
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function getItemInfo(options) {

            return _getDataSet(options, "WC.POP_CMITEM", $NC.getDisplayMsg("JS.POPUP.012", "등록되어 있지 않은 상품입니다."));
        }

        /**
         * 재고 LOT번호 검색
         * 
         * @param {Object}
         *        options 호출 옵션
         * 
         * <pre>
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * queryParams          [필수]:      {String}        쿼리 파라메터 지정
         * showErrorMessage     [옵션]:      {Boolean}       미지정 또는 true 시 검색 결과가 없을 시 오류 메시지 표시
         * errorMessage         [옵션]:      {String}        오류 메시지, 미지정시 기본 오류메시지
         * </pre>
         * 
         * @returns {Array}
         * @example
         * 
         * <pre>
         * Get:
         *     var P_QUERY_PARAMS = {
         *         P_CENTER_CD: CENTER_CD,
         *         P_BU_CD: BU_CD,
         *         P_BRAND_CD: BRAND_CD,
         *         P_ITEM_CD: ITEM_CD,
         *         P_ITEM_STATE: ITEM_STATE,
         *         P_ITEM_LOT: args.val
         *     };
         * 
         *     O_RESULT_DATA = $NP.getItemLotInfo({
         *         queryParams: P_QUERY_PARAMS
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function getItemLotInfo(options) {

            return _getDataSet(options, "WC.POP_ITEM_LOT", $NC.getDisplayMsg("JS.POPUP.013", "현재고에 존재하지 않는 LOT번호입니다."));
        }

        /**
         * 로케이션 검색
         * 
         * @param {Object}
         *        options 호출 옵션
         * 
         * <pre>
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * queryParams          [필수]:      {String}        쿼리 파라메터 지정
         * showErrorMessage     [옵션]:      {Boolean}       미지정 또는 true 시 검색 결과가 없을 시 오류 메시지 표시
         * errorMessage         [옵션]:      {String}        오류 메시지, 미지정시 기본 오류메시지
         * </pre>
         * 
         * @returns {Array}
         * @example
         * 
         * <pre>
         * Get:
         *     var P_QUERY_PARAMS = {
         *         P_CENTER_CD: CENTER_CD,
         *         P_ZONE_CD: "",
         *         P_BANK_CD: "",
         *         P_BAY_CD: "",
         *         P_LEV_CD: "",
         *         P_LOCATION_CD: args.val,
         *         P_ZONE_DIV_ATTR01_CD: "1" // 1 - 일반, 2- 유통가공, 3 - 보세
         *     };
         * 
         *     O_RESULT_DATA = $NP.getLocationInfo({
         *         queryParams: P_QUERY_PARAMS
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function getLocationInfo(options) {

            return _getDataSet(options, "WC.POP_CMLOCATION", $NC.getDisplayMsg("JS.POPUP.014", "등록되어 있지 않은 로케이션입니다."));
        }

        /**
         * 자재 검색
         * 
         * @param {Object}
         *        options 호출 옵션
         * 
         * <pre>
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * queryParams          [필수]:      {String}        쿼리 파라메터 지정
         * showErrorMessage     [옵션]:      {Boolean}       미지정 또는 true 시 검색 결과가 없을 시 오류 메시지 표시
         * errorMessage         [옵션]:      {String}        오류 메시지, 미지정시 기본 오류메시지
         * </pre>
         * 
         * @returns {Array}
         * @example
         * 
         * <pre>
         * Get:
         *     var P_QUERY_PARAMS = {
         *         P_CUST_CD: CUST_CD,
         *         P_MATERIAL_CD: args.val
         *     };
         * 
         *     O_RESULT_DATA = $NP.getMaterialInfo({
         *         queryParams: P_QUERY_PARAMS
         *     });
         * </pre>
         * 
         * @since 7.5.0
         * @memberof $NP#
         */
        function getMaterialInfo(options) {

            return _getDataSet(options, "WC.POP_CMMATERIAL", $NC.getDisplayMsg("JS.POPUP.015", "등록되어 있지 않은 자재입니다."));
        }

        /**
         * 조직 검색
         * 
         * @param {Object}
         *        options 호출 옵션
         * 
         * <pre>
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * queryParams          [필수]:      {String}        쿼리 파라메터 지정
         * showErrorMessage     [옵션]:      {Boolean}       미지정 또는 true 시 검색 결과가 없을 시 오류 메시지 표시
         * errorMessage         [옵션]:      {String}        오류 메시지, 미지정시 기본 오류메시지
         * </pre>
         * 
         * @returns {Array}
         * @example
         * 
         * <pre>
         * Get:
         *     var P_QUERY_PARAMS = {
         *         P_ORGN_DIV: "1", // 1-조직, 2-서비스
         *         P_ORGN_CD: args.val,
         *         P_VIEW_DIV: "2"
         *     };
         * 
         *     O_RESULT_DATA = $NP.getOrgnInfo({
         *         queryParams: P_QUERY_PARAMS
         *     });
         * </pre>
         * 
         * @since 7.1.0
         * @memberof $NP#
         */
        function getOrgnInfo(options) {

            return _getDataSet(options, "WC.POP_CMORGN", $NC.getDisplayMsg("JS.POPUP.024", "등록되어 있지 않은 조직입니다."));
        }

        /**
         * 우편번호 검색
         * 
         * @param {Object}
         *        options 호출 옵션
         * 
         * <pre>
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * queryParams          [필수]:      {String}        쿼리 파라메터 지정
         * showErrorMessage     [옵션]:      {Boolean}       미지정 또는 true 시 검색 결과가 없을 시 오류 메시지 표시
         * errorMessage         [옵션]:      {String}        오류 메시지, 미지정시 기본 오류메시지
         * </pre>
         * 
         * @returns {Array}
         * @example
         * 
         * <pre>
         * Get:
         *     var P_QUERY_PARAMS = {
         *         P_ADDR_NM: args.val
         *     };
         * 
         *     O_RESULT_DATA = $NP.getPostInfo({
         *         queryParams: P_QUERY_PARAMS
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function getPostInfo(options) {

            return _getDataSet(options, "WC.POP_CMPOST", $NC.getDisplayMsg("JS.POPUP.015", "등록되어 있지 않은 우편번호입니다."));
        }

        /**
         * 관련사 정보 검색
         * 
         * @param {Object}
         *        options 호출 옵션
         * 
         * <pre>
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * queryParams          [필수]:      {String}        쿼리 파라메터 지정
         * showErrorMessage     [옵션]:      {Boolean}       미지정 또는 true 시 검색 결과가 없을 시 오류 메시지 표시
         * errorMessage         [옵션]:      {String}        오류 메시지, 미지정시 기본 오류메시지
         * </pre>
         * 
         * @returns {Array}
         * @example
         * 
         * <pre>
         * Get:
         *     var P_QUERY_PARAMS = {
         *         P_REF_CUST_CD: args.val,
         *         P_REF_CUST_DIV: $ND.C_ALL,
         *         P_VIEW_DIV: "1"
         *     };
         * 
         *     O_RESULT_DATA = $NP.getReferenceInfo({
         *         queryParams: P_QUERY_PARAMS
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function getReferenceInfo(options) {

            return _getDataSet(options, "WC.POP_CMREFERENCE", $NC.getDisplayMsg("JS.POPUP.016", "등록되어 있지 않은 관련사입니다."));
        }

        /**
         * 운송사 정보 검색
         * 
         * @param {Object}
         *        options 호출 옵션
         * 
         * <pre>
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * queryParams          [필수]:      {String}        쿼리 파라메터 지정
         * showErrorMessage     [옵션]:      {Boolean}       미지정 또는 true 시 검색 결과가 없을 시 오류 메시지 표시
         * errorMessage         [옵션]:      {String}        오류 메시지, 미지정시 기본 오류메시지
         * </pre>
         * 
         * @returns {Array}
         * @example
         * 
         * <pre>
         * Get:
         *     var P_QUERY_PARAMS = {
         *         P_CARRIER_CD: args.val,
         *         P_CARRIER_DIV: $ND.C_ALL,
         *         P_VIEW_DIV: "1"
         *     };
         * 
         *     O_RESULT_DATA = $NP.getCarrierInfo({
         *         queryParams: P_QUERY_PARAMS
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function getCarrierInfo(options) {

            return _getDataSet(options, "WC.POP_CMCARRIER", $NC.getDisplayMsg("JS.POPUP.017", "등록되어 있지 않은 운송사입니다."));
        }

        /**
         * 사용자 사업부 정보 검색
         * 
         * @param {Object}
         *        options 호출 옵션
         * 
         * <pre>
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * queryParams          [필수]:      {String}        쿼리 파라메터 지정
         * showErrorMessage     [옵션]:      {Boolean}       미지정 또는 true 시 검색 결과가 없을 시 오류 메시지 표시
         * errorMessage         [옵션]:      {String}        오류 메시지, 미지정시 기본 오류메시지
         * </pre>
         * 
         * @returns {Array}
         * @example
         * 
         * <pre>
         * Get:
         *     var P_QUERY_PARAMS = {
         *         P_USER_ID: args.val,
         *         P_BU_CD: $ND.C_ALL,
         *         P_CUST_CD: $ND.C_ALL
         *     };
         * 
         *     O_RESULT_DATA = $NP.getUserBuInfo({
         *         queryParams: P_QUERY_PARAMS
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function getUserBuInfo(options) {

            return _getDataSet(options, "WC.POP_CSUSERBU", $NC.getDisplayMsg("JS.POPUP.018", "해당 사용자에 등록되어 있지 않은 사업부입니다."));
        }

        /**
         * 사용자 브랜드정보 검색
         * 
         * @param {Object}
         *        options 호출 옵션
         * 
         * <pre>
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * queryParams          [필수]:      {String}        쿼리 파라메터 지정
         * showErrorMessage     [옵션]:      {Boolean}       미지정 또는 true 시 검색 결과가 없을 시 오류 메시지 표시
         * errorMessage         [옵션]:      {String}        오류 메시지, 미지정시 기본 오류메시지
         * </pre>
         * 
         * @returns {Array}
         * @example
         * 
         * <pre>
         * Get:
         *     var P_QUERY_PARAMS = {
         *         P_USER_ID: args.val,
         *         P_BRAND_CD: $ND.C_ALL
         *     };
         * 
         *     O_RESULT_DATA = $NP.getUserBrandInfo({
         *         queryParams: P_QUERY_PARAMS
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function getUserBrandInfo(options) {

            return _getDataSet(options, "WC.POP_CSUSERBRAND", $NC.getDisplayMsg("JS.POPUP.019", "해당 사용자에 등록되어 있지 않은 브랜드입니다."));
        }

        /**
         * 사용자 물류센터 정보 검색
         * 
         * @param {Object}
         *        options 호출 옵션
         * 
         * <pre>
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * queryParams          [필수]:      {String}        쿼리 파라메터 지정
         * showErrorMessage     [옵션]:      {Boolean}       미지정 또는 true 시 검색 결과가 없을 시 오류 메시지 표시
         * errorMessage         [옵션]:      {String}        오류 메시지, 미지정시 기본 오류메시지
         * </pre>
         * 
         * @returns {Array}
         * @example
         * 
         * <pre>
         * Get:
         *     var P_QUERY_PARAMS = {
         *         P_USER_ID: args.val,
         *         P_CENTER_CD: $ND.C_ALL
         *     };
         * 
         *     O_RESULT_DATA = $NP.getUserCenterInfo({
         *         queryParams: P_QUERY_PARAMS
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function getUserCenterInfo(options) {

            return _getDataSet(options, "WC.POP_CSUSERCENTER", $NC.getDisplayMsg("JS.POPUP.020", "해당 사용자에 등록되어 있지 않은 물류센터입니다."));
        }

        /**
         * 사용자 고객사 정보 검색
         * 
         * @param {Object}
         *        options 호출 옵션
         * 
         * <pre>
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * queryParams          [필수]:      {String}        쿼리 파라메터 지정
         * showErrorMessage     [옵션]:      {Boolean}       미지정 또는 true 시 검색 결과가 없을 시 오류 메시지 표시
         * errorMessage         [옵션]:      {String}        오류 메시지, 미지정시 기본 오류메시지
         * </pre>
         * 
         * @returns {Array}
         * @example
         * 
         * <pre>
         * Get:
         *     var P_QUERY_PARAMS = {
         *         P_USER_ID: args.val,
         *         P_CUST_CD: $ND.C_ALL
         *     };
         * 
         *     O_RESULT_DATA = $NP.getUserCenterInfo({
         *         queryParams: P_QUERY_PARAMS
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function getUserCustInfo(options) {

            return _getDataSet(options, "WC.POP_CSUSERCUST", $NC.getDisplayMsg("JS.POPUP.025", "해당 사용자에 등록되어 있지 않은 고객사입니다."));
        }

        /**
         * 사용자정보 검색
         * 
         * @param {Object}
         *        options 호출 옵션
         * 
         * <pre>
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * queryParams          [필수]:      {String}        쿼리 파라메터 지정
         * showErrorMessage     [옵션]:      {Boolean}       미지정 또는 true 시 검색 결과가 없을 시 오류 메시지 표시
         * errorMessage         [옵션]:      {String}        오류 메시지, 미지정시 기본 오류메시지
         * </pre>
         * 
         * @returns {Array}
         * @example
         * 
         * <pre>
         * Get:
         *     var P_QUERY_PARAMS = {
         *         P_USER_ID: args.val,
         *         P_CERTIFY_DIV: $ND.C_ALL
         *     };
         * 
         *     O_RESULT_DATA = $NP.getUserInfo({
         *         queryParams: P_QUERY_PARAMS
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function getUserInfo(options) {

            return _getDataSet(options, "WC.POP_CSUSER", $NC.getDisplayMsg("JS.POPUP.021", "등록되어 있지 않은 사용자입니다."));
        }

        /**
         * 공급처정보 검색
         * 
         * @param {Object}
         *        options 호출 옵션
         * 
         * <pre>
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * queryParams          [필수]:      {String}        쿼리 파라메터 지정
         * showErrorMessage     [옵션]:      {Boolean}       미지정 또는 true 시 검색 결과가 없을 시 오류 메시지 표시
         * errorMessage         [옵션]:      {String}        오류 메시지, 미지정시 기본 오류메시지
         * </pre>
         * 
         * @returns {Array}
         * @example
         * 
         * <pre>
         * Get:
         *     var P_QUERY_PARAMS = {
         *         P_CUST_CD: CUST_CD,
         *         P_VENDOR_CD: args.val,
         *         P_VIEW_DIV: "1"
         *     };
         * 
         *     O_RESULT_DATA = $NP.getVendorInfo({
         *         queryParams: P_QUERY_PARAMS
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function getVendorInfo(options) {

            return _getDataSet(options, "WC.POP_CMVENDOR", $NC.getDisplayMsg("JS.POPUP.022", "등록되어 있지 않은 공급처입니다."));
        }

        /**
         * 존 정보 검색
         * 
         * @param {Object}
         *        options 호출 옵션
         * 
         * <pre>
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * queryParams          [필수]:      {String}        쿼리 파라메터 지정
         * showErrorMessage     [옵션]:      {Boolean}       미지정 또는 true 시 검색 결과가 없을 시 오류 메시지 표시
         * errorMessage         [옵션]:      {String}        오류 메시지, 미지정시 기본 오류메시지
         * </pre>
         * 
         * @returns {Array}
         * @example
         * 
         * <pre>
         * Get:
         *     var P_QUERY_PARAMS = {
         *         P_CENTER_CD: CENTER_CD,
         *         P_ZONE_CD: args.val
         *     };
         * 
         *     O_RESULT_DATA = $NP.getZoneInfo({
         *         queryParams: P_QUERY_PARAMS
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function getZoneInfo(options) {

            return _getDataSet(options, "WC.POP_CMZONE", $NC.getDisplayMsg("JS.POPUP.023", "등록되어 있지 않은 물류센터 존입니다."));
        }

        /**
         * 터미널 정보 검색
         * 
         * @param {Object}
         *        options 호출 옵션
         * 
         * <pre>
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * queryParams          [필수]:      {String}        쿼리 파라메터 지정
         * showErrorMessage     [옵션]:      {Boolean}       미지정 또는 true 시 검색 결과가 없을 시 오류 메시지 표시
         * errorMessage         [옵션]:      {String}        오류 메시지, 미지정시 기본 오류메시지
         * </pre>
         * 
         * @returns {Array}
         * @example
         * 
         * <pre>
         * Get:
         *     var P_QUERY_PARAMS = {
         *         P_TML_CD: args.val,
         *         P_VIEW_DIV: "1"
         *     };
         * 
         *     O_RESULT_DATA = $NP.getTerminalInfo({
         *         queryParams: P_QUERY_PARAMS
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function getTerminalInfo(options) {

            return _getDataSet(options, "WC.POP_CMWBTERMINAL", $NC.getDisplayMsg("JS.POPUP.024", "등록되어 있지 않은 터미널입니다."));
        }

        /**
         * 택배기준(운송사) 정보 검색
         * 
         * @param {Object}
         *        options 호출 옵션
         * 
         * <pre>
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * queryParams          [필수]:      {String}        쿼리 파라메터 지정
         * showErrorMessage     [옵션]:      {Boolean}       미지정 또는 true 시 검색 결과가 없을 시 오류 메시지 표시
         * errorMessage         [옵션]:      {String}        오류 메시지, 미지정시 기본 오류메시지
         * </pre>
         * 
         * @returns {Array}
         * @example
         * 
         * <pre>
         * Get:
         *     var P_QUERY_PARAMS = {
         *         P_CARRIER_CD: args.val,
         *         P_CUST_CD: CUST_CD,
         *         P_ATTR05_CD: "1"
         *     };
         * 
         *     O_RESULT_DATA = $NP.getWbBaseInfo({
         *         queryParams: P_QUERY_PARAMS
         *     });
         * </pre>
         * 
         * @since 7.1.0
         * @memberof $NP#
         */
        function getWbBaseInfo(options) {

            return _getDataSet(options, "WC.POP_CMWBBASE", $NC.getDisplayMsg("JS.POPUP.026", "등록되어 있지 않은 택배사입니다."));
        }

        /**
         * 사업부 계약 수수료 구분 정보 검색
         * 
         * @param {Object}
         *        options 호출 옵션
         * 
         * <pre>
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * queryParams          [필수]:      {String}        쿼리 파라메터 지정
         * showErrorMessage     [옵션]:      {Boolean}       미지정 또는 true 시 검색 결과가 없을 시 오류 메시지 표시
         * errorMessage         [옵션]:      {String}        오류 메시지, 미지정시 기본 오류메시지
         * </pre>
         * 
         * @returns {Array}
         * @example
         * 
         * <pre>
         * Get:
         *     var P_QUERY_PARAMS = {
         *         P_CENTER_CD: CENTER_CD,
         *         P_BU_CD: BU_CD,
         *         P_FEE_GRP: "10",
         *         P_FEE_DIV: args.val,
         *         P_ATTR05_CD: "1"
         *     };
         * 
         *     O_RESULT_DATA = $NP.getBuContractInfo({
         *         queryParams: P_QUERY_PARAMS
         *     });
         * </pre>
         * 
         * @since 7.5.0
         * @memberof $NP#
         */
        function getBuContractInfo(options) {

            return _getDataSet(options, "WC.POP_LFBUCONTRACT", $NC.getDisplayMsg("JS.POPUP.027", "등록되어 있지 않은 수수료구분입니다."));
        }

        /**
         * 계약번호 정보 검색
         * 
         * @param {Object}
         *        options 호출 옵션
         * 
         * <pre>
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * queryParams          [필수]:      {String}        쿼리 파라메터 지정
         * showErrorMessage     [옵션]:      {Boolean}       미지정 또는 true 시 검색 결과가 없을 시 오류 메시지 표시
         * errorMessage         [옵션]:      {String}        오류 메시지, 미지정시 기본 오류메시지
         * </pre>
         * 
         * @returns {Array}
         * @example
         * 
         * <pre>
         * Get:
         *     var P_QUERY_PARAMS = {
         *         P_CONTRACT_NO: args.val,
         *         P_PRICE_DIV: "01",
         *         P_ATTR05_CD: "1"
         *     };
         * 
         *     O_RESULT_DATA = $NP.getContractInfo({
         *         queryParams: P_QUERY_PARAMS
         *     });
         * </pre>
         * 
         * @since 7.5.0
         * @memberof $NP#
         */
        function getContractInfo(options) {

            return _getDataSet(options, "WC.POP_LFCONTRACT", $NC.getDisplayMsg("JS.POPUP.028", "등록되어 있지 않은 계약번호입니다."));
        }

        /**
         * 계약번호, 정산구분 정보 검색
         * 
         * @param {Object}
         *        options 호출 옵션
         * 
         * <pre>
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * queryParams          [필수]:      {String}        쿼리 파라메터 지정
         * showErrorMessage     [옵션]:      {Boolean}       미지정 또는 true 시 검색 결과가 없을 시 오류 메시지 표시
         * errorMessage         [옵션]:      {String}        오류 메시지, 미지정시 기본 오류메시지
         * </pre>
         * 
         * @returns {Array}
         * @example
         * 
         * <pre>
         * Get:
         *     var P_QUERY_PARAMS = {
         *         P_CENTER_CD: $NC.getValue("#cboCenter_Cd"),
         *         P_BU_CD: $NC.getValue("#edtBu_Cd"),
         *         P_CONTRACT_NO: args.val,
         *         P_BILL_DIV: "10",
         *         P_PRICE_DIV: "01",
         *         P_ATTR05_CD: "1"
         *     };
         * 
         *     O_RESULT_DATA = $NP.getContractBillInfo({
         *         queryParams: P_QUERY_PARAMS
         *     });
         * </pre>
         * 
         * @since 7.5.0
         * @memberof $NP#
         */
        function getContractBillInfo(options) {

            return _getDataSet(options, "WC.POP_LFCONTRACTBILL", $NC.getDisplayMsg("JS.POPUP.029", "등록되어 있지 않은 계약번호입니다."));
        }

        /**
         * 정산구분 정보 검색
         * 
         * @param {Object}
         *        options 호출 옵션
         * 
         * <pre>
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * queryParams          [필수]:      {String}        쿼리 파라메터 지정
         * showErrorMessage     [옵션]:      {Boolean}       미지정 또는 true 시 검색 결과가 없을 시 오류 메시지 표시
         * errorMessage         [옵션]:      {String}        오류 메시지, 미지정시 기본 오류메시지
         * </pre>
         * 
         * @returns {Array}
         * @example
         * 
         * <pre>
         * Get:
         *     var P_QUERY_PARAMS = {
         *         P_BILL_DIV: args.val,
         *         P_PRICE_DIV: "01",
         *         P_ATTR05_CD: "1"
         *     };
         * 
         *     O_RESULT_DATA = $NP.getBillInfo({
         *         queryParams: P_QUERY_PARAMS
         *     });
         * </pre>
         * 
         * @since 7.5.0
         * @memberof $NP#
         */
        function getBillInfo(options) {

            return _getDataSet(options, "WC.POP_LFBILL", $NC.getDisplayMsg("JS.POPUP.030", "등록되어 있지 않은 정산구분입니다."));
        }

        /**
         * 포장박스(정산) 정보 검색
         * 
         * @param {Object}
         *        options 호출 옵션
         * 
         * <pre>
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * queryParams          [필수]:      {String}        쿼리 파라메터 지정
         * showErrorMessage     [옵션]:      {Boolean}       미지정 또는 true 시 검색 결과가 없을 시 오류 메시지 표시
         * errorMessage         [옵션]:      {String}        오류 메시지, 미지정시 기본 오류메시지
         * </pre>
         * 
         * @returns {Array}
         * @example
         * 
         * <pre>
         * Get:
         *     var P_QUERY_PARAMS = {
         *         P_CONTRACT_NO: args.val,
         *         P_BILL_DIV: args.val,
         *         P_BU_CD: $ND.C_ALL,
         *         P_BOX_SIZE_CD: args.val,
         *         P_VIEW_DIV: "1"
         *     };
         * 
         *     O_RESULT_DATA = $NP.getBillBoxInfo({
         *         queryParams: P_QUERY_PARAMS
         *     });
         * </pre>
         * 
         * @memberof $NP#
         */
        function getBillBoxInfo(options) {

            return _getDataSet(options, "WC.POP_LFBILLBOX", $NC.getDisplayMsg("JS.POPUP.030", "등록되어 있지 않은 박스코드입니다."));
        }

        /**
         * 브랜드 변경시 호출
         * 
         * @param {String}
         *        value 변경된 값
         * @param {Object}
         *        queryParams 서비스 호출 파라메터
         * @param {Function}
         *        onResult 선택 결과 처리 Callback
         * @param {Object}
         *        options 호출 추가 옵션
         * 
         * <pre>
         * title                [옵션]:      {String}        팝업 창 타이틀
         * columnTitle          [옵션]:      {Array}         컬럼 타이틀, ["코드", "명"], 미지정시 기본 값
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * querySearchParam     [옵션]:      {String}        팝업 창 검색시 검색 값을 입력할 파라메터 명
         * queryCanAll          [옵션]:      {String}        팝업 창 전체 검색 가능 여부
         * showErrorMessage     [옵션]:      {Boolean}       미지정 또는 true 시 검색 결과가 없을 시 오류 메시지 표시
         * errorMessage         [옵션]:      {String}        오류 메시지, 미지정시 기본 오류메시지
         * </pre>
         * 
         * @example
         * 
         * <pre>
         * Call:
         *     // 호출 방법 1(단순 설정)
         *     $NP.onBrandChange(args.val, {
         *         P_BRAND_CD: args.val,
         *         P_VIEW_DIV: "2"
         *     }, onBrandPopup);
         * 
         *     // 호출 방법 2(상세 설정)
         *     $NP.onBrandChange(args.val, {
         *         P_BRAND_CD: args.val,
         *         P_VIEW_DIV: "2"
         *     }, onBrandPopup, {
         *         title: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "브랜드 검색"),
         *         columnTitle: [
         *             $NC.getDisplayName("BRAND_CD", "브랜드코드"),
         *             $NC.getDisplayName("BRAND_NM", "브랜드명"),
         *             $NC.getDisplayName("CUST_NM", "고객사명")
         *         ],
         *         errorMessage: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "등록되어 있지 않은 브랜드입니다.")
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function onBrandChange(value, queryParams, onResult, options) {

            _onValueChange("Brand", value, queryParams, onResult, options);
        }

        /**
         * 사업부브랜드 변경시 호출
         * 
         * @param {String}
         *        value 변경된 값
         * @param {Object}
         *        queryParams 서비스 호출 파라메터
         * @param {Function}
         *        onResult 선택 결과 처리 Callback
         * @param {Object}
         *        options 호출 추가 옵션
         * 
         * <pre>
         * title                [옵션]:      {String}        팝업 창 타이틀
         * columnTitle          [옵션]:      {Array}         컬럼 타이틀, ["코드", "명"], 미지정시 기본 값
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * querySearchParam     [옵션]:      {String}        팝업 창 검색시 검색 값을 입력할 파라메터 명
         * queryCanAll          [옵션]:      {String}        팝업 창 전체 검색 가능 여부
         * showErrorMessage     [옵션]:      {Boolean}       미지정 또는 true 시 검색 결과가 없을 시 오류 메시지 표시
         * errorMessage         [옵션]:      {String}        오류 메시지, 미지정시 기본 오류메시지
         * </pre>
         * 
         * @example
         * 
         * <pre>
         * Call:
         *     // 호출 방법 1(단순 설정)
         *     $NP.onBuBrandChange(args.val, {
         *         P_BU_CD: $NC.getValue("#edtQBu_Cd"),
         *         P_BRAND_CD: args.val
         *     }, onBuBrandPopup);
         * 
         *     // 호출 방법 2(상세 설정)
         *     $NP.onBuBrandChange(args.val, {
         *         P_BU_CD: $NC.getValue("#edtQBu_Cd"),
         *         P_BRAND_CD: args.val
         *     }, onBuBrandPopup, {
         *         title: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "사업부 브랜드 검색"),
         *         columnTitle: [
         *             $NC.getDisplayName("BRAND_CD", "브랜드코드"),
         *             $NC.getDisplayName("BRAND_NM", "브랜드명"),
         *             $NC.getDisplayName("CUST_NM", "고객사명")
         *         ],
         *         errorMessage: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "등록되어 있지 않은 사업부 브랜드입니다.")
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function onBuBrandChange(value, queryParams, onResult, options) {

            _onValueChange("BuBrand", value, queryParams, onResult, options);
        }

        /**
         * 사업부 변경시 호출
         * 
         * @param {String}
         *        value 변경된 값
         * @param {Object}
         *        queryParams 서비스 호출 파라메터
         * @param {Function}
         *        onResult 선택 결과 처리 Callback
         * @param {Object}
         *        options 호출 추가 옵션
         * 
         * <pre>
         * title                [옵션]:      {String}        팝업 창 타이틀
         * columnTitle          [옵션]:      {Array}         컬럼 타이틀, ["코드", "명"], 미지정시 기본 값
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * querySearchParam     [옵션]:      {String}        팝업 창 검색시 검색 값을 입력할 파라메터 명
         * queryCanAll          [옵션]:      {String}        팝업 창 전체 검색 가능 여부
         * showErrorMessage     [옵션]:      {Boolean}       미지정 또는 true 시 검색 결과가 없을 시 오류 메시지 표시
         * errorMessage         [옵션]:      {String}        오류 메시지, 미지정시 기본 오류메시지
         * </pre>
         * 
         * @example
         * 
         * <pre>
         * Call:
         *     // 호출 방법 1(단순 설정)
         *     $NP.onBuChange(args.val, {
         *         P_BU_CD: args.val
         *     }, onBuPopup);
         * 
         *     // 호출 방법 2(상세 설정)
         *     $NP.onBuChange(args.val, {
         *         P_BU_CD: args.val
         *     }, onBuPopup, {
         *         title: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "사업부 검색"),
         *         columnTitle: [
         *             $NC.getDisplayName("BU_CD", "사업부코드"),
         *             $NC.getDisplayName("BU_NM", "사업부명")
         *         ],
         *         errorMessage: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "등록되어 있지 않은 사업부입니다.")
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function onBuChange(value, queryParams, onResult, options) {

            _onValueChange("Bu", value, queryParams, onResult, options);
        }

        /**
         * 차량 변경시 호출
         * 
         * @param {String}
         *        value 변경된 값
         * @param {Object}
         *        queryParams 서비스 호출 파라메터
         * @param {Function}
         *        onResult 선택 결과 처리 Callback
         * @param {Object}
         *        options 호출 추가 옵션
         * 
         * <pre>
         * title                [옵션]:      {String}        팝업 창 타이틀
         * columnTitle          [옵션]:      {Array}         컬럼 타이틀, ["코드", "명"], 미지정시 기본 값
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * querySearchParam     [옵션]:      {String}        팝업 창 검색시 검색 값을 입력할 파라메터 명
         * queryCanAll          [옵션]:      {String}        팝업 창 전체 검색 가능 여부
         * showErrorMessage     [옵션]:      {Boolean}       미지정 또는 true 시 검색 결과가 없을 시 오류 메시지 표시
         * errorMessage         [옵션]:      {String}        오류 메시지, 미지정시 기본 오류메시지
         * </pre>
         * 
         * @example
         * 
         * <pre>
         * Call:
         *     // 호출 방법 1(단순 설정)
         *     $NP.onCarChange(args.val, {
         *         P_CAR_CD: args.val,
         *         P_VIEW_DIV: "1"
         *     }, onCarPopup);
         * 
         *     // 호출 방법 2(상세 설정)
         *     $NP.onCarChange(args.val, {
         *         P_CAR_CD: args.val,
         *         P_VIEW_DIV: "1"
         *     }, onCarPopup, {
         *         title: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "차량 검색"),
         *         columnTitle: [
         *             $NC.getDisplayName("CAR_CD", "차량코드"),
         *             $NC.getDisplayName("CAR_NM", "차량명")
         *         ],
         *         errorMessage: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "등록되어 있지 않은 차량입니다.")
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function onCarChange(value, queryParams, onResult, options) {

            _onValueChange("Car", value, queryParams, onResult, options);
        }

        /**
         * 운송사 변경시 호출
         * 
         * @param {String}
         *        value 변경된 값
         * @param {Object}
         *        queryParams 서비스 호출 파라메터
         * @param {Function}
         *        onResult 선택 결과 처리 Callback
         * @param {Object}
         *        options 호출 추가 옵션
         * 
         * <pre>
         * title                [옵션]:      {String}        팝업 창 타이틀
         * columnTitle          [옵션]:      {Array}         컬럼 타이틀, ["코드", "명"], 미지정시 기본 값
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * querySearchParam     [옵션]:      {String}        팝업 창 검색시 검색 값을 입력할 파라메터 명
         * queryCanAll          [옵션]:      {String}        팝업 창 전체 검색 가능 여부
         * showErrorMessage     [옵션]:      {Boolean}       미지정 또는 true 시 검색 결과가 없을 시 오류 메시지 표시
         * errorMessage         [옵션]:      {String}        오류 메시지, 미지정시 기본 오류메시지
         * </pre>
         * 
         * @example
         * 
         * <pre>
         * Call:
         *     // 호출 방법 1(단순 설정)
         *     $NP.onCarrierChange(args.val, {
         *         P_CARRIER_CD: args.val,
         *         P_CARRIER_DIV: $ND.C_ALL,
         *         P_VIEW_DIV: "1"
         *     }, onCarrierPopup);
         * 
         *     // 호출 방법 2(상세 설정)
         *     $NP.onCarrierChange(args.val, {
         *         P_CARRIER_CD: args.val,
         *         P_CARRIER_DIV: $ND.C_ALL,
         *         P_VIEW_DIV: "1"
         *     }, onCarrierPopup, {
         *         title: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "운송사 검색"),
         *         columnTitle: [
         *             $NC.getDisplayName("CARRIER_CD", "운송사코드"),
         *             $NC.getDisplayName("CARRIER_NM", "운송사명")
         *         ],
         *         errorMessage: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "등록되어 있지 않은 운송사입니다.")
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function onCarrierChange(value, queryParams, onResult, options) {

            _onValueChange("Carrier", value, queryParams, onResult, options);
        }

        /**
         * 물류센터 변경시 호출
         * 
         * @param {String}
         *        value 변경된 값
         * @param {Object}
         *        queryParams 서비스 호출 파라메터
         * @param {Function}
         *        onResult 선택 결과 처리 Callback
         * @param {Object}
         *        options 호출 추가 옵션
         * 
         * <pre>
         * title                [옵션]:      {String}        팝업 창 타이틀
         * columnTitle          [옵션]:      {Array}         컬럼 타이틀, ["코드", "명"], 미지정시 기본 값
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * querySearchParam     [옵션]:      {String}        팝업 창 검색시 검색 값을 입력할 파라메터 명
         * queryCanAll          [옵션]:      {String}        팝업 창 전체 검색 가능 여부
         * showErrorMessage     [옵션]:      {Boolean}       미지정 또는 true 시 검색 결과가 없을 시 오류 메시지 표시
         * errorMessage         [옵션]:      {String}        오류 메시지, 미지정시 기본 오류메시지
         * </pre>
         * 
         * @example
         * 
         * <pre>
         * Call:
         *     // 호출 방법 1(단순 설정)
         *     $NP.onCenterChange(args.val, {
         *         P_CENTER_CD: args.val
         *     }, onCenterPopup);
         * 
         *     // 호출 방법 2(상세 설정)
         *     $NP.onCenterChange(args.val, {
         *         P_CENTER_CD: args.val
         *     }, onCenterPopup, {
         *         title: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "물류센터 검색"),
         *         columnTitle: [
         *             $NC.getDisplayName("CENTER_CD", "물류센터코드"),
         *             $NC.getDisplayName("CENTER_NM", "물류센터명")
         *         ],
         *         errorMessage: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "등록되어 있지 않은 물류센터입니다.")
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function onCenterChange(value, queryParams, onResult, options) {

            _onValueChange("Center", value, queryParams, onResult, options);
        }

        /**
         * 공통코드 변경시 호출
         * 
         * @param {String}
         *        value 변경된 값
         * @param {Object}
         *        queryParams 서비스 호출 파라메터
         * @param {Function}
         *        onResult 선택 결과 처리 Callback
         * @param {Object}
         *        options 호출 추가 옵션
         * 
         * <pre>
         * title                [옵션]:      {String}        팝업 창 타이틀
         * columnTitle          [옵션]:      {Array}         컬럼 타이틀, ["코드", "명"], 미지정시 기본 값
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * querySearchParam     [옵션]:      {String}        팝업 창 검색시 검색 값을 입력할 파라메터 명
         * queryCanAll          [옵션]:      {String}        팝업 창 전체 검색 가능 여부
         * showErrorMessage     [옵션]:      {Boolean}       미지정 또는 true 시 검색 결과가 없을 시 오류 메시지 표시
         * errorMessage         [옵션]:      {String}        오류 메시지, 미지정시 기본 오류메시지
         * </pre>
         * 
         * @example
         * 
         * <pre>
         * Call:
         *     // 호출 방법 1(단순 설정)
         *     $NP.onCodeChange(args.val, {
         *         P_COMMON_GRP: "LI.INBOUND_STATE",
         *         P_COMMON_CD: args.val,
         *         P_VIEW_DIV: "1"
         *     }, onCodePopup);
         * 
         *     // 호출 방법 2(상세 설정)
         *     $NP.onCodeChange(args.val, {
         *         P_COMMON_GRP: "LI.INBOUND_STATE",
         *         P_COMMON_CD: args.val,
         *         P_VIEW_DIV: "1"
         *     }, onCodePopup, {
         *         title: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "공통코드 검색"),
         *         columnTitle: [
         *             $NC.getDisplayName("COMMON_CD", "공통코드"),
         *             $NC.getDisplayName("COMMON_NM", "공통코드명")
         *         ],
         *         errorMessage: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "등록되어 있지 않은 공통코드입니다.")
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function onCodeChange(value, queryParams, onResult, options) {

            _onValueChange("Code", value, queryParams, onResult, options);
        }

        /**
         * 고객사브랜드 변경시 호출
         * 
         * @param {String}
         *        value 변경된 값
         * @param {Object}
         *        queryParams 서비스 호출 파라메터
         * @param {Function}
         *        onResult 선택 결과 처리 Callback
         * @param {Object}
         *        options 호출 추가 옵션
         * 
         * <pre>
         * title                [옵션]:      {String}        팝업 창 타이틀
         * columnTitle          [옵션]:      {Array}         컬럼 타이틀, ["코드", "명"], 미지정시 기본 값
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * querySearchParam     [옵션]:      {String}        팝업 창 검색시 검색 값을 입력할 파라메터 명
         * queryCanAll          [옵션]:      {String}        팝업 창 전체 검색 가능 여부
         * showErrorMessage     [옵션]:      {Boolean}       미지정 또는 true 시 검색 결과가 없을 시 오류 메시지 표시
         * errorMessage         [옵션]:      {String}        오류 메시지, 미지정시 기본 오류메시지
         * </pre>
         * 
         * @example
         * 
         * <pre>
         * Call:
         *     // 호출 방법 1(단순 설정)
         *     $NP.onCustBrandChange(args.val, {
         *         P_CUST_CD: $NC.getValue("#edtQCust_Cd"),
         *         P_BRAND_CD: args.val
         *     }, onCustBrandPopup);
         * 
         *     // 호출 방법 2(상세 설정)
         *     $NP.onCustBrandChange(args.val, {
         *         P_CUST_CD: $NC.getValue("#edtQCust_Cd"),
         *         P_BRAND_CD: args.val
         *     }, onCustBrandPopup, {
         *         title: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "고객사 브랜드 검색"),
         *         columnTitle: [
         *             $NC.getDisplayName("BRAND_CD", "브랜드코드"),
         *             $NC.getDisplayName("BRAND_NM", "브랜드명"),
         *             $NC.getDisplayName("CUST_NM", "고객사명")
         *         ],
         *         errorMessage: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "등록되어 있지 않은 고객사 브랜드입니다.")
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function onCustBrandChange(value, queryParams, onResult, options) {

            _onValueChange("CustBrand", value, queryParams, onResult, options);
        }

        /**
         * 고객사 변경시 호출
         * 
         * @param {String}
         *        value 변경된 값
         * @param {Object}
         *        queryParams 서비스 호출 파라메터
         * @param {Function}
         *        onResult 선택 결과 처리 Callback
         * @param {Object}
         *        options 호출 추가 옵션
         * 
         * <pre>
         * title                [옵션]:      {String}        팝업 창 타이틀
         * columnTitle          [옵션]:      {Array}         컬럼 타이틀, ["코드", "명"], 미지정시 기본 값
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * querySearchParam     [옵션]:      {String}        팝업 창 검색시 검색 값을 입력할 파라메터 명
         * queryCanAll          [옵션]:      {String}        팝업 창 전체 검색 가능 여부
         * showErrorMessage     [옵션]:      {Boolean}       미지정 또는 true 시 검색 결과가 없을 시 오류 메시지 표시
         * errorMessage         [옵션]:      {String}        오류 메시지, 미지정시 기본 오류메시지
         * </pre>
         * 
         * @example
         * 
         * <pre>
         * Call:
         *     // 호출 방법 1(단순 설정)
         *     $NP.onCustChange(args.val, {
         *         P_CUST_CD: args.val
         *     }, onCustPopup);
         * 
         *     // 호출 방법 2(상세 설정)
         *     $NP.onCustChange(args.val, {
         *         P_CUST_CD: args.val
         *     }, onCustPopup, {
         *         title: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "고객사 검색"),
         *         columnTitle: [
         *             $NC.getDisplayName("CUST_CD", "고객사코드"),
         *             $NC.getDisplayName("CUST_NM", "고객사명")
         *         ],
         *         errorMessage: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "등록되어 있지 않은 고객사 고객사입니다.")
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function onCustChange(value, queryParams, onResult, options) {

            _onValueChange("Cust", value, queryParams, onResult, options);
        }

        /**
         * 운송권역 변경시 호출
         * 
         * @param {String}
         *        value 변경된 값
         * @param {Object}
         *        queryParams 서비스 호출 파라메터
         * @param {Function}
         *        onResult 선택 결과 처리 Callback
         * @param {Object}
         *        options 호출 추가 옵션
         * 
         * <pre>
         * title                [옵션]:      {String}        팝업 창 타이틀
         * columnTitle          [옵션]:      {Array}         컬럼 타이틀, ["코드", "명"], 미지정시 기본 값
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * querySearchParam     [옵션]:      {String}        팝업 창 검색시 검색 값을 입력할 파라메터 명
         * queryCanAll          [옵션]:      {String}        팝업 창 전체 검색 가능 여부
         * showErrorMessage     [옵션]:      {Boolean}       미지정 또는 true 시 검색 결과가 없을 시 오류 메시지 표시
         * errorMessage         [옵션]:      {String}        오류 메시지, 미지정시 기본 오류메시지
         * </pre>
         * 
         * @example
         * 
         * <pre>
         * Call:
         *     // 호출 방법 1(단순 설정)
         *     $NP.onDeliveryAreaChange(args.val, {
         *         P_CENTER_CD: $NC.getValue("#cboCenter_Cd"),
         *         P_AREA_CD: args.val
         *     }, onQDeliveryAreaPopup);
         * 
         *     // 호출 방법 2(상세 설정)
         *     $NP.onDeliveryAreaChange(args.val, {
         *         P_CENTER_CD: $NC.getValue("#cboCenter_Cd"),
         *         P_AREA_CD: args.val
         *     }, onDeliveryAreaPopup, {
         *         title: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "운송권역 검색"),
         *         columnTitle: [
         *             $NC.getDisplayName("AREA_CD", "운송권역코드"),
         *             $NC.getDisplayName("AREA_NM", "운송권역명")
         *         ],
         *         errorMessage: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "등록되어 있지 않은 고객사 운송권역입니다.")
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function onDeliveryAreaChange(value, queryParams, onResult, options) {

            _onValueChange("DeliveryArea", value, queryParams, onResult, options);
        }

        /**
         * 배송처 변경시 호출
         * 
         * @param {String}
         *        value 변경된 값
         * @param {Object}
         *        queryParams 서비스 호출 파라메터
         * @param {Function}
         *        onResult 선택 결과 처리 Callback
         * @param {Object}
         *        options 호출 추가 옵션
         * 
         * <pre>
         * title                [옵션]:      {String}        팝업 창 타이틀
         * columnTitle          [옵션]:      {Array}         컬럼 타이틀, ["코드", "명"], 미지정시 기본 값
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * querySearchParam     [옵션]:      {String}        팝업 창 검색시 검색 값을 입력할 파라메터 명
         * queryCanAll          [옵션]:      {String}        팝업 창 전체 검색 가능 여부
         * showErrorMessage     [옵션]:      {Boolean}       미지정 또는 true 시 검색 결과가 없을 시 오류 메시지 표시
         * errorMessage         [옵션]:      {String}        오류 메시지, 미지정시 기본 오류메시지
         * </pre>
         * 
         * @example
         * 
         * <pre>
         * Call:
         *     // 호출 방법 1(단순 설정)
         *     $NP.onDeliveryChange(args.val, {
         *         P_CUST_CD: $NC.getValue("#edtCust_Cd"),
         *         P_DELIVERY_CD: args.val,
         *         P_DELIVERY_DIV: $ND.C_ALL,
         *         P_VIEW_DIV: "1"
         *     }, onDeliveryPopup);
         * 
         *     // 호출 방법 2(상세 설정)
         *     $NP.onDeliveryChange(args.val, {
         *         P_CUST_CD: $NC.getValue("#edtCust_Cd"),
         *         P_DELIVERY_CD: args.val,
         *         P_DELIVERY_DIV: "92", // 92 - 온라인몰
         *         P_VIEW_DIV: "1"
         *     }, onDeliveryPopup, {
         *         title: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "온라인몰 검색"),
         *         columnTitle: [
         *             $NC.getDisplayName("DELIVERY_CD", "온라인몰코드"),
         *             $NC.getDisplayName("DELIVERY_NM", "온라인몰명")
         *         ],
         *         errorMessage: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "등록되어 있지 않은 온라인몰입니다.")
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function onDeliveryChange(value, queryParams, onResult, options) {

            _onValueChange("Delivery", value, queryParams, onResult, options);
        }

        /**
         * 부서 변경시 호출
         * 
         * @param {String}
         *        value 변경된 값
         * @param {Object}
         *        queryParams 서비스 호출 파라메터
         * @param {Function}
         *        onResult 선택 결과 처리 Callback
         * @param {Object}
         *        options 호출 추가 옵션
         * 
         * <pre>
         * title                [옵션]:      {String}        팝업 창 타이틀
         * columnTitle          [옵션]:      {Array}         컬럼 타이틀, ["코드", "명"], 미지정시 기본 값
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * querySearchParam     [옵션]:      {String}        팝업 창 검색시 검색 값을 입력할 파라메터 명
         * queryCanAll          [옵션]:      {String}        팝업 창 전체 검색 가능 여부
         * showErrorMessage     [옵션]:      {Boolean}       미지정 또는 true 시 검색 결과가 없을 시 오류 메시지 표시
         * errorMessage         [옵션]:      {String}        오류 메시지, 미지정시 기본 오류메시지
         * </pre>
         * 
         * @example
         * 
         * <pre>
         * Call:
         *     // 호출 방법 1(단순 설정)
         *     $NP.onDeptChange(args.val, {
         *         P_CUST_CD: CUST_CD,
         *         P_DEPT_CD: args.val,
         *         P_VIEW_DIV: "2"
         *     }, onDeptPopup);
         * 
         *     // 호출 방법 2(상세 설정)
         *     $NP.onDeptChange(args.val, {
         *         P_CUST_CD: CUST_CD,
         *         P_DEPT_CD: args.val,
         *         P_VIEW_DIV: "2"
         *     }, onDeptPopup, {
         *         title: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "부서 검색"),
         *         columnTitle: [
         *             $NC.getDisplayName("DEPT_CD", "부서코드"),
         *             $NC.getDisplayName("DEPT_NM", "부서명")
         *         ],
         *         errorMessage: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "등록되어 있지 않은 부서입니다.")
         *     });
         * </pre>
         * 
         * @since 7.0.0
         * @memberof $NP#
         */
        function onDeptChange(value, queryParams, onResult, options) {

            _onValueChange("Dept", value, queryParams, onResult, options);
        }

        /**
         * 상품 변경시 호출
         * 
         * @param {String}
         *        value 변경된 값
         * @param {Object}
         *        queryParams 서비스 호출 파라메터
         * @param {Function}
         *        onResult 선택 결과 처리 Callback
         * @param {Object}
         *        options 호출 추가 옵션
         * 
         * <pre>
         * title                [옵션]:      {String}        팝업 창 타이틀
         * columnTitle          [옵션]:      {Array}         컬럼 타이틀, ["코드", "명"], 미지정시 기본 값
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * querySearchParam     [옵션]:      {String}        팝업 창 검색시 검색 값을 입력할 파라메터 명
         * queryCanAll          [옵션]:      {String}        팝업 창 전체 검색 가능 여부
         * showErrorMessage     [옵션]:      {Boolean}       미지정 또는 true 시 검색 결과가 없을 시 오류 메시지 표시
         * errorMessage         [옵션]:      {String}        오류 메시지, 미지정시 기본 오류메시지
         * </pre>
         * 
         * @example
         * 
         * <pre>
         * Call:
         *     // 호출 방법 1(단순 설정)
         *     $NP.onItemChange(args.val, {
         *         P_BU_CD: $NC.getValue("#edtBu_Cd"),
         *         P_BRAND_CD: $NC.getValue("#edtBrand_Cd"),
         *         P_ITEM_CD: args.val,
         *         P_VIEW_DIV: "2",
         *         P_DEPART_CD: $ND.C_ALL,
         *         P_LINE_CD: $ND.C_ALL,
         *         P_CLASS_CD: $ND.C_ALL
         *     }, onItemPopup);
         * 
         *     // 호출 방법 2(상세 설정)
         *     $NP.onItemChange()(args.val, {
         *         P_BU_CD: $NC.getValue("#edtBu_Cd"),
         *         P_BRAND_CD: $NC.getValue("#edtBrand_Cd"),
         *         P_ITEM_CD: args.val,
         *         P_VIEW_DIV: "2",
         *         P_DEPART_CD: $ND.C_ALL,
         *         P_LINE_CD: $ND.C_ALL,
         *         P_CLASS_CD: $ND.C_ALL
         *     }, onItemPopup, {
         *         title: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "상품 검색"),
         *         columnTitle: [
         *             $NC.getDisplayName("ITEM_CD", "상품코드"),
         *             $NC.getDisplayName("ITEM_BARCD", "상품바코드"),
         *             $NC.getDisplayName("ITEM_NM", "상품명"),
         *             $NC.getDisplayName("ITEM_SPEC", "규격"),
         *             $NC.getDisplayName("BRAND_CD", "브랜드명")
         *         ],
         *         errorMessage: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "등록되어 있지 않은 상품입니다.")
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function onItemChange(value, queryParams, onResult, options) {

            _onValueChange("Item", value, queryParams, onResult, options);
        }

        /**
         * LOT번호 변경시 호출
         * 
         * @param {String}
         *        value 변경된 값
         * @param {Object}
         *        queryParams 서비스 호출 파라메터
         * @param {Function}
         *        onResult 선택 결과 처리 Callback
         * @param {Object}
         *        options 호출 추가 옵션
         * 
         * <pre>
         * title                [옵션]:      {String}        팝업 창 타이틀
         * columnTitle          [옵션]:      {Array}         컬럼 타이틀, ["코드", "명"], 미지정시 기본 값
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * querySearchParam     [옵션]:      {String}        팝업 창 검색시 검색 값을 입력할 파라메터 명
         * queryCanAll          [옵션]:      {String}        팝업 창 전체 검색 가능 여부
         * showErrorMessage     [옵션]:      {Boolean}       미지정 또는 true 시 검색 결과가 없을 시 오류 메시지 표시
         * errorMessage         [옵션]:      {String}        오류 메시지, 미지정시 기본 오류메시지
         * </pre>
         * 
         * @example
         * 
         * <pre>
         * Call:
         *     // 호출 방법 1(단순 설정)
         *     $NP.onItemLotChange(args.val, {
         *         P_CENTER_CD: CENTER_CD,
         *         P_BU_CD: BU_CD,
         *         P_BRAND_CD: BRAND_CD,
         *         P_ITEM_CD: ITEM_CD,
         *         P_ITEM_STATE: ITEM_STATE,
         *         P_ITEM_LOT: args.val
         *     }, onItemLotPopup);
         * 
         *     // 호출 방법 2(상세 설정)
         *     $NP.onItemLotChange(args.val, {
         *         P_CENTER_CD: CENTER_CD,
         *         P_BU_CD: BU_CD,
         *         P_BRAND_CD: BRAND_CD,
         *         P_ITEM_CD: ITEM_CD,
         *         P_ITEM_STATE: ITEM_STATE,
         *         P_ITEM_LOT: args.val
         *     }, onItemLotPopup, {
         *         title: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "재고 LOT번호 검색"),
         *         columnTitle: [
         *             $NC.getDisplayName("ITEM_CD", "LOT번호"),
         *             $NC.getDisplayName("STOCK_QTY", "재고수량"),
         *             $NC.getDisplayName("PSTOCK_QTY", "가용재고")
         *         ],
         *         errorMessage: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "등록되어 있지 않은 재고 LOT번호입니다.")
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function onItemLotChange(value, queryParams, onResult, options) {

            _onValueChange("ItemLot", value, queryParams, onResult, options);
        }

        /**
         * 로케이션 변경시 호출
         * 
         * @param {String}
         *        value 변경된 값
         * @param {Object}
         *        queryParams 서비스 호출 파라메터
         * @param {Function}
         *        onResult 선택 결과 처리 Callback
         * @param {Object}
         *        options 호출 추가 옵션
         * 
         * <pre>
         * title                [옵션]:      {String}        팝업 창 타이틀
         * columnTitle          [옵션]:      {Array}         컬럼 타이틀, ["코드", "명"], 미지정시 기본 값
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * querySearchParam     [옵션]:      {String}        팝업 창 검색시 검색 값을 입력할 파라메터 명
         * queryCanAll          [옵션]:      {String}        팝업 창 전체 검색 가능 여부
         * showErrorMessage     [옵션]:      {Boolean}       미지정 또는 true 시 검색 결과가 없을 시 오류 메시지 표시
         * errorMessage         [옵션]:      {String}        오류 메시지, 미지정시 기본 오류메시지
         * </pre>
         * 
         * @example
         * 
         * <pre>
         * Call:
         *     // 호출 방법 1 (단순 설정)
         *     $NP.onLocationChange(args.val, {
         *         P_CENTER_CD: CENTER_CD,
         *         P_ZONE_CD: "",
         *         P_BANK_CD: "",
         *         P_BAY_CD: "",
         *         P_LEV_CD: "",
         *         P_LOCATION_CD: args.val,
         *         P_ZONE_DIV_ATTR01_CD: "1", // 존구분 특성01(존특성), 1 - 일반, 2- 유통가공, 3 - 보세
         *         P_INOUT_DIV: "1", // 1 - 입고(적치), 2 - 출고, NULL - 전체, 필수
         *         P_LOC_DIV_ATTR03_CD: "", // 로케이션구분 특성03(셀특성), 센터운영화면(필수)
         *         P_POLICY_VAL: "" // 입고(적치)/출고불가능 로케이션 사용 정책(입고 - LC410, 출고 - LC411), 기타입출고화면(필수)
         *     }, onLocationPopup);
         * 
         *     // 호출 방법 1 - 1 (입고(적치))
         *     $NP.onLocationChange(args.val, {
         *         P_CENTER_CD: CENTER_CD,
         *         P_ZONE_CD: "",
         *         P_BANK_CD: "",
         *         P_BAY_CD: "",
         *         P_LEV_CD: "",
         *         P_LOCATION_CD: args.val,
         *         P_ZONE_DIV_ATTR01_CD: "1", // 존구분 특성01(존특성), 1 - 일반, 2- 유통가공, 3 - 보세
         *         P_INOUT_DIV: "1" // 1 - 입고(적치), 2 - 출고, NULL - 전체, 필수
         *     }, onLocationPopup);
         * 
         *     // 호출 방법 1 - 2 (출고)
         *     $NP.onLocationChange(args.val, {
         *         P_CENTER_CD: CENTER_CD,
         *         P_ZONE_CD: "",
         *         P_BANK_CD: "",
         *         P_BAY_CD: "",
         *         P_LEV_CD: "",
         *         P_LOCATION_CD: args.val,
         *         P_ZONE_DIV_ATTR01_CD: "1", // 존구분 특성01(존특성), 1 - 일반, 2- 유통가공, 3 - 보세
         *         P_INOUT_DIV: "2" // 1 - 입고(적치), 2 - 출고, NULL - 전체, 필수
         *     }, onLocationPopup);
         * 
         *     // 호출 방법 2(상세 설정)
         *     $NP.onLocationChange(args.val, {
         *         P_CENTER_CD: CENTER_CD,
         *         P_ZONE_CD: "",
         *         P_BANK_CD: "",
         *         P_BAY_CD: "",
         *         P_LEV_CD: "",
         *         P_LOCATION_CD: args.val,
         *         P_ZONE_DIV_ATTR01_CD: "1", // 존구분 특성01(존특성), 1 - 일반, 2- 유통가공, 3 - 보세
         *         P_INOUT_DIV: "1", // 1 - 입고(적치), 2 - 출고, NULL - 전체, 필수
         *         P_LOC_DIV_ATTR03_CD: "", // 로케이션구분 특성03(셀특성), 센터운영화면(필수)
         *         P_POLICY_VAL: "", // 입고(적치)/출고불가능 로케이션 사용 정책(입고 - LC410, 출고 - LC411), 기타입출고화면(필수)
         *     }, onLocationPopup, {
         *         title: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "로케이션 검색"),
         *         columnTitle: [
         *             $NC.getDisplayName("ZONE_CD", "존코드"),
         *             $NC.getDisplayName("ZONE_NM", "존명"),
         *             $NC.getDisplayName("LOCATION_CD", "로케이션")
         *         ],
         *         errorMessage: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "등록되어 있지 않은 로케이션입니다.")
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function onLocationChange(value, queryParams, onResult, options) {

            _onValueChange("Location", value, queryParams, onResult, options);
        }

        /**
         * 자재 변경시 호출
         * 
         * @param {String}
         *        value 변경된 값
         * @param {Object}
         *        queryParams 서비스 호출 파라메터
         * @param {Function}
         *        onResult 선택 결과 처리 Callback
         * @param {Object}
         *        options 호출 추가 옵션
         * 
         * <pre>
         * title                [옵션]:      {String}        팝업 창 타이틀
         * columnTitle          [옵션]:      {Array}         컬럼 타이틀, ["코드", "명"], 미지정시 기본 값
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * querySearchParam     [옵션]:      {String}        팝업 창 검색시 검색 값을 입력할 파라메터 명
         * queryCanAll          [옵션]:      {String}        팝업 창 전체 검색 가능 여부
         * showErrorMessage     [옵션]:      {Boolean}       미지정 또는 true 시 검색 결과가 없을 시 오류 메시지 표시
         * errorMessage         [옵션]:      {String}        오류 메시지, 미지정시 기본 오류메시지
         * </pre>
         * 
         * @example
         * 
         * <pre>
         * Call:
         *     // 호출 방법 1(단순 설정)
         *     $NP.onMaterialChange(args.val, {
         *         P_CUST_CD: CUST_CD,
         *         P_MATERIAL_CD: args.val
         *     }, onMaterialPopup);
         * 
         *     // 호출 방법 2(상세 설정)
         *     $NP.onMaterialChange(args.val, {
         *         P_CUST_CD: CUST_CD,
         *         P_MATERIAL_CD: args.val
         *     }, onMaterialPopup, {
         *         title: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "자재 검색"),
         *         columnTitle: [
         *             $NC.getDisplayName("MATERIAL_CD", "자재코드"),
         *             $NC.getDisplayName("MATERIAL_NM", "자재명"),
         *             $NC.getDisplayName("PROCESSING_DIV_D", "가공작업구분"),
         *             $NC.getDisplayName("CUST_NM", "고객사명")
         *         ],
         *         errorMessage: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "등록되어 있지 않은 로케이션입니다.")
         *     });
         * </pre>
         * 
         * @since 7.5.0
         * @memberof $NP#
         */
        function onMaterialChange(value, queryParams, onResult, options) {

            _onValueChange("Material", value, queryParams, onResult, options);
        }

        /**
         * 조직 변경시 호출
         * 
         * @param {String}
         *        value 변경된 값
         * @param {Object}
         *        queryParams 서비스 호출 파라메터
         * @param {Function}
         *        onResult 선택 결과 처리 Callback
         * @param {Object}
         *        options 호출 추가 옵션
         * 
         * <pre>
         * title                [옵션]:      {String}        팝업 창 타이틀
         * columnTitle          [옵션]:      {Array}         컬럼 타이틀, ["코드", "명"], 미지정시 기본 값
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * querySearchParam     [옵션]:      {String}        팝업 창 검색시 검색 값을 입력할 파라메터 명
         * queryCanAll          [옵션]:      {String}        팝업 창 전체 검색 가능 여부
         * showErrorMessage     [옵션]:      {Boolean}       미지정 또는 true 시 검색 결과가 없을 시 오류 메시지 표시
         * errorMessage         [옵션]:      {String}        오류 메시지, 미지정시 기본 오류메시지
         * </pre>
         * 
         * @example
         * 
         * <pre>
         * Call:
         *     // 호출 방법 1(단순 설정)
         *     $NP.onOrgnChange(args.val, {
         *         P_ORGN_DIV:  "1", // 1-조직, 2-서비스
         *         P_ORGN_CD: args.val,
         *         P_VIEW_DIV: "2"
         *     }, onOrgnPopup);
         * 
         *     // 호출 방법 2(상세 설정)
         *     $NP.onOrgnChange(args.val, {
         *         P_ORGN_DIV:  "1", // 1-조직, 2-서비스
         *         P_ORGN_CD: args.val,
         *         P_VIEW_DIV: "2"
         *     }, onOrgnPopup, {
         *         title: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "조직 검색"),
         *         columnTitle: [
         *             $NC.getDisplayName("ORGN_CD", "조직코드"),
         *             $NC.getDisplayName("ORGN_NM", "조직명")
         *         ],
         *         errorMessage: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "등록되어 있지 않은 조직입니다.")
         *     });
         * </pre>
         * 
         * @since 7.1.0
         * @memberof $NP#
         */
        function onOrgnChange(value, queryParams, onResult, options) {

            _onValueChange("Orgn", value, queryParams, onResult, options);
        }

        /**
         * 우편번호 변경시 호출
         * 
         * @param {String}
         *        value 변경된 값
         * @param {Object}
         *        queryParams 서비스 호출 파라메터
         * @param {Function}
         *        onResult 선택 결과 처리 Callback
         * @param {Object}
         *        options 호출 추가 옵션
         * 
         * <pre>
         * title                [옵션]:      {String}        팝업 창 타이틀
         * columnTitle          [옵션]:      {Array}         컬럼 타이틀, ["코드", "명"], 미지정시 기본 값
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * querySearchParam     [옵션]:      {String}        팝업 창 검색시 검색 값을 입력할 파라메터 명
         * queryCanAll          [옵션]:      {String}        팝업 창 전체 검색 가능 여부
         * showErrorMessage     [옵션]:      {Boolean}       미지정 또는 true 시 검색 결과가 없을 시 오류 메시지 표시
         * errorMessage         [옵션]:      {String}        오류 메시지, 미지정시 기본 오류메시지
         * </pre>
         * 
         * @example
         * 
         * <pre>
         * Call:
         *     // 호출 방법 1(단순 설정)
         *     $NP.onPostChange(args.val, {
         *         P_ADDR_NM: args.val
         *     }, onPostPopup);
         * 
         *     // 호출 방법 2(상세 설정)
         *     $NP.onPostChange(args.val, {
         *         P_ADDR_NM: args.val
         *     }, onPostPopup, {
         *         title: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "우편번호 검색"),
         *         columnTitle: [
         *             $NC.getDisplayName("ZIP_CD", "우편번호"),
         *             $NC.getDisplayName("ADDR_NM", "주소")
         *         ],
         *         errorMessage: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "등록되어 있지 않은 우편번호입니다.")
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function onPostChange(value, queryParams, onResult, options) {

            _onValueChange("Post", value, queryParams, onResult, options);
        }

        /**
         * 관련사 변경시 호출
         * 
         * @param {String}
         *        value 변경된 값
         * @param {Object}
         *        queryParams 서비스 호출 파라메터
         * @param {Function}
         *        onResult 선택 결과 처리 Callback
         * @param {Object}
         *        options 호출 추가 옵션
         * 
         * <pre>
         * title                [옵션]:      {String}        팝업 창 타이틀
         * columnTitle          [옵션]:      {Array}         컬럼 타이틀, ["코드", "명"], 미지정시 기본 값
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * querySearchParam     [옵션]:      {String}        팝업 창 검색시 검색 값을 입력할 파라메터 명
         * queryCanAll          [옵션]:      {String}        팝업 창 전체 검색 가능 여부
         * showErrorMessage     [옵션]:      {Boolean}       미지정 또는 true 시 검색 결과가 없을 시 오류 메시지 표시
         * errorMessage         [옵션]:      {String}        오류 메시지, 미지정시 기본 오류메시지
         * </pre>
         * 
         * @example
         * 
         * <pre>
         * Call:
         *     // 호출 방법 1(단순 설정)
         *     $NP.onReferenceChange(args.val, {
         *         P_REF_CUST_CD: args.val,
         *         P_REF_CUST_DIV: $ND.C_ALL,
         *         P_VIEW_DIV: "2"
         *     }, onReferencePopup);
         * 
         *     // 호출 방법 2(상세 설정)
         *     $NP.onReferenceChange(args.val, {
         *         P_REF_CUST_CD: args.val,
         *         P_REF_CUST_DIV: "2", // 제약사
         *         P_VIEW_DIV: "2"
         *     }, onReferencePopup, {
         *         title: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "제약사 검색"),
         *         columnTitle: [
         *             $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "제약사코드"),
         *             $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "제약사명")
         *         ],
         *         errorMessage: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "등록되어 있지 않은 제약사입니다.")
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function onReferenceChange(value, queryParams, onResult, options) {

            _onValueChange("Reference", value, queryParams, onResult, options);
        }

        /**
         * 터미널 변경시 호출
         * 
         * @param {String}
         *        value 변경된 값
         * @param {Object}
         *        queryParams 서비스 호출 파라메터
         * @param {Function}
         *        onResult 선택 결과 처리 Callback
         * @param {Object}
         *        options 호출 추가 옵션
         * 
         * <pre>
         * title                [옵션]:      {String}        팝업 창 타이틀
         * columnTitle          [옵션]:      {Array}         컬럼 타이틀, ["코드", "명"], 미지정시 기본 값
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * querySearchParam     [옵션]:      {String}        팝업 창 검색시 검색 값을 입력할 파라메터 명
         * queryCanAll          [옵션]:      {String}        팝업 창 전체 검색 가능 여부
         * showErrorMessage     [옵션]:      {Boolean}       미지정 또는 true 시 검색 결과가 없을 시 오류 메시지 표시
         * errorMessage         [옵션]:      {String}        오류 메시지, 미지정시 기본 오류메시지
         * </pre>
         * 
         * @example
         * 
         * <pre>
         * Call:
         *     // 호출 방법 1(단순 설정)
         *     $NP.onTerminalChange(args.val, {
         *         P_TML_CD: args.val,
         *         P_VIEW_DIV: "1"
         *     }, onTerminalPopup);
         * 
         *     // 호출 방법 2(상세 설정)
         *     $NP.onTerminalChange(args.val, {
         *         P_TML_CD: args.val,
         *         P_VIEW_DIV: "1"
         *     }, onTerminalPopup, {
         *         title: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "터미널 검색"),
         *         columnTitle: [
         *             $NC.getDisplayName("TML_CD", "터미널코드"),
         *             $NC.getDisplayName("TML_NM", "터미널명")
         *         ],
         *         errorMessage: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "등록되어 있지 않은 터미널입니다.")
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function onTerminalChange(value, queryParams, onResult, options) {

            _onValueChange("Terminal", value, queryParams, onResult, options);
        }

        /**
         * 사용자브랜드 변경시 호출
         * 
         * @param {String}
         *        value 변경된 값
         * @param {Object}
         *        queryParams 서비스 호출 파라메터
         * @param {Function}
         *        onResult 선택 결과 처리 Callback
         * @param {Object}
         *        options 호출 추가 옵션
         * 
         * <pre>
         * title                [옵션]:      {String}        팝업 창 타이틀
         * columnTitle          [옵션]:      {Array}         컬럼 타이틀, ["코드", "명"], 미지정시 기본 값
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * querySearchParam     [옵션]:      {String}        팝업 창 검색시 검색 값을 입력할 파라메터 명
         * queryCanAll          [옵션]:      {String}        팝업 창 전체 검색 가능 여부
         * showErrorMessage     [옵션]:      {Boolean}       미지정 또는 true 시 검색 결과가 없을 시 오류 메시지 표시
         * errorMessage         [옵션]:      {String}        오류 메시지, 미지정시 기본 오류메시지
         * </pre>
         * 
         * @example
         * 
         * <pre>
         * Call:
         *     // 호출 방법 1(단순 설정)
         *     $NP.onUserBrandChange(args.val, {
         *         P_USER_ID: $NC.G_USERINFO.USER_ID,
         *         P_BRAND_CD: args.val
         *     }, onUserBrandPopup);
         * 
         *     // 호출 방법 2(상세 설정)
         *     $NP.onUserBrandChange(args.val, {
         *         P_USER_ID: $NC.G_USERINFO.USER_ID,
         *         P_BRAND_CD: args.val
         *     }, onUserBrandPopup, {
         *         title: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "사용자 브랜드 검색"),
         *         columnTitle: [
         *             $NC.getDisplayName("BRAND_CD", "브랜드코드"),
         *             $NC.getDisplayName("BRAND_NM", "브랜드명"),
         *             $NC.getDisplayName("CUST_NM", "고객사명")
         *         ],
         *         errorMessage: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "등록되어 있지 않은 사용자 브랜드입니다.")
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function onUserBrandChange(value, queryParams, onResult, options) {

            _onValueChange("UserBrand", value, queryParams, onResult, options);
        }

        /**
         * 사용자사업부 변경시 호출
         * 
         * @param {String}
         *        value 변경된 값
         * @param {Object}
         *        queryParams 서비스 호출 파라메터
         * @param {Function}
         *        onResult 선택 결과 처리 Callback
         * @param {Object}
         *        options 호출 추가 옵션
         * 
         * <pre>
         * title                [옵션]:      {String}        팝업 창 타이틀
         * columnTitle          [옵션]:      {Array}         컬럼 타이틀, ["코드", "명"], 미지정시 기본 값
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * querySearchParam     [옵션]:      {String}        팝업 창 검색시 검색 값을 입력할 파라메터 명
         * queryCanAll          [옵션]:      {String}        팝업 창 전체 검색 가능 여부
         * showErrorMessage     [옵션]:      {Boolean}       미지정 또는 true 시 검색 결과가 없을 시 오류 메시지 표시
         * errorMessage         [옵션]:      {String}        오류 메시지, 미지정시 기본 오류메시지
         * </pre>
         * 
         * @example
         * 
         * <pre>
         * Call:
         *     // 호출 방법 1(단순 설정)
         *     $NP.onUserBuChange(args.val, {
         *         P_USER_ID: $NC.G_USERINFO.USER_ID,
         *         P_BU_CD: args.val,
         *         P_CUST_CD: $ND.C_ALL
         *     }, onUserBuPopup);
         * 
         *     // 호출 방법 2(상세 설정)
         *     $NP.onUserBuChange(args.val, {
         *         P_USER_ID: $NC.G_USERINFO.USER_ID,
         *         P_BU_CD: args.val,
         *         P_CUST_CD: $ND.C_ALL
         *     }, onUserBuPopup, {
         *         title: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "사용자 사업부 검색"),
         *         columnTitle: [
         *             $NC.getDisplayName("BU_CD", "사업부코드"),
         *             $NC.getDisplayName("BU_NM", "사업부명")
         *         ],
         *         errorMessage: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "등록되어 있지 않은 사용자 사업부입니다.")
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function onUserBuChange(value, queryParams, onResult, options) {

            _onValueChange("UserBu", value, queryParams, onResult, options);
        }

        /**
         * 사용자물류센터 변경시 호출
         * 
         * @param {String}
         *        value 변경된 값
         * @param {Object}
         *        queryParams 서비스 호출 파라메터
         * @param {Function}
         *        onResult 선택 결과 처리 Callback
         * @param {Object}
         *        options 호출 추가 옵션
         * 
         * <pre>
         * title                [옵션]:      {String}        팝업 창 타이틀
         * columnTitle          [옵션]:      {Array}         컬럼 타이틀, ["코드", "명"], 미지정시 기본 값
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * querySearchParam     [옵션]:      {String}        팝업 창 검색시 검색 값을 입력할 파라메터 명
         * queryCanAll          [옵션]:      {String}        팝업 창 전체 검색 가능 여부
         * showErrorMessage     [옵션]:      {Boolean}       미지정 또는 true 시 검색 결과가 없을 시 오류 메시지 표시
         * errorMessage         [옵션]:      {String}        오류 메시지, 미지정시 기본 오류메시지
         * </pre>
         * 
         * @example
         * 
         * <pre>
         * Call:
         *     // 호출 방법 1(단순 설정)
         *     $NP.onUserCenterChange(args.val, {
         *         P_USER_ID: $NC.G_USERINFO.USER_ID,
         *         P_CENTER_CD: args.val
         *     }, onUserCenterPopup);
         * 
         *     // 호출 방법 2(상세 설정)
         *     $NP.onUserCenterChange(args.val, {
         *         P_USER_ID: $NC.G_USERINFO.USER_ID,
         *         P_CENTER_CD: args.val
         *     }, onUserCenterPopup, {
         *         title: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "사용자 물류센터 검색"),
         *         columnTitle: [
         *             $NC.getDisplayName("CENTER_CD", "물류센터코드"),
         *             $NC.getDisplayName("CENTER_NM", "물류센터명")
         *         ],
         *         errorMessage: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "등록되어 있지 않은 사용자 물류센터입니다.")
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function onUserCenterChange(value, queryParams, onResult, options) {

            _onValueChange("UserCenter", value, queryParams, onResult, options);
        }

        /**
         * 사용자고객사 변경시 호출
         * 
         * @param {String}
         *        value 변경된 값
         * @param {Object}
         *        queryParams 서비스 호출 파라메터
         * @param {Function}
         *        onResult 선택 결과 처리 Callback
         * @param {Object}
         *        options 호출 추가 옵션
         * 
         * <pre>
         * title                [옵션]:      {String}        팝업 창 타이틀
         * columnTitle          [옵션]:      {Array}         컬럼 타이틀, ["코드", "명"], 미지정시 기본 값
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * querySearchParam     [옵션]:      {String}        팝업 창 검색시 검색 값을 입력할 파라메터 명
         * queryCanAll          [옵션]:      {String}        팝업 창 전체 검색 가능 여부
         * showErrorMessage     [옵션]:      {Boolean}       미지정 또는 true 시 검색 결과가 없을 시 오류 메시지 표시
         * errorMessage         [옵션]:      {String}        오류 메시지, 미지정시 기본 오류메시지
         * </pre>
         * 
         * @example
         * 
         * <pre>
         * Call:
         *     // 호출 방법 1(단순 설정)
         *     $NP.onUserCustChange(args.val, {
         *         P_USER_ID: $NC.G_USERINFO.USER_ID,
         *         P_CUST_CD: args.val
         *     }, onUserCustPopup);
         * 
         *     // 호출 방법 2(상세 설정)
         *     $NP.onUserCustChange(args.val, {
         *         P_USER_ID: $NC.G_USERINFO.USER_ID,
         *         P_CUST_CD: args.val
         *     }, onUserCustPopup, {
         *         title: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "사용자 고객사 검색"),
         *         columnTitle: [
         *             $NC.getDisplayName("CUST_CD", "고객사코드"),
         *             $NC.getDisplayName("CUST_NM", "고객사명")
         *         ],
         *         errorMessage: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "등록되어 있지 않은 사용자 고객사입니다.")
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function onUserCustChange(value, queryParams, onResult, options) {

            _onValueChange("UserCust", value, queryParams, onResult, options);
        }

        /**
         * 사용자ID 변경시 호출
         * 
         * @param {String}
         *        value 변경된 값
         * @param {Object}
         *        queryParams 서비스 호출 파라메터
         * @param {Function}
         *        onResult 선택 결과 처리 Callback
         * @param {Object}
         *        options 호출 추가 옵션
         * 
         * <pre>
         * title                [옵션]:      {String}        팝업 창 타이틀
         * columnTitle          [옵션]:      {Array}         컬럼 타이틀, ["코드", "명"], 미지정시 기본 값
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * querySearchParam     [옵션]:      {String}        팝업 창 검색시 검색 값을 입력할 파라메터 명
         * queryCanAll          [옵션]:      {String}        팝업 창 전체 검색 가능 여부
         * showErrorMessage     [옵션]:      {Boolean}       미지정 또는 true 시 검색 결과가 없을 시 오류 메시지 표시
         * errorMessage         [옵션]:      {String}        오류 메시지, 미지정시 기본 오류메시지
         * </pre>
         * 
         * @example
         * 
         * <pre>
         * Call:
         *     // 호출 방법 1(단순 설정)
         *     $NP.onUserChange(args.val, {
         *         P_USER_ID: args.val,
         *         P_CERTIFY_DIV: $ND.C_ALL
         *     }, onUserPopup);
         * 
         *     // 호출 방법 2(상세 설정)
         *     $NP.onUserChange(args.val, {
         *         P_USER_ID: args.val,
         *         P_CERTIFY_DIV: $ND.C_ALL
         *     }, onUserPopup, {
         *         title: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "사용자 검색"),
         *         columnTitle: [
         *             $NC.getDisplayName("USER_ID", "사용자ID"),
         *             $NC.getDisplayName("USER_NM", "사용자명")
         *         ],
         *         errorMessage: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "등록되어 있지 않은 사용자입니다.")
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function onUserChange(value, queryParams, onResult, options) {

            _onValueChange("User", value, queryParams, onResult, options);
        }

        /**
         * 공급처 변경시 호출
         * 
         * @param {String}
         *        value 변경된 값
         * @param {Object}
         *        queryParams 서비스 호출 파라메터
         * @param {Function}
         *        onResult 선택 결과 처리 Callback
         * @param {Object}
         *        options 호출 추가 옵션
         * 
         * <pre>
         * title                [옵션]:      {String}        팝업 창 타이틀
         * columnTitle          [옵션]:      {Array}         컬럼 타이틀, ["코드", "명"], 미지정시 기본 값
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * querySearchParam     [옵션]:      {String}        팝업 창 검색시 검색 값을 입력할 파라메터 명
         * queryCanAll          [옵션]:      {String}        팝업 창 전체 검색 가능 여부
         * showErrorMessage     [옵션]:      {Boolean}       미지정 또는 true 시 검색 결과가 없을 시 오류 메시지 표시
         * errorMessage         [옵션]:      {String}        오류 메시지, 미지정시 기본 오류메시지
         * </pre>
         * 
         * @example
         * 
         * <pre>
         * Call:
         *     // 호출 방법 1(단순 설정)
         *     $NP.onVendorChange(args.val, {
         *         P_CUST_CD: CUST_CD,
         *         P_VENDOR_CD: args.val,
         *         P_VIEW_DIV: "2"
         *     }, onVendorPopup);
         * 
         *     // 호출 방법 2(상세 설정)
         *     $NP.onVendorChange(args.val, {
         *         P_CUST_CD: CUST_CD,
         *         P_VENDOR_CD: args.val,
         *         P_VIEW_DIV: "2"
         *     }, onVendorPopup, {
         *         title: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "공급처 검색"),
         *         columnTitle: [
         *             $NC.getDisplayName("VENDOR_CD", "공급처코드"),
         *             $NC.getDisplayName("VENDOR_NM", "공급처명")
         *         ],
         *         errorMessage: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "등록되어 있지 않은 공급처입니다.")
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function onVendorChange(value, queryParams, onResult, options) {

            _onValueChange("Vendor", value, queryParams, onResult, options);
        }

        /**
         * 택배기준(운송사) 변경시 호출
         * 
         * @param {String}
         *        value 변경된 값
         * @param {Object}
         *        queryParams 서비스 호출 파라메터
         * @param {Function}
         *        onResult 선택 결과 처리 Callback
         * @param {Object}
         *        options 호출 추가 옵션
         * 
         * <pre>
         * title                [옵션]:      {String}        팝업 창 타이틀
         * columnTitle          [옵션]:      {Array}         컬럼 타이틀, ["코드", "명"], 미지정시 기본 값
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * querySearchParam     [옵션]:      {String}        팝업 창 검색시 검색 값을 입력할 파라메터 명
         * queryCanAll          [옵션]:      {String}        팝업 창 전체 검색 가능 여부
         * showErrorMessage     [옵션]:      {Boolean}       미지정 또는 true 시 검색 결과가 없을 시 오류 메시지 표시
         * errorMessage         [옵션]:      {String}        오류 메시지, 미지정시 기본 오류메시지
         * </pre>
         * 
         * @example
         * 
         * <pre>
         * Call:
         *     // 호출 방법 1(단순 설정)
         *     $NP.onWbBaseChange(args.val, {
         *         P_CARRIER_CD: args.val,
         *         P_CUST_CD: CUST_CD,
         *         P_ATTR05_CD: "1"
         *     }, onWbBasePopup);
         * 
         *     // 호출 방법 2(상세 설정)
         *     $NP.onWbBaseChange(args.val, {
         *         P_CARRIER_CD: args.val,
         *         P_CUST_CD: CUST_CD,
         *         P_ATTR05_CD: "1"
         *     }, onWbBasePopup, {
         *         title: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "운송사 검색"),
         *         columnTitle: [
         *             $NC.getDisplayName("CARRIER_CD", "운송사코드"),
         *             $NC.getDisplayName("CARRIER_NM", "운송사명")
         *         ],
         *         errorMessage: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "등록되어 있지 않은 운송사입니다.")
         *     });
         * </pre>
         * 
         * @since 7.1.0
         * @memberof $NP#
         */
        function onWbBaseChange(value, queryParams, onResult, options) {

            _onValueChange("WbBase", value, queryParams, onResult, options);
        }

        /**
         * 사업부 계약 수수료 구분 변경시 호출
         * 
         * @param {String}
         *        value 변경된 값
         * @param {Object}
         *        queryParams 서비스 호출 파라메터
         * @param {Function}
         *        onResult 선택 결과 처리 Callback
         * @param {Object}
         *        options 호출 추가 옵션
         * 
         * <pre>
         * title                [옵션]:      {String}        팝업 창 타이틀
         * columnTitle          [옵션]:      {Array}         컬럼 타이틀, ["코드", "명"], 미지정시 기본 값
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * querySearchParam     [옵션]:      {String}        팝업 창 검색시 검색 값을 입력할 파라메터 명
         * queryCanAll          [옵션]:      {String}        팝업 창 전체 검색 가능 여부
         * showErrorMessage     [옵션]:      {Boolean}       미지정 또는 true 시 검색 결과가 없을 시 오류 메시지 표시
         * errorMessage         [옵션]:      {String}        오류 메시지, 미지정시 기본 오류메시지
         * </pre>
         * 
         * @example
         * 
         * <pre>
         * Call:
         *     // 호출 방법 1(단순 설정)
         *     $NP.onBuContractChange(args.val, {
         *         P_CENTER_CD: $NC.getValue("#cboQCenter_Cd"),
         *         P_BU_CD: $NC.getValue("#edtQBu_Cd"),
         *         P_FEE_GRP: "10",
         *         P_FEE_GRP: args.val,
         *         P_VIEW_DIV: "2"
         *     }, onBuContractPopup);
         * 
         *     // 호출 방법 2(상세 설정)
         *     $NP.onBuContractChange(args.val, {
         *         P_CENTER_CD: $NC.getValue("#cboQCenter_Cd"),
         *         P_BU_CD: $NC.getValue("#edtQBu_Cd"),
         *         P_FEE_GRP: "10",
         *         P_FEE_DIV: args.val,
         *         P_VIEW_DIV: "2"
         *     }, onBuContractPopup, {
         *         title: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "수수료구분 검색"),
         *         columnTitle: [
         *             $NC.getDisplayName("FEE_DIV", "수수료구분"),
         *             $NC.getDisplayName("FEE_DIV_D", "수수료구분명"),
         *             $NC.getDisplayName("CONTRACT_NO", "계약번호"),
         *             $NC.getDisplayName("CONTRACT_NM", "계약명")
         *         ],
         *         errorMessage: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "등록되어 있지 않은 수수료구분입니다.")
         *     });
         * </pre>
         * 
         * @since 7.5.0
         * @memberof $NP#
         */
        function onBuContractChange(value, queryParams, onResult, options) {

            _onValueChange("BuContract", value, queryParams, onResult, options);
        }

        /**
         * 계약번호 변경시 호출
         * 
         * @param {String}
         *        value 변경된 값
         * @param {Object}
         *        queryParams 서비스 호출 파라메터
         * @param {Function}
         *        onResult 선택 결과 처리 Callback
         * @param {Object}
         *        options 호출 추가 옵션
         * 
         * <pre>
         * title                [옵션]:      {String}        팝업 창 타이틀
         * columnTitle          [옵션]:      {Array}         컬럼 타이틀, ["코드", "명"], 미지정시 기본 값
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * querySearchParam     [옵션]:      {String}        팝업 창 검색시 검색 값을 입력할 파라메터 명
         * queryCanAll          [옵션]:      {String}        팝업 창 전체 검색 가능 여부
         * showErrorMessage     [옵션]:      {Boolean}       미지정 또는 true 시 검색 결과가 없을 시 오류 메시지 표시
         * errorMessage         [옵션]:      {String}        오류 메시지, 미지정시 기본 오류메시지
         * </pre>
         * 
         * @example
         * 
         * <pre>
         * Call:
         *     // 호출 방법 1(단순 설정)
         *     $NP.onContractChange(args.val, {
         *         P_CONTRACT_NO: args.val,
         *         P_BILL_GRP: "10",
         *         P_VIEW_DIV: "2"
         *     }, onContractPopup);
         * 
         *     // 호출 방법 2(상세 설정)
         *     $NP.onContractChange(args.val, {
         *         P_CONTRACT_NO: args.val,
         *         P_BILL_GRP: "10",
         *         P_VIEW_DIV: "2"
         *     }, onContractPopup, {
         *         title: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "계약번호 검색"),
         *         columnTitle: [
         *             $NC.getDisplayName("CONTRACT_NO", "계약번호"),
         *             $NC.getDisplayName("CONTRACT_NM", "계약명")
         *         ],
         *         errorMessage: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "등록되어 있지 않은 계약번호입니다.")
         *     });
         * </pre>
         * 
         * @since 7.1.0
         * @memberof $NP#
         */
        function onContractChange(value, queryParams, onResult, options) {

            _onValueChange("Contract", value, queryParams, onResult, options);
        }

        /**
         * 계약번호, 정산구분 변경시 호출
         * 
         * @param {String}
         *        value 변경된 값
         * @param {Object}
         *        queryParams 서비스 호출 파라메터
         * @param {Function}
         *        onResult 선택 결과 처리 Callback
         * @param {Object}
         *        options 호출 추가 옵션
         * 
         * <pre>
         * title                [옵션]:      {String}        팝업 창 타이틀
         * columnTitle          [옵션]:      {Array}         컬럼 타이틀, ["코드", "명"], 미지정시 기본 값
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * querySearchParam     [옵션]:      {String}        팝업 창 검색시 검색 값을 입력할 파라메터 명
         * queryCanAll          [옵션]:      {String}        팝업 창 전체 검색 가능 여부
         * showErrorMessage     [옵션]:      {Boolean}       미지정 또는 true 시 검색 결과가 없을 시 오류 메시지 표시
         * errorMessage         [옵션]:      {String}        오류 메시지, 미지정시 기본 오류메시지
         * </pre>
         * 
         * @example
         * 
         * <pre>
         * Call:
         *     // 호출 방법 1(단순 설정)
         *     $NP.onContractBillChange(args.val, {
         *         P_CONTRACT_NO: args.val,
         *         P_BILL_GRP: "10",
         *         P_VIEW_DIV: "2"
         *     }, onContractPopup);
         * 
         *     // 호출 방법 2(상세 설정)
         *     $NP.onContractBillChange(args.val, {
         *         P_CONTRACT_NO: args.val,
         *         P_BILL_GRP: "10",
         *         P_VIEW_DIV: "2"
         *     }, onContractBillPopup, {
         *         title: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "계약번호 검색"),
         *         columnTitle: [
         *             $NC.getDisplayName("CONTRACT_NO", "계약번호"),
         *             $NC.getDisplayName("CONTRACT_NM", "계약명")
         *             $NC.getDisplayName("BILL_DIV", "정산구분"),
         *             $NC.getDisplayName("BILL_DIV_D", "정산구분명")
         *         ],
         *         errorMessage: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "등록되어 있지 않은 계약번호입니다.")
         *     });
         * </pre>
         * 
         * @since 7.5.0
         * @memberof $NP#
         */
        function onContractBillChange(value, queryParams, onResult, options) {

            _onValueChange("ContractBill", value, queryParams, onResult, options);
        }

        /**
         * 정산구분 변경시 호출
         * 
         * @param {String}
         *        value 변경된 값
         * @param {Object}
         *        queryParams 서비스 호출 파라메터
         * @param {Function}
         *        onResult 선택 결과 처리 Callback
         * @param {Object}
         *        options 호출 추가 옵션
         * 
         * <pre>
         * title                [옵션]:      {String}        팝업 창 타이틀
         * columnTitle          [옵션]:      {Array}         컬럼 타이틀, ["코드", "명"], 미지정시 기본 값
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * querySearchParam     [옵션]:      {String}        팝업 창 검색시 검색 값을 입력할 파라메터 명
         * queryCanAll          [옵션]:      {String}        팝업 창 전체 검색 가능 여부
         * showErrorMessage     [옵션]:      {Boolean}       미지정 또는 true 시 검색 결과가 없을 시 오류 메시지 표시
         * errorMessage         [옵션]:      {String}        오류 메시지, 미지정시 기본 오류메시지
         * </pre>
         * 
         * @example
         * 
         * <pre>
         * Call:
         *     // 호출 방법 1(단순 설정)
         *     $NP.onBillChange(args.val, {
         *         P_BILL_DIV: args.val,
         *         P_BILL_GRP: "10",
         *         P_VIEW_DIV: "2"
         *     }, onContractPopup);
         * 
         *     // 호출 방법 2(상세 설정)
         *     $NP.onBillChange(args.val, {
         *         P_BILL_DIV: args.val,
         *         P_BILL_GRP: "10",
         *         P_VIEW_DIV: "2"
         *     }, onBillPopup, {
         *         title: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "정산구분 검색"),
         *         columnTitle: [
         *             $NC.getDisplayName("BILL_DIV", "정산구분"),
         *             $NC.getDisplayName("BILL_DIV_D", "정산구분명")
         *         ],
         *         errorMessage: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "등록되어 있지 않은 정산구분입니다.")
         *     });
         * </pre>
         * 
         * @since 7.1.0
         * @memberof $NP#
         */
        function onBillChange(value, queryParams, onResult, options) {

            _onValueChange("Bill", value, queryParams, onResult, options);
        }

        /**
         * 포장박스(정산) 변경시 호출
         * 
         * @param {String}
         *        value 변경된 값
         * @param {Object}
         *        queryParams 서비스 호출 파라메터
         * @param {Function}
         *        onResult 선택 결과 처리 Callback
         * @param {Object}
         *        options 호출 추가 옵션
         * 
         * <pre>
         * title                [옵션]:      {String}        팝업 창 타이틀
         * columnTitle          [옵션]:      {Array}         컬럼 타이틀, ["코드", "명"], 미지정시 기본 값
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * querySearchParam     [옵션]:      {String}        팝업 창 검색시 검색 값을 입력할 파라메터 명
         * queryCanAll          [옵션]:      {String}        팝업 창 전체 검색 가능 여부
         * showErrorMessage     [옵션]:      {Boolean}       미지정 또는 true 시 검색 결과가 없을 시 오류 메시지 표시
         * errorMessage         [옵션]:      {String}        오류 메시지, 미지정시 기본 오류메시지
         * </pre>
         * 
         * @example
         * 
         * <pre>
         * Call:
         *     // 호출 방법 1(단순 설정)
         *     $NP.onBillBoxChange(args.val, {
         *         P_CONTRACT_NO: args.val,
         *         P_BILL_DIV: args.val,
         *         P_BU_CD: $ND.C_ALL,
         *         P_BOX_SIZE_CD: args.val,
         *         P_VIEW_DIV: "1"
         *     }, onBillBoxPopup);
         * 
         *     // 호출 방법 2(상세 설정)
         *     $NP.onBillBoxChange(args.val, {
         *         P_CONTRACT_NO: args.val,
         *         P_BILL_DIV: args.val,
         *         P_BU_CD: $ND.C_ALL,
         *         P_BOX_SIZE_CD: args.val,
         *         P_VIEW_DIV: "1"
         *     }, onBillBoxPopup, {
         *         title: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "박스코드 검색"),
         *         columnTitle: [
         *             $NC.getDisplayName("BOX_SIZE_CD", "박스코드"),
         *             $NC.getDisplayName("BOX_SIZE_NM", "박스코드명"),
         *             $NC.getDisplayName("BU_CD", "사업부코드"),
         *             $NC.getDisplayName("BU_NM", "사업부명")
         *         ],
         *         errorMessage: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "등록되어 있지 않은 박스코드입니다.")
         *     });
         * </pre>
         * 
         * @since 7.5.0
         * @memberof $NP#
         */
        function onBillBoxChange(value, queryParams, onResult, options) {

            _onValueChange("BillBox", value, queryParams, onResult, options);
        }

        /**
         * 존 변경시 호출
         * 
         * @param {String}
         *        value 변경된 값
         * @param {Object}
         *        queryParams 서비스 호출 파라메터
         * @param {Function}
         *        onResult 선택 결과 처리 Callback
         * @param {Object}
         *        options 호출 추가 옵션
         * 
         * <pre>
         * title                [옵션]:      {String}        팝업 창 타이틀
         * columnTitle          [옵션]:      {Array}         컬럼 타이틀, ["코드", "명"], 미지정시 기본 값
         * queryId              [옵션]:      {String}        미지정시 기본 쿼리ID 사용
         * querySearchParam     [옵션]:      {String}        팝업 창 검색시 검색 값을 입력할 파라메터 명
         * queryCanAll          [옵션]:      {String}        팝업 창 전체 검색 가능 여부
         * showErrorMessage     [옵션]:      {Boolean}       미지정 또는 true 시 검색 결과가 없을 시 오류 메시지 표시
         * errorMessage         [옵션]:      {String}        오류 메시지, 미지정시 기본 오류메시지
         * </pre>
         * 
         * @example
         * 
         * <pre>
         * Call:
         *     // 호출 방법 1(단순 설정)
         *     $NP.onZoneChange(args.val, {
         *         P_CENTER_CD: CENTER_CD,
         *         P_ZONE_CD: args.val,
         *         P_ZONE_DIV_ATTR01_CD: "1" // 1 - 일반, 2- 유통가공, 3 - 보세
         *     }, onZonePopup);
         * 
         *     // 호출 방법 2(상세 설정)
         *     $NP.onZoneChange(args.val, {
         *         P_CENTER_CD: CENTER_CD,
         *         P_ZONE_CD: args.val,
         *         P_ZONE_DIV_ATTR01_CD: "1" // 1 - 일반, 2- 유통가공, 3 - 보세
         *     }, onZonePopup, {
         *         title: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "존 검색"),
         *         columnTitle: [
         *             $NC.getDisplayName("ZONE_CD", "존코드"),
         *             $NC.getDisplayName("ZONE_NM", "존명")
         *         ],
         *         errorMessage: $NC.getDisplayMsg("JS.XXXXXXXXXX.XXX", "등록되어 있지 않은 존입니다.")
         *     });
         * </pre>
         * 
         * @since 6.0.0
         * @memberof $NP#
         */
        function onZoneChange(value, queryParams, onResult, options) {

            _onValueChange("Zone", value, queryParams, onResult, options);
        }
        // -------------------------------------------------------------------------------------------------------------------------------------------
        // Public Function
        // TODO: Public Function - END
        // -------------------------------------------------------------------------------------------------------------------------------------------

        // -------------------------------------------------------------------------------------------------------------------------------------------
        // Private Function
        // TODO: Private Function - START
        // -------------------------------------------------------------------------------------------------------------------------------------------

        /**
         * 타이틀 옵션 세팅
         * 
         * @param {Object}
         *        options 팝업 호출 옵션
         * @param {String}
         *        defPopupTitle 팝업 타이틀
         * @param {Array}
         *        defColumnTitle 그리드 컬럼 타이틀
         * @param {Array}
         *        gridColumns 그리드 컬럼정보
         * @private
         * @ignore
         * @since 6.0.0
         * @memberof $NP#
         */
        function _setTitleOptions(options, defPopupTitle, defColumnTitle, gridColumns) {

            if ($NC.isNotNull(defColumnTitle)) {
                if (!$.isArray(options.columnTitle)) {
                    options.columnTitle = defColumnTitle;
                } else {
                    options.columnTitle = $.extend(true, defColumnTitle, options.columnTitle);
                }
                for ( var col in gridColumns) {
                    gridColumns[col].name = options.columnTitle[col];
                }
                options.columns = gridColumns;
            }
            if ($NC.isNull(options.title)) {
                options.title = defPopupTitle + " " + $NC.getDisplayMsg("JS.POPUP.001", "검색");
            }

            // 멀티선택 체크
            // 멀티 선택, 기본은 false
            if ($NC.isNull(options.multiSelect)) {
                options.multiSelect = false;
            }
            // 멀티선택일 경우 선택 컬럼 추가
            if (options.multiSelect) {
                if (options.columns[0].field != "CHECK_YN") {
                    options.columns.splice(0, 0, {
                        id: "CHECK_YN",
                        field: "CHECK_YN",
                        resizable: false,
                        maxWidth: 30,
                        cssClass: "styCenter",
                        formatter: Slick.Formatters.CheckBox,
                        editor: Slick.Editors.CheckBox,
                        editorOptions: {
                            valueChecked: $ND.C_YES,
                            valueUnChecked: $ND.C_NO
                        }
                    });
                }
            }
        }

        /**
         * Service Call
         * 
         * @param {Object}
         *        options 서비스 호출 파라메터
         * @param {String}
         *        defQueryId 기본 Query Id
         * @param {String}
         *        defErrorMessage 기본 오류 메시지
         * @private
         * @ignore
         * @since 6.0.0
         * @memberof $NP#
         */
        function _getDataSet(options, defQueryId, defErrorMessage) {

            var requestData, dsResult;
            if ($NC.isNull(options)) {
                return [];
            }

            if ($NC.isNull(options.requestUrl)) {
                options.requestUrl = "/WC/getDataSet.do";
            }
            if ($NC.isNull(options.queryId)) {
                options.queryId = defQueryId;
            }
            if ($NC.isNull(options.showErrorMessage)) {
                options.showErrorMessage = true;
            }
            if (options.showErrorMessage && $NC.isNull(options.errorMessage)) {
                options.errorMessage = defErrorMessage;
            }

            requestData = {
                P_QUERY_ID: options.queryId
            };
            if ($NC.isNotNull(options.queryParams)) {
                requestData.P_QUERY_PARAMS = options.queryParams;
            }
            $NC.serviceCallAndWait(options.requestUrl, requestData, function(ajaxData) {
                dsResult = $NC.toArray(ajaxData);
            });

            if ($NC.isNull(dsResult)) {
                dsResult = [];
            }

            if (dsResult.length == 0 && options.showErrorMessage) {
                alert(options.errorMessage);
            }

            return dsResult;
        }

        /**
         * 공통 팝업 표시
         * 
         * @param {Object}
         *        requestData 서비스 호출 파라메터
         * @private
         * @ignore
         * @since 6.0.0
         * @memberof $NP#
         */
        function _showPopup(requestData) {

            $THIS.G_SHOW_POPUP = true;
            if ($NC.isNull(requestData.requestUrl)) {
                requestData.requestUrl = "/WC/getDataSet.do";
            }
            setTimeout(function() {
                $NC.G_MAIN.showCommonPopup(requestData);
            }, $ND.C_TIMEOUT_ACT);
        }

        /**
         * 코드 값 변경시 호출되는 Event
         * 
         * @param {String}
         *        target 호출 공통팝업명
         * @param {String}
         *        value 변경된 코드 값
         * @param {Object}
         *        queryParams 서비스 호출 파라메터
         * @param {Function}
         *        onResult 정상 처리시 결과를 받을 Callback
         * @param {Object}
         *        options 서비스 호출 옵션
         * @private
         * @ignore
         * @since 6.0.0
         * @memberof $NP#
         */
        function _onValueChange(target, value, queryParams, onResult, options) {

            var getInfoName, showPopupName, O_RESULT_DATA;
            if ($NC.isNull(target) || $NC.isNull(queryParams) || !$.isFunction(onResult)) {
                return;
            }

            // 호출 Function 세팅
            getInfoName = "get" + target + "Info";
            showPopupName = "show" + target + "Popup";

            if ($NC.isNull(options)) {
                options = {};
            }
            // 멀티 선택, 기본은 false
            if ($NC.isNull(options.multiSelect)) {
                options.multiSelect = false;
            }
            // 검색시 기본 선택은 검색 값으로 지정
            if (options.multiSelect && $NC.isNull(options.multiValue)) {
                options.multiValue = value;
            }

            O_RESULT_DATA = [];
            // 검색 값을 입력했을 경우 데이터 검색
            if ($NC.isNotNull(value)) {
                O_RESULT_DATA = $THIS[getInfoName]({
                    queryId: options.queryId,
                    queryParams: queryParams,
                    showErrorMessage: options.showErrorMessage,
                    errorMessage: options.errorMessage
                });
            }
            // 검색 값 미지정 또는 검색된 데이터가 1건일 경우 값 적용
            if (O_RESULT_DATA.length <= 1) {
                // 멀티 선택이면 Array로
                if (options.multiSelect) {
                    onResult(O_RESULT_DATA);
                } else {
                    onResult(O_RESULT_DATA[0]);
                }
            }
            // 검색된 데이터가 여러건일 경우 검색한 데이터로 팝업 표시
            else {
                $THIS[showPopupName]({
                    queryId: options.queryId,
                    queryParams: queryParams,
                    queryData: O_RESULT_DATA,
                    querySearchParam: options.querySearchParam,
                    queryCanAll: options.queryCanAll,
                    multiSelect: options.multiSelect,
                    multiValue: options.multiValue,
                    addBase: options.addBase
                }, onResult, onResult);
            }
        }

        /**
         * Public Method Export 처리<br>
         * Eclipse Outline에 정상 표시되도록 하기 위해 Function 선언 방법 변경<br>
         * function명 앞에 _(언더바)가 있을 경우 private function
         * 
         * <pre>
         * // v6.4 이전
         * $THIS.functionName = function() {
         * 
         * }
         * 
         * // v6.4 이후
         * function functionName() {
         * 
         * }
         * 
         * $.extend($THIS, {
         *     "functionName": functionImpl
         * }
         * </pre>
         * 
         * @since 6.4.0
         * @private
         * @ignore
         * @memberof $NP#
         */
        function _exportPublicMethod() {

            $.extend($THIS, {
                "version": Nexos.fn.version,

                "getBrandInfo": getBrandInfo,
                "getBillInfo": getBillInfo,
                "getBillBoxInfo": getBillBoxInfo,
                "getBuBrandInfo": getBuBrandInfo,
                "getBuContractInfo": getBuContractInfo,
                "getBuInfo": getBuInfo,
                "getCarInfo": getCarInfo,
                "getCarrierInfo": getCarrierInfo,
                "getCenterInfo": getCenterInfo,
                "getCodeInfo": getCodeInfo,
                "getContractInfo": getContractInfo,
                "getContractBillInfo": getContractBillInfo,
                "getCustBrandInfo": getCustBrandInfo,
                "getCustInfo": getCustInfo,
                "getDeliveryAreaInfo": getDeliveryAreaInfo,
                "getDeliveryInfo": getDeliveryInfo,
                "getDeptInfo": getDeptInfo,
                "getItemInfo": getItemInfo,
                "getItemLotInfo": getItemLotInfo,
                "getLocationInfo": getLocationInfo,
                "getMaterialInfo": getMaterialInfo,
                "getOrgnInfo": getOrgnInfo,
                "getPostInfo": getPostInfo,
                "getReferenceInfo": getReferenceInfo,
                "getTerminalInfo": getTerminalInfo,
                "getUserBrandInfo": getUserBrandInfo,
                "getUserBuInfo": getUserBuInfo,
                "getUserCenterInfo": getUserCenterInfo,
                "getUserCustInfo": getUserCustInfo,
                "getUserInfo": getUserInfo,
                "getVendorInfo": getVendorInfo,
                "getWbBaseInfo": getWbBaseInfo,
                "getZoneInfo": getZoneInfo,

                "onBrandChange": onBrandChange,
                "onBillChange": onBillChange,
                "onBillBoxChange": onBillBoxChange,
                "onBuBrandChange": onBuBrandChange,
                "onBuChange": onBuChange,
                "onBuContractChange": onBuContractChange,
                "onCarChange": onCarChange,
                "onCarrierChange": onCarrierChange,
                "onCenterChange": onCenterChange,
                "onCodeChange": onCodeChange,
                "onContractChange": onContractChange,
                "onContractBillChange": onContractBillChange,
                "onCustBrandChange": onCustBrandChange,
                "onCustChange": onCustChange,
                "onDeliveryAreaChange": onDeliveryAreaChange,
                "onDeliveryChange": onDeliveryChange,
                "onDeptChange": onDeptChange,
                "onItemChange": onItemChange,
                "onItemLotChange": onItemLotChange,
                "onLocationChange": onLocationChange,
                "onMaterialChange": onMaterialChange,
                "onOrgnChange": onOrgnChange,
                "onPopupClose": onPopupClose,
                "onPostChange": onPostChange,
                "onReferenceChange": onReferenceChange,
                "onTerminalChange": onTerminalChange,
                "onUserBrandChange": onUserBrandChange,
                "onUserBuChange": onUserBuChange,
                "onUserCenterChange": onUserCenterChange,
                "onUserCustChange": onUserCustChange,
                "onUserChange": onUserChange,
                "onVendorChange": onVendorChange,
                "onWbBaseChange": onWbBaseChange,
                "onZoneChange": onZoneChange,

                "showBrandPopup": showBrandPopup,
                "showBillPopup": showBillPopup,
                "showBillBoxPopup": showBillBoxPopup,
                "showBuBrandPopup": showBuBrandPopup,
                "showBuPopup": showBuPopup,
                "showBuContractPopup": showBuContractPopup,
                "showCarPopup": showCarPopup,
                "showCarrierPopup": showCarrierPopup,
                "showCenterPopup": showCenterPopup,
                "showCodePopup": showCodePopup,
                "showContractPopup": showContractPopup,
                "showContractBillPopup": showContractBillPopup,
                "showCustBrandPopup": showCustBrandPopup,
                "showCustPopup": showCustPopup,
                "showDaumPostcodePopup": showDaumPostcodePopup,
                "showDeliveryAreaPopup": showDeliveryAreaPopup,
                "showDeliveryPopup": showDeliveryPopup,
                "showDeptPopup": showDeptPopup,
                "showItemGroupPopup": showItemGroupPopup,
                "showItemLotPopup": showItemLotPopup,
                "showItemPopup": showItemPopup,
                "showLocationPopup": showLocationPopup,
                "showMaterialPopup": showMaterialPopup,
                "showOrgnPopup": showOrgnPopup,
                "showPostPopup": showPostPopup,
                "showReferencePopup": showReferencePopup,
                "showTerminalPopup": showTerminalPopup,
                "showUserBrandPopup": showUserBrandPopup,
                "showUserBuPopup": showUserBuPopup,
                "showUserCenterPopup": showUserCenterPopup,
                "showUserCustPopup": showUserCustPopup,
                "showUserPopup": showUserPopup,
                "showValidDatePopup": showValidDatePopup,
                "showVendorPopup": showVendorPopup,
                "showWbBasePopup": showWbBasePopup,
                "showZonePopup": showZonePopup
            });
        }

        /**
         * NexosPopup 초기화
         * 
         * @since 6.4.0
         * @private
         * @ignore
         * @memberof $NP#
         */
        function _init() {

            _exportPublicMethod();
        }
        // -------------------------------------------------------------------------------------------------------------------------------------------
        // Private Function
        // TODO: Private Function - END
        // -------------------------------------------------------------------------------------------------------------------------------------------

        /**
         * 초기화
         */
        _init();
    }

})(jQuery);
